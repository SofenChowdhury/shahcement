@extends('layouts.frontend_layout')
@section('contents')
<div class="content-grid"style="padding-left:10%;margin-bottom: 10px;">
	
</div>