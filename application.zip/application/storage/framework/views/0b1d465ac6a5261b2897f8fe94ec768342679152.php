
<?php $__env->startSection('contents'); ?>

<?php
  use App\model\forums\JoinBlogForum;
  use App\model\blog\Post;
?>
<div class="content-grid"style="padding-left:10%;margin-top: 7px;margin-bottom: 10px;">
  <div class="section-filters-bar v1" style="background-color: #ed2124;">
      <div class="section-filters-bar-actions">
        <h3 style="color: white;">Forums Lists</h3>        
      </div>
  </div>
  <div class="grid">
    <?php $__currentLoopData = $get_forums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formums): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
      $checkJoin = JoinBlogForum::where('forum_id',$formums->id)
        ->where('user_id',Auth::user()->id)
        ->first();
      $count_members  = JoinBlogForum::where('forum_id',$formums->id)->count();
      $count_posts    = Post::where('status',1)->where('forum_id',$formums->id)->count();
    ?>
      <div class="user-preview landscape" style="border-radius: 0px;">
          <figure class="user-preview-cover liquid" style="border-radius: 0px;margin-left: 1%;margin-bottom: 10px;">
            <img src="<?php echo e(asset($formums->cover)); ?>" alt="cover-08">
          </figure>
          <div class="user-preview-info">
            <div class="user-short-description landscape tiny">
                <a class="user-short-description-avatar user-avatar small no-stats" href="<?php echo e(route('blog_forums',['id'=>$formums->id])); ?>">
                  <div class="user-avatar-border">
                      <div class="hexagon-50-56"></div>
                  </div>
                  <div class="user-avatar-content">
                    <div class="hexagon-image-40-44" data-src="<?php echo e(asset($formums->avatar)); ?>"></div>
                  </div>
                </a>
                <p class="user-short-description-title"><a href="<?php echo e(route('blog_forums',['id'=>$formums->id])); ?>"><?php echo e($formums->title); ?></a></p>
                <p class="user-short-description-text"><?php echo e($formums->note); ?></p>
            </div>
            <div class="user-stats">
                <div class="user-stat">
                  <p class="user-stat-title"><?php echo e($count_members); ?></p>
                  <p class="user-stat-text">members</p>
                </div>
                <div class="user-stat">
                  <p class="user-stat-title"><?php echo e($count_posts); ?></p>
                  <p class="user-stat-text">posts</p>
                </div>
            </div>
            <div class="user-preview-actions">
                <div class="tag-sticker">
                  <?php if($formums->type == 0): ?>
                  <svg class="tag-sticker-icon icon-private">
                    <use xlink:href="#svg-private"></use>
                  </svg>
                  <?php else: ?>
                  <svg class="tag-sticker-icon icon-private">
                    <use xlink:href="#svg-public"></use>
                  </svg>
                  <?php endif; ?>
                </div>
                <span id="join_<?php echo e($formums->id); ?>">
                  <?php if($checkJoin): ?>
                  <?php if($checkJoin->status == '1'): ?>
                  
                  <p class="button success" onclick="leaveForum(<?php echo e($formums->id); ?>,<?php echo e($formums->type); ?>)" style="background-color:green;"><i class="lni lni-protection"></i></p>
                  <?php elseif($checkJoin->status == '0'): ?>
                  
                  <p class="button success" onclick="leaveForum(<?php echo e($formums->id); ?>,<?php echo e($formums->type); ?>)" style="background-color:blue;"><i class="lni lni-spinner"></i></p>
                  <?php else: ?>
                  
                    <p class="button secondary" onclick="joinForum(<?php echo e($formums->id); ?>,<?php echo e($formums->type); ?>)">
                      <svg class="button-icon icon-join-group">
                        <use xlink:href="#svg-join-group"></use>
                      </svg>
                    </p>
                  <?php endif; ?>
                  <?php else: ?>
                  
                    <p class="button secondary" onclick="joinForum(<?php echo e($formums->id); ?>,<?php echo e($formums->type); ?>)">
                      <svg class="button-icon icon-join-group">
                        <use xlink:href="#svg-join-group"></use>
                      </svg>
                    </p>
                  <?php endif; ?>
                </span>
            </div>
          </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script type="text/javascript">


  function joinForum(id,id2) {
    console.log(id2);
    var status = id2;
    if (status == '1'){

      $.ajax({
          url: "<?php echo e(url('join_group')); ?>"+'/'+id+'/'+1,
          method: "get",
          success: function(data){
            if(data){
              $('#join_'+id).find('p').hide();
              $('#join_'+id).append('<p class="button success" onclick="leaveForum('+id+','+status+')" style="background-color:green;"><i class="lni lni-protection"></i></p>');
            }
          }
        });
    }else{
      $.ajax({
          url: "<?php echo e(url('join_group')); ?>"+'/'+id+'/'+0,
          method: "get",
          success: function(data){
            if(data){
              $('#join_'+id).find('p').hide();
              $('#join_'+id).append('<p class="button success" onclick="leaveForum('+id+','+status+')" style="background-color:blue;"><i class="lni lni-spinner"></i></p>');
            }
          }
        });
    }
    
  }
  function leaveForum(id,id2){
    console.log(id);
    $.ajax({
        url: "<?php echo e(url('join_group')); ?>"+'/'+id+'/'+2,
        method: "get",
        success: function(data){
          if(data){
            $('#join_'+id).empty();
            $('#join_'+id).append('<p class="button secondary" onclick="joinForum('+id+','+id2+')">'+
                            '<svg class="button-icon icon-join-group">'+
                              '<use xlink:href="#svg-join-group"></use>'+
                            '</svg>'+
                          '</p>');
          }
        }
      });
    
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shahcement\application\resources\views/frontend/forum/index.blade.php ENDPATH**/ ?>