
<?php $__env->startSection('contents'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<div class="row" style="margin-top: 1%;">
    <div class="col-12">
    	<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card-box">
        	<div class="row">
        		<div class="col-10">
		            <h4 class="header-title text-center"><?php echo e($title); ?></h4>
		        </div>
		        <div class="col-2">
		            <a href="#create-modal" class="btn btn-primary waves-effect waves-light" data-animation="door" data-plugin="custommodal"data-overlaySpeed="100" data-overlayColor="#36404a" style="color: white;float: right;"><i class="fas fa-plus"></i> Create</a>
		        </div>
	        </div>
            <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                <thead>
	                <tr>
	                    <th>SL</th>
	                    <th>Image</th>
	                    <th>Name</th>
	                    <th>Email</th>
	                    <th>Phone</th>
	                    <th>Note</th>
	                    <th>Status</th>
	                    <th>Action</th>
	                </tr>
                </thead>
                <tbody>
                	<?php $__currentLoopData = $get_directory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $directory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                	<tr id="directory<?php echo e($directory->id); ?>">
	                    <td><?php echo e($loop->index+1); ?></td>
	                    <td><img src="<?php echo e(asset($directory->image)); ?>" style="height:50px;"></td>
	                    <td><?php echo e($directory->name); ?></td>
	                    <td><?php echo e($directory->email); ?></td>
	                    <td><?php echo e($directory->phone); ?></td>
	                    <td><?php echo e($directory->note); ?></td>
	                    <?php if($directory->status == 1): ?>
	                    <td style="background-color: green;color: white;" id="status<?php echo e($directory->id); ?>">Active</td>
	                    <?php else: ?>
	                    <td style="background-color: tomato;color: white;" id="status<?php echo e($directory->id); ?>">Pending</td>
	                    <?php endif; ?>
	                    <td style="width: 200px;">
						  	<a href="#edit-modal<?php echo e($directory->id); ?>" type="button" class="btn btn-info waves-effect waves-light" data-animation="door" data-plugin="custommodal" data-overlaySpeed="100" data-overlayColor="#36404a">
						  		<i class="far fa-edit"></i>
						  	</a>
	                        <a href="#" class="material-switch">
	                        	<?php if($directory->status == 1): ?>
	                            <input id="postApprove<?php echo e($directory->id); ?>" name="action" type="checkbox" onclick="actionPost(<?php echo e($directory->id); ?>)" checked=""/>
	                            <label for="postApprove<?php echo e($directory->id); ?>" class="label-danger" ></label>
	                            <?php else: ?>
	                            <input id="postApprove<?php echo e($directory->id); ?>" name="action" type="checkbox" onclick="actionPost(<?php echo e($directory->id); ?>)"/>
	                            <label for="postApprove<?php echo e($directory->id); ?>" class="label-danger" ></label>
	                            <?php endif; ?>
	                        </a>
						  	<a href="javascript:void(0);" type="button" class="btn btn-icon btn-danger btn_delete" attr="<?php echo e($directory->id); ?>">
						  		<i class="far fa-trash-alt"></i>
						  	</a>
						</td>
	                </tr>
                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>


        <!-- Modal -->
        <div id="create-modal" class="modal-demo">
            <button type="button" class="close" onclick="Custombox.modal.close();">
                <span>&times;</span><span class="sr-only">Close</span>
            </button>
            <h4 class="custom-modal-title">Create <?php echo e($title); ?></h4>
            <div class="text-muted">
                <form method="POST" action="<?php echo e(route('saveDirectory')); ?>" enctype="multipart/form-data">
		            <?php echo csrf_field(); ?>
					<div class="card m-0">
						<div class="card-body">
							<div class="row gutters">
								<div class="col-6">
									<label>Devision</label>
									<select class="form-control" name="division_id" required="" id="division_id">
										<option value="">Select Division</option>
										<?php $__currentLoopData = $get_divission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $divission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($divission->id); ?>"><?php echo e($divission->division_name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
								<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
									<div class="form-group">
										<label>City (required)</label>
										<select class="form-control" name="city_id" required="" id="city_id">
											<option value="">Select City</option>
										</select>
									</div>
								</div>
								<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
									<div class="form-group">
										<label>Service Name (required)</label>
										<select class="form-control" name="service_id" required="" id="service_id">
											<option value="">Select Service</option>
										</select>
									</div>
								</div>
								<div class="col-6">
									<label>Name</label>
									<input type="text" name="name" class="form-control" placeholder="Name"  required="" />
								</div>
								<div class="col-6">
									<label>Email</label>
									<input type="email" name="email" class="form-control" placeholder="Email" />
								</div>
								<div class="col-6">
									<label>Phone</label>
									<input type="text" name="phone" class="form-control" placeholder="Phone" />
								</div>
								<div class="col-12">
									<label>Image</label>
									<input type="file" name="image" class="form-control" />
								</div>
								<div class="col-12">
									<label>Doc Note</label>
									<textarea class="form-control" name="note" placeholder="Doc Note"></textarea>
								</div>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary">Save</button>
					</div>
				</form>
            </div>
        </div>
        <?php $__currentLoopData = $get_directory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div id="edit-modal<?php echo e($key->id); ?>" class="modal-demo">
            <button type="button" class="close" onclick="Custombox.modal.close();">
                <span>&times;</span><span class="sr-only">Close</span>
            </button>
            <h4 class="custom-modal-title">Update <?php echo e($key->name); ?></h4>
            <div class="text-muted">
                <form method="POST" action="<?php echo e(route('updateDirectory')); ?>" enctype="multipart/form-data">
		            <?php echo csrf_field(); ?>
					<div class="card m-0">
						<div class="card-body">
							<div class="row gutters">
								<div class="col-6">
									<label>Devision</label>
									<select class="form-control" name="division_id" required="" id="division_id<?php echo e($key->id); ?>">
										<option value="<?php echo e($key->devision_id); ?>"><?php echo e($key->division_name); ?></option>
										<?php $__currentLoopData = $get_divission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $divission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($divission->id); ?>"><?php echo e($divission->division_name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
								<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
									<div class="form-group">
										<label>City (required)</label>
										<select class="form-control" name="city_id" required="" id="city_id<?php echo e($key->id); ?>">
											<option value="<?php echo e($key->city_id); ?>"><?php echo e($key->city_name); ?></option>
										</select>
									</div>
								</div>
								<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
									<div class="form-group">
										<label>Service Name (required)</label>
										<select class="form-control" name="service_id" required="" id="service_id<?php echo e($key->id); ?>">
											<option value="<?php echo e($key->service_id); ?>"><?php echo e($key->service_name); ?></option>
										</select>
									</div>
								</div>
								<div class="col-6">
									<label>Name</label>
									<input type="text" name="name" class="form-control" placeholder="Name"  required="" value="<?php echo e($key->name); ?>" />
									<input type="hidden" name="id" class="form-control" placeholder="Name"  required="" value="<?php echo e($key->id); ?>" />
								</div>
								<div class="col-6">
									<label>Email</label>
									<input type="email" name="email" class="form-control" placeholder="email" value="<?php echo e($key->email); ?>" />
								</div>
								<div class="col-6">
									<label>Phone</label>
									<input type="text" name="phone" class="form-control" placeholder="email" value="<?php echo e($key->phone); ?>" />
								</div>
								<div class="col-12">
									<label>Image</label>
									<input type="file" name="image" class="form-control" />
									<img src="<?php echo e(asset($key->image)); ?>" style="width: 40px;">
								</div>
								<div class="col-12">
									<label>Doc Note</label>
									<textarea class="form-control" name="note" placeholder="Doc Note"><?php echo e($key->note); ?></textarea>
								</div>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary">Save</button>
					</div>
				</form>
            </div>
        </div>
        <script>
        	$('#division_id<?php echo e($key->id); ?>').change(function(){
				var division_id = $('#division_id<?php echo e($key->id); ?> :selected').val();
				$.ajax({
					url: "<?php echo e(url('/admin/city/data/')); ?>"+'/'+division_id,
					success:function(result){
						console.log(result);
						$('#city_id<?php echo e($key->id); ?>').empty();
						$('#city_id<?php echo e($key->id); ?>').append('<option value="">Select City</option>');
						for(var i=0; i<result.length; i++){
							$('#city_id<?php echo e($key->id); ?>').append('<option value='+result[i].id+'>'+result[i].city_name+'</option>');
						}
					}
				});
			})
			$('#city_id<?php echo e($key->id); ?>').change(function(){
				var city_id = $('#city_id<?php echo e($key->id); ?> :selected').val();

				$.ajax({
					url: "<?php echo e(url('/admin/service/data/')); ?>"+'/'+city_id,
					success:function(result){
						console.log(result);
						$('#service_id<?php echo e($key->id); ?>').empty();
						$('#service_id<?php echo e($key->id); ?>').append('<option value="">Select Service</option>');
						for(var i=0; i<result.length; i++){
							$('#service_id<?php echo e($key->id); ?>').append('<option value='+result[i].id+'>'+result[i].service_name+'</option>');
						}
					}
				});
			})
        </script>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<script>
	$(document).on('click', '.btn_delete',function(event){
		event.preventDefault();
		var id = $(this).attr("attr");
		Swal.fire({
		  title: 'Are you sure?',
		  text: "You won't be able to revert this!",
		  icon: 'warning',
		  showCancelButton: true,
		  confirmButtonColor: '#3085d6',
		  cancelButtonColor: '#d33',
		  confirmButtonText: 'Yes, delete it!'
		}).then((result) => {
		  if (result.value) {
		  	$('#directory'+id).hide();
			$.ajax({
				url: "<?php echo e(url('/admin/blog/directory/member/delete/')); ?>"+'/'+id,
				success:function(result){
					Swal.fire(
				      'Deleted!',
				      'Your Image has been deleted.',
				      'success'
				    )
				}
			});
		    
		  }
		})
	});
</script>
<script>
	function actionPost(id){

		if ($('#postApprove'+id).prop('checked') == true) {
			$('#status'+id).css('background-color','green');
			$('#status'+id).empty();
			$('#status'+id).text('Accepted');

			$.ajax({
	            url: "<?php echo e(url('actionDirectoryMember')); ?>"+'/'+id+'/'+1,
	            method: 'get',

	            success: function(result){
	            		console.log(result);
	            }
        	});
		}else{
			$('#status'+id).css('background-color','tomato');
			$('#status'+id).empty();
			$('#status'+id).text('Pending');
			$.ajax({
	            url: "<?php echo e(url('actionDirectoryMember')); ?>"+'/'+id+'/'+0,
	            method: 'get',

	            success: function(result){
	            	console.log(result);
	            }
        	});
		}
	}
</script>
<script>
	$('#division_id').change(function(){
		var division_id = $('#division_id :selected').val();
		$.ajax({
			url: "<?php echo e(url('/admin/city/data/')); ?>"+'/'+division_id,
			success:function(result){
				console.log(result);
				$('#city_id').empty();
				$('#city_id').append('<option value="">Select City</option>');
				for(var i=0; i<result.length; i++){
					$('#city_id').append('<option value='+result[i].id+'>'+result[i].city_name+'</option>');
				}
			}
		});
	})
	$('#city_id').change(function(){
		var city_id = $('#city_id :selected').val();

		$.ajax({
			url: "<?php echo e(url('/admin/service/data/')); ?>"+'/'+city_id,
			success:function(result){
				console.log(result);
				$('#service_id').empty();
				$('#service_id').append('<option value="">Select Service</option>');
				for(var i=0; i<result.length; i++){
					$('#service_id').append('<option value='+result[i].id+'>'+result[i].service_name+'</option>');
				}
			}
		});
	})
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<style>
	#datatable-buttons_filter{
		float: right !important;
	}
	.material-switch > input[type="checkbox"] {
	    display: none;   
	}

	.material-switch > label {
	    cursor: pointer;
	    height: 0px;
	    position: relative; 
	    width: 40px;  
	}

	.material-switch > label::before {
	    background: rgb(255 99 71);
	    box-shadow: inset 0px 0px 10px rgba(0, 0, 0, 0.5);
	    border-radius: 8px;
	    content: '';
	    height: 16px;
	    margin-top: -8px;
	    position:absolute;
	    opacity: 0.3;
	    transition: all 0.4s ease-in-out;
	    width: 40px;
	}
	.material-switch > label::after {
	    background: rgb(255 99 71);
	    border-radius: 16px;
	    box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.3);
	    content: '';
	    height: 24px;
	    left: -4px;
	    margin-top: -8px;
	    position: absolute;
	    top: -4px;
	    transition: all 0.3s ease-in-out;
	    width: 24px;
	}
	.material-switch > input[type="checkbox"]:checked + label::before {
	    background: green;
	    opacity: 0.5;
	}
	.material-switch > input[type="checkbox"]:checked + label::after {
	    background: green;
	    left: 20px;
	}
</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<!-- Datatable plugin js -->
<script src="<?php echo e(asset('assets/admin/libs/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/libs/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/libs/datatables/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/libs/datatables/buttons.bootstrap4.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/admin/libs/jszip/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/libs/pdfmake/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/libs/pdfmake/vfs_fonts.js')); ?>"></script>

<script src="<?php echo e(asset('assets/admin/libs/datatables/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/libs/datatables/buttons.print.min.js')); ?>"></script>

<!-- Datatables init -->
<script src="<?php echo e(asset('assets/admin/js/pages/datatables.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xobot/public_html/shahcement/application/resources/views/admin/directory/index.blade.php ENDPATH**/ ?>