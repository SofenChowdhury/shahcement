<?php
    use App\model\SetupSite;
    $get_site_settings = SetupSite::first();
  ?>
<style>
    @import  url('https://fonts.maateen.me/solaiman-lipi/font.css');
</style>
<!-- HEADER -->
  <header class="header">
    <div class="header-actions">
      <div class="header-brand">
        <div class="logo" style="width: 100px;">
          <img src="<?php echo e(asset($get_site_settings->logo)); ?>" style="width: 100%;">
        </div>
        <h1 class="header-brand-text">Nirmane Ami</h1>
      </div>
    </div>
    <div class="header-actions" style="width:100%;">
      <div class="sidemenu-trigger navigation-widget-trigger">
        <svg class="icon-grid">
          <use xlink:href="#svg-grid"></use>
        </svg>
      </div>
      <div class="mobilemenu-trigger navigation-widget-mobile-trigger">
        <div class="burger-icon inverted">
          <div class="burger-icon-bar"></div>
          <div class="burger-icon-bar"></div>
          <div class="burger-icon-bar"></div>
        </div>
      </div>
      <nav class="navigation">
        <ul class="menu-main" style="padding-top:2%;font-family: 'SolaimanLipi', sans-serif;">
          <li class="menu-main-item">
            <a class="menu-main-item-link" href="<?php echo e(route('index')); ?>" style="font-family: SolaimanLipi;font-size: 14px;">হোম </a>
          </li>
          <li class="menu-main-item">
            <a class="menu-main-item-link" href="<?php echo e(route('forums')); ?>"style="font-family: SolaimanLipi;font-size: 14px;">ফোরাম</a>
          </li>
          <li class="menu-main-item">
            <a class="menu-main-item-link" href="<?php echo e(route('construction_rule')); ?>"style="font-family: SolaimanLipi;font-size: 14px;">নির্মাণ নিয়মাবলী</a>
          </li>
          <li class="menu-main-item">
            <a class="menu-main-item-link" href="<?php echo e(route('e_book')); ?>"style="font-family: SolaimanLipi;font-size: 14px;">লাইব্রেরি</a>
          </li>
          <li class="menu-main-item">
            <a class="menu-main-item-link" href="<?php echo e(route('directory')); ?>"style="font-family: SolaimanLipi;font-size: 14px;">ডিরেক্টরি</a>
          </li>
          <li class="menu-main-item">
            <a class="menu-main-item-link" href="<?php echo e(route('gallery')); ?>"style="font-family: SolaimanLipi;font-size: 14px;">গ্যালারী</a>
          </li>
          <li class="menu-main-item">
            <a class="menu-main-item-link" href="<?php echo e(route('info_advice')); ?>"style="font-family: SolaimanLipi;font-size: 14px;">তথ্য ও পরামর্শ</a>
          </li>
        </ul>
      </nav>
    </div>
    <div class="header-actions search-bar">
      <div class="interactive-input dark">
        <input type="text" id="search-main" name="search_main" placeholder="Search here for people or groups" style="color: gray;">
        <div class="interactive-input-icon-wrap">
          <svg class="interactive-input-icon icon-magnifying-glass">
            <use xlink:href="#svg-magnifying-glass"></use>
          </svg>
        </div>
        <div class="interactive-input-action">
          <svg class="interactive-input-action-icon icon-cross-thin">
            <use xlink:href="#svg-cross-thin"></use>
          </svg>
        </div>
      </div>
    </div>
    <div class="header-actions">
      <div class="action-list dark">

        <!-- Message -->
        <div class="action-list-item-wrap">
          <!-- ACTION LIST ITEM -->
          <div class="action-list-item unread header-dropdown-trigger">
            <!-- ACTION LIST ITEM ICON -->
            <i class="lni lni-facebook-messenger" style="color:white;"></i>
            <!-- /ACTION LIST ITEM ICON -->
          </div>
          <!-- /ACTION LIST ITEM -->
          <?php
            use App\model\RepliedMessage;
            $get_replied_msg = RepliedMessage::leftjoin('messages','messages.id','replied_messages.message_id')
              ->leftjoin('users','users.id','replied_messages.replied_by')
              ->select('messages.title','users.name','users.image','replied_messages.*')
              ->where('replied_to',Auth::user()->id)
              ->orderby('id','DESC')
              ->limit(10)
              ->get();
          ?>
          <!-- DROPDOWN BOX -->
          <div class="dropdown-box header-dropdown">
            <!-- DROPDOWN BOX HEADER -->
            <div class="dropdown-box-header" style="border-bottom: 1px solid #dbdbdb;">
              <!-- DROPDOWN BOX HEADER TITLE -->
              <p class="dropdown-box-header-title">Messages</p>
              <!-- /DROPDOWN BOX HEADER TITLE -->
            </div>
            <!-- /DROPDOWN BOX HEADER -->
        
            <!-- DROPDOWN BOX LIST -->
            <div class="dropdown-box-list" data-simplebar>
              <?php $__currentLoopData = $get_replied_msg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $replied): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <!-- DROPDOWN BOX LIST ITEM -->
              <div class="dropdown-box-list-item unread">
                <!-- USER STATUS -->
                <div class="user-status notification">
                  <!-- USER STATUS AVATAR -->
                  <a class="user-status-avatar" href="<?php echo e(route('view_message',$replied->message_id)); ?>">
                    <!-- USER AVATAR -->
                    <div class="user-avatar small no-outline">
                      <!-- USER AVATAR CONTENT -->
                      <div class="user-avatar-content">
                        <!-- HEXAGON -->
                        <div class="hexagon-image-30-32" data-src="<?php echo e(asset($replied->image)); ?>"></div>
                        <!-- /HEXAGON -->
                      </div>
                      <!-- /USER AVATAR CONTENT -->
                    </div>
                    <!-- /USER AVATAR -->
                  </a>
                  <!-- /USER STATUS AVATAR -->
              
                  <!-- USER STATUS TITLE -->
                  <p class="user-status-title"><a class="bold" href="<?php echo e(route('view_message',$replied->message_id)); ?>"><?php echo e($replied->name); ?></a> sent a Message for your <a class="highlighted" href="<?php echo e(route('view_message',$replied->message_id)); ?>"><?php echo e($replied->title); ?></a></p>
                  <!-- /USER STATUS TITLE -->
              
                  <!-- USER STATUS TIMESTAMP -->
                  <p class="user-status-timestamp"><?php echo e(\Carbon\Carbon::parse($replied->updated_at)->diffForhumans()); ?></p>
                  <!-- /USER STATUS TIMESTAMP -->
              
                  <!-- USER STATUS ICON -->
                  <div class="user-status-icon">
                    <!-- ICON COMMENT -->
                    <svg class="icon-comment">
                      <use xlink:href="#svg-comment"></use>
                    </svg>
                    <!-- /ICON COMMENT -->
                  </div>
                  <!-- /USER STATUS ICON -->
                </div>
                <!-- /USER STATUS -->
              </div>
              <!-- /DROPDOWN BOX LIST ITEM -->
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- /DROPDOWN BOX LIST -->
        
            <!-- DROPDOWN BOX BUTTON -->
            <a class="dropdown-box-button secondary" href="<?php echo e(route('all_message')); ?>">View all Messages</a>
            <!-- /DROPDOWN BOX BUTTON -->
          </div>
          <!-- /DROPDOWN BOX -->
        </div>
        <!-- /Message -->
      </div>
      <!-- /ACTION LIST -->

      <!-- ACTION ITEM WRAP -->
      <div class="action-item-wrap">
        <!-- ACTION ITEM -->
        <div class="action-item dark header-settings-dropdown-trigger">
          <!-- ACTION ITEM ICON -->
          <svg class="action-item-icon icon-settings">
            <use xlink:href="#svg-settings"></use>
          </svg>
          <!-- /ACTION ITEM ICON -->
        </div>
        <!-- /ACTION ITEM -->

        <!-- DROPDOWN NAVIGATION -->
        <div class="dropdown-navigation header-settings-dropdown">
          <!-- DROPDOWN NAVIGATION HEADER -->
          <div class="dropdown-navigation-header">
            <!-- USER STATUS -->
            <div class="user-status">
              <!-- USER STATUS AVATAR -->
              <a class="user-status-avatar" href="<?php echo e(route('profile')); ?>">
                <!-- USER AVATAR -->
                <div class="user-avatar small no-outline">
                  <!-- USER AVATAR CONTENT -->
                  <div class="user-avatar-content">
                    <!-- HEXAGON -->
                    <div class="hexagon-image-30-32" data-src="<?php echo e(asset(Auth::user()->image)); ?>"></div>
                    <!-- /HEXAGON -->
                  </div>
                  <!-- /USER AVATAR CONTENT -->
              
                  <!-- USER AVATAR PROGRESS -->
                  <div class="user-avatar-progress">
                    <!-- HEXAGON -->
                    <div class="hexagon-progress-40-44"></div>
                    <!-- /HEXAGON -->
                  </div>
                  <!-- /USER AVATAR PROGRESS -->
              
                  <!-- USER AVATAR PROGRESS BORDER -->
                  <div class="user-avatar-progress-border">
                    <!-- HEXAGON -->
                    <div class="hexagon-border-40-44"></div>
                    <!-- /HEXAGON -->
                  </div>
                  <!-- /USER AVATAR PROGRESS BORDER -->
              
                  <!-- USER AVATAR BADGE -->
                  <div class="user-avatar-badge">
                    <!-- USER AVATAR BADGE BORDER -->
                    <div class="user-avatar-badge-border">
                      <!-- HEXAGON -->
                      <div class="hexagon-22-24"></div>
                      <!-- /HEXAGON -->
                    </div>
                    <!-- /USER AVATAR BADGE BORDER -->
              
                    <!-- USER AVATAR BADGE CONTENT -->
                    <div class="user-avatar-badge-content">
                      <!-- HEXAGON -->
                      <div class="hexagon-dark-16-18"></div>
                      <!-- /HEXAGON -->
                    </div>
                    <!-- /USER AVATAR BADGE CONTENT -->
                  </div>
                  <!-- /USER AVATAR BADGE -->
                </div>
                <!-- /USER AVATAR -->
              </a>
              <!-- /USER STATUS AVATAR -->
          
              <!-- USER STATUS TITLE -->
              <p class="user-status-title"><span class="bold">Hi <?php echo e(Auth()->user()->name); ?>!</span></p>
              <!-- /USER STATUS TITLE -->
          
              <!-- USER STATUS TEXT -->
              <p class="user-status-text small"><a href="<?php echo e(route('profile')); ?>"><?php echo e(Auth()->user()->email); ?></a></p>
              <!-- /USER STATUS TEXT -->
            </div>
            <!-- /USER STATUS -->
          </div>
          <!-- /DROPDOWN NAVIGATION HEADER -->
      
          <!-- DROPDOWN NAVIGATION CATEGORY -->
          <p class="dropdown-navigation-category">My Profile</p>
          <!-- /DROPDOWN NAVIGATION CATEGORY -->
          <?php if(Auth::user()->role=='Admin'): ?>
          <!-- DROPDOWN NAVIGATION LINK -->
          <a class="dropdown-navigation-link" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
          <!-- /DROPDOWN NAVIGATION LINK -->
          <?php endif; ?>
          <!-- DROPDOWN NAVIGATION LINK -->
          <a class="dropdown-navigation-link" href="<?php echo e(route('profile')); ?>">Profile Info</a>
          <!-- /DROPDOWN NAVIGATION LINK -->
      
          <!-- DROPDOWN NAVIGATION LINK -->
          <a class="dropdown-navigation-link" href="#">Notifications</a>
          <!-- /DROPDOWN NAVIGATION LINK -->
      
          <!-- DROPDOWN NAVIGATION LINK -->
          <a class="dropdown-navigation-link" href="<?php echo e(route('all_message')); ?>">Messages</a>
          <!-- /DROPDOWN NAVIGATION LINK -->
      
          <!-- DROPDOWN NAVIGATION LINK -->
          <a class="dropdown-navigation-link" href="<?php echo e(route('change_password')); ?>">Change Password</a>
          <!-- /DROPDOWN NAVIGATION LINK -->
          <a class="dropdown-navigation-button button small secondary" href="<?php echo e(route('logout')); ?>"
             onclick="event.preventDefault();
                           document.getElementById('logout-form').submit();">
              <?php echo e(__('Logout')); ?>

          </a>

          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
              <?php echo csrf_field(); ?>
          </form>
        </div>
        <!-- /DROPDOWN NAVIGATION -->
      </div>
      <!-- /ACTION ITEM WRAP -->
    </div>
    <!-- /HEADER ACTIONS -->
  </header>
  <!-- /HEADER --><?php /**PATH C:\xampp\htdocs\shahcement\application\resources\views/layouts/topbar.blade.php ENDPATH**/ ?>