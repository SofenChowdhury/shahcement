
<?php $__env->startSection('contents'); ?>
<div class="content-grid"style="padding-left:10%;margin-bottom: 10px;">
	
</div>
<?php echo $__env->make('layouts.frontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shahcement\application\resources\views/frontend/information/info_advice.blade.php ENDPATH**/ ?>