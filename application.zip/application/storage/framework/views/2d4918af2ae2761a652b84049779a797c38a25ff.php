
<?php $__env->startSection('contents'); ?>
<style type="text/css">

    .banner .med-caption {
        font-size: 2.5em
    }

    .box-title {
        margin-bottom: 0;
        line-height: 1em
    }

    .box-title small {
        font-size: 10px;
        color: #838383;
        text-transform: uppercase;
        display: block;
        margin-top: 4px
    }

    button,
    input[type="button"].button,
    a.button {
        border: none;
        color: #fff;
        cursor: pointer;
        padding: 0 15px;
        white-space: nowrap
    }

    button.btn-small,
    input[type="button"].button.btn-small,
    a.button.btn-small {
        height: 28px;
        padding: 0 24px;
        line-height: 28px;
        font-size: 0.9167em
    }

    a.button {
        display: inline-block;
        background: #d9d9d9;
        font-size: 0.8333em;
        line-height: 1.8333em;
        white-space: nowrap;
        text-align: center
    }

    a.button:hover {
        background: #98ce44
    }

    button.yellow,
    a.button.yellow,
    input[type="button"].button.yellow {
        background: #f0715f
    }
    .five-stars-container {
        display: inline-block;
        position: relative;
        font-family: 'Glyphicons Halflings';
        font-size: 14px;
        text-align: left;
        cursor: default;
        white-space: nowrap;
        line-height: 1.2em;
        color: #dbdbdb
    }

    .five-stars-container .five-stars,
    .five-stars-container.editable-rating .ui-slider-range {
        display: block;
        overflow: hidden;
        position: relative;
        background: #fff;
        padding-left: 1px
    }

    .five-stars-container .five-stars:before,
    .five-stars-container.editable-rating .ui-slider-range:before {
        content: "\e006\e006\e006\e006\e006";
        color: #ef715f
    }

    .five-stars-container:before {
        display: block;
        position: absolute;
        top: 0;
        left: 1px;
        content: "\e006\e006\e006\e006\e006";
        z-index: 0
    }

    .price {
        color: #7db921;
        font-size: 1.6667em;
        text-transform: uppercase;
        float: right;
        text-align: right;
        line-height: 1;
        display: block
    }

    .price small {
        display: block;
        color: #838383;
        font-size: 0.5em
    }

    .price-wrapper {
        font-weight: normal;
        text-transform: uppercase;
        font-size: 0.8333em;
        color: inherit;
        line-height: 1.3333em;
        margin: 0
    }

    .price-wrapper .price-per-unit {
        color: #7db921;
        font-size: 1.4em;
        padding-right: 5px
    }

    .image-carousel.style2 .slides>li {
        margin-right: 30px
    }

    .image-box .box>.details,
    .image-box.box>.details {
        padding: 12px 15px
    }

    .listing-style1.hotel .feedback {
        margin: 5px 0;
        border-top: 1px solid #f5f5f5;
        padding-top: 5px;
        border-bottom: 1px solid #f5f5f5
    }

    .listing-style1.hotel .feedback .review {
        display: block;
        float: right;
        text-transform: uppercase;
        font-size: 0.8333em;
        color: #9e9e9e
    }

    .listing-style1.hotel .action .button:last-child {
        float: right
    }

    .box {
        border: 1px solid #cccccc
    }

    .fa {
        color: #f0715f
    }
</style>
<div class="content-grid"style="padding-left:10%;margin-bottom: 10px;padding-top:5% !important;">
    <div class="section-filters-bar v2">
        <form class="form" method="GET" action="<?php echo e(route('searchDirectory')); ?>" enctype="multipart/form-data">
		    <?php echo csrf_field(); ?>
            <div class="form-item split medium">
                <div class="form-select" style="width: 100%;">
                    <input type="text" name="title" class="form-control" placeholder="search directry board ...">
                </div>
                <button type="submit" class="button secondary">Search Directry</button>
            </div>
        </form>
    </div>
    <div class="flex-viewport" style="padding-top: 20px;">
        <ul class="slides image-box hotel listing-style1">
            <?php for($i=0; $i<10; $i++): ?>
            <li style="width: 270px; float: left; display: block;">
                <article class="box">
                    <figure> <a href="ajax/slideshow-popup.html" class="hover-effect popup-gallery"><img width="270" height="160" alt="" src="https://res.cloudinary.com/dxfq3iotg/image/upload/v1556030102/home-office-336373_640.jpg" draggable="false"></a> </figure>
                    <div class="details"> <span class="price"><small>avg/night</small>$188</span>
                        <h4 class="box-title">Hotel Hilton<small>Albufeira</small></h4>
                        <div class="feedback">
                            <div data-placement="bottom" data-toggle="tooltip" class="fa fa-star" title="" data-original-title="4 stars"><span style="width: 80%;" class="five-stars"></span></div> <span class="review">170 reviews</span>
                        </div>
                        <p class="description">For what reason would it be advisable for me to think about business content?</p>
                        <div class="action"> <a class="button btn-small" href="#">BOOK</a> <a class="button btn-small yellow popup-map" href="#" data-box="37.089072, -8.247880">VIEW ON MAP</a> </div>
                    </div>
                </article>
            </li>
            <?php endfor; ?>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\whitepaper\shahcement\application\resources\views/frontend/directory/index.blade.php ENDPATH**/ ?>