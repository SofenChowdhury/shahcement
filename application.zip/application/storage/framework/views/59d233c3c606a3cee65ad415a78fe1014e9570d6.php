<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from odindesign-themes.com/Blog/newsfeed.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 03 Jul 2020 15:15:23 GMT -->
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- bootstrap 4.3.1 -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/vendor/bootstrap.min.css')); ?>">
  <!-- styles -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/styles.min.css')); ?>">
  <!-- simplebar styles -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/vendor/simplebar.css')); ?>">
  <!-- tiny-slider styles -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/vendor/tiny-slider.css')); ?>">
  <!-- favicon -->
  <link rel="icon" href="<?php echo e(asset('assets/frontend/img/favicon.ico')); ?>">
  <link href="https://cdn.lineicons.com/2.0/LineIcons.css" rel="stylesheet">
  <title>Blog | Newsfeed</title>
</head>
<body>
<style>
  .quick-post .quick-post-header .option-items{
    border-radius: 0px !important;
  }
.progress-stat-bar canvas{
  background-color: white;
  border-radius: 10px;
}
</style>
  <!-- PAGE LOADER -->
  <div class="page-loader" style="">
    <!-- PAGE LOADER DECORATION -->
    <div class="page-loader-decoration" style="background-color: transparent;">
      <!-- ICON LOGO -->
      <img class="icon-logo" src="https://static.wixstatic.com/media/48e8c5_c18117849889477a99f6b1c983eae079.png" style="width: 250%;height: 150%;">
      <!-- /ICON LOGO -->
    </div>
    <!-- /PAGE LOADER DECORATION -->

    <!-- PAGE LOADER INFO -->
    <div class="page-loader-info">
      <!-- PAGE LOADER INFO TITLE -->
      <p class="page-loader-info-title">Shah Cement Blog</p>
      <!-- /PAGE LOADER INFO TITLE -->

      <!-- PAGE LOADER INFO TEXT -->
      <p class="page-loader-info-text">Loading...</p>
      <!-- /PAGE LOADER INFO TEXT -->
    </div>
    <!-- /PAGE LOADER INFO -->
    
    <!-- PAGE LOADER INDICATOR -->
    <div class="page-loader-indicator loader-bars">
      <div class="loader-bar"></div>
      <div class="loader-bar"></div>
      <div class="loader-bar"></div>
      <div class="loader-bar"></div>
      <div class="loader-bar"></div>
      <div class="loader-bar"></div>
      <div class="loader-bar"></div>
      <div class="loader-bar"></div>
    </div>
    <!-- /PAGE LOADER INDICATOR -->
  </div>
  <!-- /PAGE LOADER -->



  <!-- NAVIGATION WIDGET -->
  <?php echo $__env->make('layouts.sidebar-left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- /NAVIGATION WIDGET -->



  <?php echo $__env->make('layouts.sidebar-right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- HEADER -->
  <?php echo $__env->make('layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- /HEADER -->

  <!-- FLOATY BAR -->
  <aside class="floaty-bar">
    <!-- BAR ACTIONS -->
    <div class="bar-actions">
      <!-- PROGRESS STAT -->
      <div class="progress-stat">
        <!-- BAR PROGRESS WRAP -->
        <div class="bar-progress-wrap">
          <!-- BAR PROGRESS INFO -->
          <p class="bar-progress-info">Next: <span class="bar-progress-text"></span></p>
          <!-- /BAR PROGRESS INFO -->
        </div>
        <!-- /BAR PROGRESS WRAP -->
    
        <!-- PROGRESS STAT BAR -->
        <div id="logged-user-level-cp" class="progress-stat-bar"></div>
        <!-- /PROGRESS STAT BAR -->
      </div>
      <!-- /PROGRESS STAT -->
    </div>
    <!-- /BAR ACTIONS -->

    <!-- BAR ACTIONS -->
    <div class="bar-actions">
      <!-- ACTION LIST -->
      <div class="action-list dark">
        <!-- ACTION LIST ITEM -->
        <a class="action-list-item" href="marketplace-cart.html">
          <!-- ACTION LIST ITEM ICON -->
          <svg class="action-list-item-icon icon-shopping-bag">
            <use xlink:href="#svg-shopping-bag"></use>
          </svg>
          <!-- /ACTION LIST ITEM ICON -->
        </a>
        <!-- /ACTION LIST ITEM -->

        <!-- ACTION LIST ITEM -->
        <a class="action-list-item" href="hub-profile-requests.html">
          <!-- ACTION LIST ITEM ICON -->
          <svg class="action-list-item-icon icon-friend">
            <use xlink:href="#svg-friend"></use>
          </svg>
          <!-- /ACTION LIST ITEM ICON -->
        </a>
        <!-- /ACTION LIST ITEM -->

        <!-- ACTION LIST ITEM -->
        <a class="action-list-item" href="hub-profile-messages.html">
          <!-- ACTION LIST ITEM ICON -->
          <svg class="action-list-item-icon icon-messages">
            <use xlink:href="#svg-messages"></use>
          </svg>
          <!-- /ACTION LIST ITEM ICON -->
        </a>
        <!-- /ACTION LIST ITEM -->

        <!-- ACTION LIST ITEM -->
        <a class="action-list-item unread" href="hub-profile-notifications.html">
          <!-- ACTION LIST ITEM ICON -->
          <svg class="action-list-item-icon icon-notification">
            <use xlink:href="#svg-notification"></use>
          </svg>
          <!-- /ACTION LIST ITEM ICON -->
        </a>
        <!-- /ACTION LIST ITEM -->
      </div>
      <!-- /ACTION LIST -->

      <!-- ACTION ITEM WRAP -->
      <a class="action-item-wrap" href="hub-profile-info.html">
        <!-- ACTION ITEM -->
        <div class="action-item dark">
          <!-- ACTION ITEM ICON -->
          <svg class="action-item-icon icon-settings">
            <use xlink:href="#svg-settings"></use>
          </svg>
          <!-- /ACTION ITEM ICON -->
        </div>
        <!-- /ACTION ITEM -->
      </a>
      <!-- /ACTION ITEM WRAP -->
    </div>
    <!-- /BAR ACTIONS -->
  </aside>
  <!-- /FLOATY BAR -->

  <!-- CONTENT GRID -->
  <div class="content-grid" style="">
    <!-- GRID -->
    <?php echo $__env->yieldContent('contents'); ?>
    <!-- /GRID -->
  </div>
  <!-- /CONTENT GRID -->
<!-- app -->
<script src="<?php echo e(asset('assets/frontend/app.bundle.min.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\blog\resources\views/layouts/frontend_layout.blade.php ENDPATH**/ ?>