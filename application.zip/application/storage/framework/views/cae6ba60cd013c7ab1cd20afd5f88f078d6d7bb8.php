
<?php $__env->startSection('contents'); ?>
<div class="content-grid"style="padding-left:10%;margin-bottom: 10px;padding-top:5% !important;">
    <div class="section-filters-bar v2">
        <form class="form" method="GET" action="<?php echo e(route('searchEbook')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-item split medium">
                <div class="form-select" style="width: 100%;">
                    <input type="text" name="title" class="form-control" placeholder="search E-Library with Title ...">
                </div>
                <button type="submit" class="button secondary">Search E-Library</button>
            </div>
        </form>
    </div>
    
    <div class="table table-quests split-rows">
        <div class="table-header">
            <div class="table-header-column">
                <p class="table-header-title">E-Library</p>
            </div>
            <div class="table-header-column">
                <p class="table-header-title">Description</p>
            </div>
            <div class="table-header-column" style="width: 150px;">
                <p class="table-header-title">File</p>
            </div>
            <div class="table-header-column" style="width: 200px;">
                <p class="table-header-title">Action</p>
            </div>
        </div>
        <div class="table-body same-color-rows">
            <?php $__currentLoopData = $get_library; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $library): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="table-row small">
                <div class="table-column">
                    <div class="table-information">
                        <img class="table-image" src="<?php echo e(asset($library->icon)); ?>" alt="completedq-s" style="width: 40px;">
                        <p class="table-title"><?php echo e($library->title); ?></p>
                    </div>
                </div>
                <div class="table-column">
                    <p class="table-text"><?php echo e($library->description); ?>

                    </p>
                </div>
                <div class="table-column">
                    <p class="table-text">
                        <a href="<?php echo e(asset($library->file)); ?>" target="_blank">
                            <i class="lni lni-folder" style="font-size: 20px;color: #ed2124;"></i>
                        </a>
                    </p>
                </div>
                <div class="table-column">
                    <p class="table-text btn btn-info">
                        <a href="<?php echo e(asset($library->file)); ?>" target="_blank">
                            <i class="lni lni-eye" style="color: white;"></i>
                        </a>
                    </p>
                    <p class="table-text btn btn-danger">
                        <a href="<?php echo e(asset($library->file)); ?>" download>
                            <i class="lni lni-cloud-download" style="color: white;"></i>
                        </a>
                    </p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamp\htdocs\shahcement\application\resources\views/frontend/e_book/index.blade.php ENDPATH**/ ?>