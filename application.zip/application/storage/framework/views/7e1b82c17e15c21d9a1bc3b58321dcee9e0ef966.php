
<?php $__env->startSection('contents'); ?>
<div class="content-grid"style="padding-left:10%;margin-bottom: 10px;">

      <h2 class="section-title">Latest Photos</h2>

  <div class="photos-masonry">
    <!-- PHOTO PREVIEW -->
    <div class="photo-preview popup-picture-trigger" style="margin-right: -5%;margin-top: -5%;">
      <figure class="photo-preview-image liquid">
        <img src="<?php echo e(asset('assets/frontend/img/cover/06.jpg')); ?>" alt="photo-preview-06">
      </figure>
      <div class="photo-preview-info">
        <div class="reaction-count-list landscape">
          <div class="reaction-count negative">
            <svg class="reaction-count-icon icon-thumbs-up">
              <use xlink:href="#svg-thumbs-up"></use>
            </svg>
            <p class="reaction-count-text">2</p>
          </div>
          <div class="reaction-count negative">
            <svg class="reaction-count-icon icon-comment">
              <use xlink:href="#svg-comment"></use>
            </svg>
            <p class="reaction-count-text">5</p>
          </div>
        </div>
      </div>
    </div>
    <!-- /PHOTO PREVIEW -->
    <!-- PHOTO PREVIEW -->
    <div class="photo-preview popup-picture-trigger" style="margin-right: -5%;margin-top: -5%;">
      <figure class="photo-preview-image liquid">
        <img src="<?php echo e(asset('assets/frontend/img/cover/16.jpg')); ?>" alt="photo-preview-16">
      </figure>
      <div class="photo-preview-info">
        <div class="reaction-count-list landscape">
          <div class="reaction-count negative">
            <svg class="reaction-count-icon icon-thumbs-up">
              <use xlink:href="#svg-thumbs-up"></use>
            </svg>
            <p class="reaction-count-text">2</p>
          </div>
          <div class="reaction-count negative">
            <svg class="reaction-count-icon icon-comment">
              <use xlink:href="#svg-comment"></use>
            </svg>
            <p class="reaction-count-text">5</p>
          </div>
        </div>
      </div>
    </div>
    <!-- /PHOTO PREVIEW -->
    <!-- PHOTO PREVIEW -->
    <div class="photo-preview popup-picture-trigger" style="margin-right: -5%;margin-top: -5%;">
      <figure class="photo-preview-image liquid">
        <img src="<?php echo e(asset('assets/frontend/img/cover/04.jpg')); ?>" alt="photo-preview-04">
      </figure>
      <div class="photo-preview-info">
        <div class="reaction-count-list landscape">
          <div class="reaction-count negative">
            <svg class="reaction-count-icon icon-thumbs-up">
              <use xlink:href="#svg-thumbs-up"></use>
            </svg>
            <p class="reaction-count-text">2</p>
          </div>
          <div class="reaction-count negative">
            <svg class="reaction-count-icon icon-comment">
              <use xlink:href="#svg-comment"></use>
            </svg>
            <p class="reaction-count-text">5</p>
          </div>
        </div>
      </div>
    </div>
    <!-- /PHOTO PREVIEW -->
    <!-- PHOTO PREVIEW -->
    <div class="photo-preview popup-picture-trigger" style="margin-right: -5%;margin-top: -5%;">
      <figure class="photo-preview-image liquid">
        <img src="<?php echo e(asset('assets/frontend/img/cover/20.jpg')); ?>" alt="photo-preview-20">
      </figure>
      <div class="photo-preview-info">
        <div class="reaction-count-list landscape">
          <div class="reaction-count negative">
            <svg class="reaction-count-icon icon-thumbs-up">
              <use xlink:href="#svg-thumbs-up"></use>
            </svg>
            <p class="reaction-count-text">2</p>
          </div>
          <div class="reaction-count negative">
            <svg class="reaction-count-icon icon-comment">
              <use xlink:href="#svg-comment"></use>
            </svg>
            <p class="reaction-count-text">5</p>
          </div>
        </div>
      </div>
    </div>
    <!-- PHOTO PREVIEW -->
    <div class="photo-preview popup-picture-trigger" style="margin-right: -5%;margin-top: -5%;">
      <figure class="photo-preview-image liquid">
        <img src="<?php echo e(asset('assets/frontend/img/cover/06.jpg')); ?>" alt="photo-preview-06">
      </figure>
      <div class="photo-preview-info">
        <div class="reaction-count-list landscape">
          <div class="reaction-count negative">
            <svg class="reaction-count-icon icon-thumbs-up">
              <use xlink:href="#svg-thumbs-up"></use>
            </svg>
            <p class="reaction-count-text">2</p>
          </div>
          <div class="reaction-count negative">
            <svg class="reaction-count-icon icon-comment">
              <use xlink:href="#svg-comment"></use>
            </svg>
            <p class="reaction-count-text">5</p>
          </div>
        </div>
      </div>
    </div>
    <!-- /PHOTO PREVIEW -->
  </div>
</div>

<script>
  $('#OpenImgUpload').click(function(){ 
    $('#imgupload').trigger('click');
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shahcement\application\resources\views/frontend/gallery/index.blade.php ENDPATH**/ ?>