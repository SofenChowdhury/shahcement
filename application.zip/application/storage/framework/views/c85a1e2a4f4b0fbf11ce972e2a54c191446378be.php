
<?php $__env->startSection('contents'); ?>
<div class="grid grid-3-6-3 mobile-prefer-content" style="margin-top: -20px;">
  <div class="grid-column">
    <?php if(Auth::user()): ?>
    <div class="widget-box">
      <div class="progress-arc-summary">
        <div class="progress-arc-wrap">
          <div class="progress-arc">
            <canvas id="profile-completion-chart"></canvas>
          </div>
          <div class="progress-arc-info">
            
            <img src="<?php echo e(asset(Auth::user()->image)); ?>" style="width: 100%;border-radius: 50%;">
          </div>
        </div>
        <div class="progress-arc-summary-info">
          <p class="progress-arc-summary-title"><?php echo e(Auth::user()->name); ?></p>
          <p class="progress-arc-summary-subtitle"><?php echo e(Auth::user()->email); ?></p>
        </div>
      </div>
      
    </div>
    <?php endif; ?>
    <div class="widget-box">
      <!-- WIDGET BOX CONTROLS -->
      <div class="widget-box-controls">
        <!-- SLIDER CONTROLS -->
        <div id="badge-stat-slider-controls" class="slider-controls">
          <!-- SLIDER CONTROL -->
          <div class="slider-control left">
            <!-- SLIDER CONTROL ICON -->
            <svg class="slider-control-icon icon-small-arrow">
              <use xlink:href="#svg-small-arrow"></use>
            </svg>
            <!-- /SLIDER CONTROL ICON -->
          </div>
          <!-- /SLIDER CONTROL -->

          <!-- SLIDER CONTROL -->
          <div class="slider-control right">
            <!-- SLIDER CONTROL ICON -->
            <svg class="slider-control-icon icon-small-arrow">
              <use xlink:href="#svg-small-arrow"></use>
            </svg>
            <!-- /SLIDER CONTROL ICON -->
          </div>
          <!-- /SLIDER CONTROL -->
        </div>
        <!-- /SLIDER CONTROLS -->
      </div>
      <!-- /WIDGET BOX CONTROLS -->

      <!-- WIDGET BOX TITLE -->
      <p class="widget-box-title">Featured Badges</p>
      <!-- /WIDGET BOX TITLE -->

      <!-- WIDGET BOX CONTENT -->
      <div class="widget-box-content">
        <!-- WIDGET BOX CONTENT SLIDER -->
        <div id="badge-stat-slider-items" class="widget-box-content-slider">
          <!-- WIDGET BOX CONTENT SLIDER ITEM -->
          <div class="widget-box-content-slider-item">
            <!-- BADGE ITEM STAT -->
            <div class="badge-item-stat void">
              <!-- TEXT STICKER -->
              <p class="text-sticker">
                <!-- TEXT STICKER ICON -->
                <svg class="text-sticker-icon icon-plus-small">
                  <use xlink:href="#svg-plus-small"></use>
                </svg>
                <!-- TEXT STICKER ICON -->
                20 EXP
              </p>
              <!-- /TEXT STICKER -->

              <!-- BADGE ITEM STAT IMAGE -->
              <img class="badge-item-stat-image" src="<?php echo e(asset('assets/frontend/img/badge/uexp-b.png')); ?>" alt="badge-uexp-b">
              <!-- /BADGE ITEM STAT IMAGE -->

              <!-- BADGE ITEM STAT TITLE -->
              <p class="badge-item-stat-title">Universe Explorer</p>
              <!-- /BADGE ITEM STAT TITLE -->

              <!-- BADGE ITEM STAT TEXT -->
              <p class="badge-item-stat-text">Joined and posted on 20 different groups</p>
              <!-- /BADGE ITEM STAT TEXT -->

              <!-- PROGRESS STAT -->
              <div class="progress-stat medium">
                <!-- PROGRESS STAT BAR -->
                <div id="badge-uexp" class="progress-stat-bar"></div>
                <!-- /PROGRESS STAT BAR -->

                <!-- BAR PROGRESS WRAP -->
                <div class="bar-progress-wrap">
                  <!-- BAR PROGRESS INFO -->
                  <p class="bar-progress-info negative center"><span class="bar-progress-text no-space"></span></p>
                  <!-- /BAR PROGRESS INFO -->
                </div>
                <!-- /BAR PROGRESS WRAP -->
              </div>
              <!-- /PROGRESS STAT -->
            </div>
            <!-- /BADGE ITEM STAT -->
          </div>
          <!-- /WIDGET BOX CONTENT SLIDER ITEM -->

          <!-- WIDGET BOX CONTENT SLIDER ITEM -->
          <div class="widget-box-content-slider-item">
            <!-- BADGE ITEM STAT -->
            <div class="badge-item-stat void">
              <!-- TEXT STICKER -->
              <p class="text-sticker">
                <!-- TEXT STICKER ICON -->
                <svg class="text-sticker-icon icon-plus-small">
                  <use xlink:href="#svg-plus-small"></use>
                </svg>
                <!-- TEXT STICKER ICON -->
                40 EXP
              </p>
              <!-- /TEXT STICKER -->

              <!-- BADGE ITEM STAT IMAGE -->
              <img class="badge-item-stat-image" src="<?php echo e(asset('assets/frontend/img/badge/verifieds-b.png')); ?>" alt="badge-verifieds-b">
              <!-- /BADGE ITEM STAT IMAGE -->

              <!-- BADGE ITEM STAT TITLE -->
              <p class="badge-item-stat-title">Verified Streamer</p>
              <!-- /BADGE ITEM STAT TITLE -->

              <!-- BADGE ITEM STAT TEXT -->
              <p class="badge-item-stat-text">Has linked a stream that was verified by the staff</p>
              <!-- /BADGE ITEM STAT TEXT -->

              <!-- PROGRESS STAT -->
              <div class="progress-stat medium">
                <!-- PROGRESS STAT BAR -->
                <div id="badge-verifieds" class="progress-stat-bar"></div>
                <!-- /PROGRESS STAT BAR -->

                <!-- BAR PROGRESS WRAP -->
                <div class="bar-progress-wrap">
                  <!-- BAR PROGRESS INFO -->
                  <p class="bar-progress-info negative center"><span class="bar-progress-text no-space"></span></p>
                  <!-- /BAR PROGRESS INFO -->
                </div>
                <!-- /BAR PROGRESS WRAP -->
              </div>
              <!-- /PROGRESS STAT -->
            </div>
            <!-- /BADGE ITEM STAT -->
          </div>
          <!-- /WIDGET BOX CONTENT SLIDER ITEM -->

          <!-- WIDGET BOX CONTENT SLIDER ITEM -->
          <div class="widget-box-content-slider-item">
            <!-- BADGE ITEM STAT -->
            <div class="badge-item-stat void">
              <!-- TEXT STICKER -->
              <p class="text-sticker">
                <!-- TEXT STICKER ICON -->
                <svg class="text-sticker-icon icon-plus-small">
                  <use xlink:href="#svg-plus-small"></use>
                </svg>
                <!-- TEXT STICKER ICON -->
                40 EXP
              </p>
              <!-- /TEXT STICKER -->

              <!-- BADGE ITEM STAT IMAGE -->
              <img class="badge-item-stat-image" src="<?php echo e(asset('assets/frontend/img/badge/qconq-b.png')); ?>" alt="badge-qconq-b">
              <!-- /BADGE ITEM STAT IMAGE -->

              <!-- BADGE ITEM STAT TITLE -->
              <p class="badge-item-stat-title">Quest Conqueror</p>
              <!-- /BADGE ITEM STAT TITLE -->

              <!-- BADGE ITEM STAT TEXT -->
              <p class="badge-item-stat-text">Succesfully completed at least 10 quests at 100%</p>
              <!-- /BADGE ITEM STAT TEXT -->

              <!-- PROGRESS STAT -->
              <div class="progress-stat medium">
                <!-- PROGRESS STAT BAR -->
                <div id="badge-qconq" class="progress-stat-bar"></div>
                <!-- /PROGRESS STAT BAR -->

                <!-- BAR PROGRESS WRAP -->
                <div class="bar-progress-wrap">
                  <!-- BAR PROGRESS INFO -->
                  <p class="bar-progress-info negative center"><span class="bar-progress-text no-space"></span></p>
                  <!-- /BAR PROGRESS INFO -->
                </div>
                <!-- /BAR PROGRESS WRAP -->
              </div>
              <!-- /PROGRESS STAT -->
            </div>
            <!-- /BADGE ITEM STAT -->
          </div>
          <!-- /WIDGET BOX CONTENT SLIDER ITEM -->
        </div>
        <!-- /WIDGET BOX CONTENT SLIDER -->
      </div>
      <!-- /WIDGET BOX CONTENT -->
    </div>
  </div>
  <div class="grid-column">
    <?php echo $__env->make('frontend.includes.posts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
  <div class="grid-column">
    <div class="widget-box">
      <div class="widget-box-controls">
        <div id="reaction-stat-slider-controls" class="slider-controls">
          <div class="slider-control left">
            <svg class="slider-control-icon icon-small-arrow">
              <use xlink:href="#svg-small-arrow"></use>
            </svg>
          </div>
          <div class="slider-control right">
            <svg class="slider-control-icon icon-small-arrow">
              <use xlink:href="#svg-small-arrow"></use>
            </svg>
          </div>
        </div>
      </div>

      <p class="widget-box-title">Reactions Received</p>

      <div class="widget-box-content">
        <div id="reaction-stat-slider-items" class="widget-box-content-slider">
          <div class="widget-box-content-slider-item">
            <div class="reaction-stats">
              <div class="reaction-stat">
                <img class="reaction-stat-image" src="<?php echo e(asset('assets/frontend/img/reaction/like.png')); ?>" alt="reaction-like">
                <p class="reaction-stat-title">12.642</p>
                <p class="reaction-stat-text">Likes</p>
              </div>
              <div class="reaction-stat">
                <img class="reaction-stat-image" src="<?php echo e(asset('assets/frontend/img/reaction/love.png')); ?>" alt="reaction-love">
                <p class="reaction-stat-title">8.913</p>
                <p class="reaction-stat-text">Loves</p>
              </div>
            </div>
            <div class="reaction-stats">
              <div class="reaction-stat">
                <img class="reaction-stat-image" src="<?php echo e(asset('assets/frontend/img/reaction/dislike.png')); ?>" alt="reaction-dislike">
                <p class="reaction-stat-title">945</p>
                <p class="reaction-stat-text">Dislikes</p>
              </div>
              <div class="reaction-stat">
                <img class="reaction-stat-image" src="<?php echo e(asset('assets/frontend/img/reaction/happy.png')); ?>" alt="reaction-happy">
                <p class="reaction-stat-title">7.034</p>
                <p class="reaction-stat-text">Happy</p>
              </div>
            </div>
          </div>
          <div class="widget-box-content-slider-item">
            <div class="reaction-stats">
              <div class="reaction-stat">
                <img class="reaction-stat-image" src="<?php echo e(asset('assets/frontend/img/reaction/funny.png')); ?>" alt="reaction-funny">

                <p class="reaction-stat-title">2.356</p>
                <p class="reaction-stat-text">Funny</p>
              </div>
              <div class="reaction-stat">
                <img class="reaction-stat-image" src="<?php echo e(asset('assets/frontend/img/reaction/wow.png')); ?>" alt="reaction-wow">
                <p class="reaction-stat-title">5.944</p>
                <p class="reaction-stat-text">Wow!</p>
              </div>
            </div>
            <div class="reaction-stats">
              <div class="reaction-stat">
                <img class="reaction-stat-image" src="<?php echo e(asset('assets/frontend/img/reaction/angry.png')); ?>" alt="reaction-angry">
                <p class="reaction-stat-title">1.706</p>
                <p class="reaction-stat-text">Angry</p>
              </div>
              <div class="reaction-stat">
                <img class="reaction-stat-image" src="<?php echo e(asset('assets/frontend/img/reaction/sad.png')); ?>" alt="reaction-sad">
                <p class="reaction-stat-title">801</p>
                <p class="reaction-stat-text">Sad</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="widget-box no-padding">
      <p class="widget-box-title" style="margin-bottom: -20px;">Upcommings Events</p>
      <div class="widget-box-content">
        <div class="calendar-events-preview small">
          <p class="calendar-events-preview-title">Monday 13th</p>
          <div class="calendar-event-preview-list">
            <div class="calendar-event-preview small secondary">
              <div class="calendar-event-preview-start-time">
                <p class="calendar-event-preview-start-time-title">8:30</p>
                <p class="calendar-event-preview-start-time-text">AM</p>
              </div>
              <div class="calendar-event-preview-info">
                <p class="calendar-event-preview-title">Breakfast with Neko</p>
                <p class="calendar-event-preview-text">Hi Neko! I'm creating this event to invite you to have breakfast before work. Meet me at Coffebucks.</p>
              </div>
            </div>
            <div class="calendar-event-preview small primary">
              <div class="calendar-event-preview-start-time">
                <p class="calendar-event-preview-start-time-title">10:00</p>
                <p class="calendar-event-preview-start-time-text">PM</p>
              </div>
              <div class="calendar-event-preview-info">
                <p class="calendar-event-preview-title">Streaming Party</p>
                <p class="calendar-event-preview-text">The biggest party for Twitch streamers! Come and join us at Shenron Arena.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/frontend/index.blade.php ENDPATH**/ ?>