
<?php $__env->startSection('contents'); ?>
<div class="content-grid"style="margin-top: 30px;margin-bottom: 10px;">
	<section class="section">
	  <div class="section-header">
	    <div class="section-header-info">
	    </div>
	  </div>
	  	<div class="row">
	  		<?php $__currentLoopData = $get_videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  		<div class="col-md-3" style="padding-top: 10px;padding-bottom: 10px;">
			    <div class="user-preview small" Style="border-radius:20px !important">
			      	<embed
					    src="<?php echo e($video->video_link); ?>"
					    wmode="transparent"
					    type="video/mp4"
					    width="100%" height="100%"
					    allow="autoplay; encrypted-media; picture-in-picture"
					    allowfullscreen
					    title="Keyboard Cat"
					  >
			      	
			      	<div class="user-preview-footer" style="background-color: #ed2124;">
			      		<a href="<?php echo e(asset($video->video_link)); ?>">
					        <p class="abc" style="font-size: 16px;color: white;text-align: left;"> &nbsp &nbsp 
					               &nbsp &nbsp &nbsp &nbsp  
					        </p>
					    </a>
					    <!---->
					    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(asset($video->video_link)); ?>&display=popup" target="_blank">
					        <p class="abc" style="font-size: 16px;color: white;text-align: right;">
					            <i class="lni lni-facebook-oval"></i> &nbsp &nbsp &nbsp 
					        </p>
					    </a>
					    <a href="https://wa.me/?text=<?php echo e(asset($video->video_link)); ?>&display=popup" target="_blank">
					        <p class="abc" style="font-size: 16px;color: white;text-align: right;">
					            &nbsp&nbsp<i class="lni lni-whatsapp"></i> &nbsp &nbsp &nbsp 
					        </p>
					    </a>
					    <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo e(asset($video->video_link)); ?>&display=popup" target="_blank">
					        <p class="abc" style="font-size: 16px;color: white;text-align: right;">
					            &nbsp&nbsp<i class="lni lni-linkedin-original"></i> &nbsp &nbsp &nbsp 
					        </p>
					    </a>
					    <a  href="http://www.twitter.com/share?url=<?php echo e(asset($video->video_link)); ?>&display=popup" target="_blank">
					        <p class="abc" style="font-size: 16px;color: white;text-align: right;">
					            &nbsp&nbsp<i class="lni lni-twitter-original"></i> &nbsp &nbsp &nbsp 
					        </p>
					    </a>
			      	</div>
			    </div>
			</div>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  	</div>
	</section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xobot/public_html/shahcement/application/resources/views/frontend/gallery/videos.blade.php ENDPATH**/ ?>