
<?php $__env->startSection('contents'); ?>

<div class="content-grid"style="margin-top: 30px;margin-bottom: 10px;">
	<section class="section">
	  <div class="section-header">
	    <div class="section-header-info">
	      
	    </div>
	  </div>
	  	<div class="grid grid-3-3-3-3 centered">
	  		<?php $__currentLoopData = $get_const_rule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $const_rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    <div class="user-preview small">
		      	<figure class="user-preview-cover liquid">
		        	<img src="<?php echo e(asset($const_rule->image)); ?>" alt="cover-04">
		      	</figure>
		      	<div class="user-preview-info" style="height:100px;overflow-y:hidden;">
			        <div class="user-short-description small">
			          	<p class="user-short-description-title">
			          		<a href="#"><?php echo e($const_rule->title); ?></a>
			          	</p>
			          	<p class="user-short-description-text">
			          		<a href="#"><?php echo e($const_rule->description); ?></a>
			          	</p>
			          	<?php if($const_rule->website): ?>
			          	<p class="" style="text-align: left;font-size: 13px;line-height: 13px;">
			          		<a href="#"><i class="lni lni-world"></i> <?php echo e($const_rule->website); ?></a>
			          	</p>
			          	<?php endif; ?>
			          	<?php if($const_rule->address): ?>
			          	<p class="" style="text-align: left;font-size: 13px;line-height: 30px;">
			          		<a href="#"><i class="lni lni-direction"></i> <?php echo e($const_rule->address); ?></a>
			          	</p>
			          	<?php endif; ?>
			        </div>
		      	</div>
		      	<div class="user-preview-footer" style="background-color: #ed2124;padding-top:5px;">
		      		<a href="<?php echo e(asset($const_rule->file)); ?>">
				        <p class="abc" style="font-size: 16px;color: white;text-align: left;"> &nbsp &nbsp 
				            <i class="lni lni-download"></i> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp  
				        </p>
				    </a>
				    <!---->
				    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(asset($const_rule->file)); ?>&display=popup" target="_blank">
				        <p class="abc" style="font-size: 16px;color: white;text-align: right;">
				            <i class="lni lni-facebook-oval"></i>
				            
				        </p>
				        
				    </a>
				    <a href="https://wa.me/?text=<?php echo e(asset($const_rule->file)); ?>&display=popup" target="_blank">
				        <p class="abc" style="font-size: 16px;color: white;text-align: right;">
				            &nbsp&nbsp<i class="lni lni-whatsapp"></i>
				            
				        </p>
				        
				    </a>
				    <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo e(asset($const_rule->file)); ?>&display=popup" target="_blank">
				        <p class="abc" style="font-size: 16px;color: white;text-align: right;">
				            &nbsp&nbsp<i class="lni lni-linkedin-original"></i>
				            
				        </p>
				        
				    </a>
				    <a  href="http://www.twitter.com/share?url=<?php echo e(asset($const_rule->file)); ?>&display=popup" target="_blank">
				        <p class="abc" style="font-size: 16px;color: white;text-align: right;">
				            &nbsp&nbsp<i class="lni lni-twitter-original"></i>
				            
				        </p>
				        
				    </a>
				    <!--<a href="fb-messenger://share/?link=http://url-you-want-to-share.com&app_id=<?php echo e(asset($const_rule->file)); ?>&display=popup" target="_blank">-->
				    <!--    <p class="abc" style="font-size: 16px;color: white;text-align: right;">-->
				    <!--        &nbsp&nbsp<i class="lni lni-facebook-messenger"></i>-->
				            
				    <!--    </p>-->
				        
				    <!--</a>-->
				    
		      	</div>
		    </div>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  	</div>
	</section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shahcement\application\resources\views/frontend/construction/index.blade.php ENDPATH**/ ?>