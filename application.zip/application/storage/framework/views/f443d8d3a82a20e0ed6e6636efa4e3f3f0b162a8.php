
<?php $__env->startSection('contents'); ?>
<?php
    use App\model\forums\JoinBlogForum;
    use App\model\SetupSite;
    $get_site_settings = SetupSite::first();
?>
<!-- CONTENT GRID -->
  <div class="content-grid" style="margin-left:2%; padding-top:7% !important;">
    <div class="row">
      <!-- Post Content Column -->
      <div class="col-lg-9" style="background-color: white;">
        
        <div class="row">
          <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if(pathinfo($key_image, PATHINFO_EXTENSION) == 'jpg' or pathinfo($key_image, PATHINFO_EXTENSION) == 'jpeg' or pathinfo($key_image, PATHINFO_EXTENSION) == 'png'or pathinfo($key_image, PATHINFO_EXTENSION) == 'gif'): ?>

          <div class="col-6">
            <img class="img-fluid rounded" src="<?php echo e(asset($key_image)); ?>" alt="">
          </div>
          <?php else: ?>

          <div class="col-12">
            <?php if($images[0]): ?>
            <video style="width: 100%;"controls style="margin-left: -14px;">
              <source src="<?php echo e(asset($images[0])); ?>" type="video/mp4">
              Your browser does not support the video tag.
            </video>
            <?php endif; ?>
          </div>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <h1 class="mt-4"><?php echo e($blog_post->post_title); ?></h1>
        <p>
          by
          <a href="#" style="color: #ed2124;font-weight: bold;"><?php echo e($blog_post->name); ?></a>
          Posted - <?php echo e(\Carbon\Carbon::parse($blog_post->updated_at)->diffForhumans()); ?>

        </p>
        <hr>
        <!-- Post Content -->
        <p class="" style="line-height: 1.5em;">
          <?php echo $blog_post->description; ?>

        </p>
        <hr>
        <!-- Comments Form -->
        <div class="card my-4">
          <h5 class="card-header">Leave a Comment:</h5>
          <div class="card-body">
            <form>
              <div class="form-group">
                <textarea class="form-control" rows="3" id="comment<?php echo e($blog_post->id); ?>" placeholder="Please Comment Here ........."></textarea>
              </div>
              <button type="button" class="btn btn-primary"  onclick="post_comment(<?php echo e($blog_post->id); ?>)">Submit</button>
            </form>
          </div>
        </div>
        <?php $__currentLoopData = $get_comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Single Comment -->
        <div class="media mb-4">
          <img class="d-flex mr-3 rounded-circle" src="<?php echo e(asset($comment->image)); ?>" alt="" style="width: 48px;height: 50px;">
          <div class="media-body">
            <h5 class="mt-0" style="color: #ed2124;font-weight: bold;"><?php echo e($comment->name); ?></h5>
            <?php echo e($comment->comment); ?>

          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="row" style="padding-bottom: 15px;" id="push_post<?php echo e($blog_post->id); ?>">
        
        </div>
      </div>
      <!-- Sidebar Widgets Column -->
      <div class="col-md-3" >
        <!-- WIDGET BOX -->
        <div class="widget-box">      
          <!-- WIDGET BOX TITLE -->
          <p class="widget-box-title">ফোরাম</p>
          <!-- /WIDGET BOX TITLE -->
      
          <!-- WIDGET BOX CONTENT -->
          <?php $__currentLoopData = $get_forum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formums): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                  $checkJoin = JoinBlogForum::where('forum_id',$formums->id)
                    ->where('user_id',Auth::user()->id)
                    ->first();
                ?>
              <div class="user-preview landscape" style="border-radius: 0px;margin-bottom: 10px;padding-left:0px;">
                  
                  <img src="<?php echo e(asset($formums->avatar)); ?>" alt="cover-08" style="width: 30px;">
                  <div class="user-preview-info">
                    <div class="user-short-description landscape tiny" style="width: 50%;">
                        <p class="user-short-description-title">
                          <a href="<?php echo e(route('blog_forums',['id'=>$formums->id])); ?>"><?php echo e($formums->title); ?></a>
                        </p>
                    </div>
                    <div class="user-preview-actions">
                        <span id="join_<?php echo e($formums->id); ?>">
                          <?php if($checkJoin): ?>
                          <?php if($checkJoin->status == '1'): ?>
                          
                          <p class="button success" onclick="leaveForum(<?php echo e($formums->id); ?>,<?php echo e($formums->type); ?>)" style="background-color:green; width:40px;height:40px;">
                              <i class="lni lni-protection"></i>
                              </p>
                          <?php elseif($checkJoin->status == '0'): ?>
                          
                          <p class="button success" onclick="leaveForum(<?php echo e($formums->id); ?>,<?php echo e($formums->type); ?>)" style="background-color:blue; width:40px;height:40px;"><i class="lni lni-spinner"></i></p>
                          <?php else: ?>
                          
                            <p class="button secondary" onclick="joinForum(<?php echo e($formums->id); ?>,<?php echo e($formums->type); ?>)"  style="width:40px; height:40px;">
                              <svg class="button-icon icon-join-group">
                                <use xlink:href="#svg-join-group"></use>
                              </svg>
                            </p>
                          <?php endif; ?>
                          <?php else: ?>
                          
                            <p class="button secondary" onclick="joinForum(<?php echo e($formums->id); ?>,<?php echo e($formums->type); ?>)" style="width:40px; height:40px;">
                              <svg class="button-icon icon-join-group">
                                <use xlink:href="#svg-join-group"></use>
                              </svg>
                            </p>
                          <?php endif; ?>
                        </span>
                    </div>
                  </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <!-- WIDGET BOX CONTENT -->
        </div>
        <!-- /WIDGET BOX -->
      </div>
    </div>
  </div>
  <!-- /CONTENT GRID -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script>
    function post_comment($post_id){
      var post_id = $post_id;
      var post_comment = $('#comment'+post_id).val();
      var user_image = '<?php echo e(Auth::user()->image); ?>';
      var user_name = '<?php echo e(Auth::user()->name); ?>';
      $('#comment'+post_id).val('');
      console.log(post_comment);
      $.ajax({
          url: "<?php echo e(url('post_comment')); ?>",
          method: "get",
          data: {post_id:post_id,post_comment:post_comment},
          success: function(data){
            if (post_comment) {

               $('#push_post'+post_id).append('<span>'+
                '<img src="<?php echo e(asset('/')); ?>'+user_image+'" style="border-radius:100px;width:48px;height:50px;margin-left: 20px;margin-right: 10px;" >'+
              '</span>'+
              '<span style="width: 80%">'+
                '<p>'+
                  '<span style="color: #ed2124;font-weight: bold;">'+user_name+'</span> <span>'+
                    post_comment+
                  '</span>'+
                '</p>'+
              '</span>');
             }else{
              alert('Please Type a comment first');
             }
          }
        });
    }

    function react_post($id,$post_id){
      var auth = <?php echo e(Auth::user()->id); ?>;
      var post_id = $post_id;
      var react_id = $id;
      if (auth) {
        $.ajax({
          url: "<?php echo e(url('react_post')); ?>",
          method: "get",
          data: {post_id:$post_id,react_id:$id},
          success: function(data){
            var count_react = $('#react'+post_id).text();
            console.log(count_react);

            $('#react'+post_id).empty();
            $('#react'+post_id).text(parseInt(count_react)+1);
            
          }
        });
      }else{
        alert('Please Login First');
      }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xobot/public_html/shahcement/application/resources/views/frontend/post_single.blade.php ENDPATH**/ ?>