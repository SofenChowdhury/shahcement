
<?php $__env->startSection('contents'); ?>
<div class="row" style="margin-top: 1%;">
    <div class="col-12">
    	<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card-box">
        	<div class="row">
        		<div class="col-10">
		            <h4 class="header-title text-center"><?php echo e($title); ?></h4>
		        </div>
		        <div class="col-2">
		            <a href="#create-modal" class="btn btn-primary waves-effect waves-light" data-animation="door" data-plugin="custommodal"data-overlaySpeed="100" data-overlayColor="#36404a" style="color: white;float: right;"><i class="fas fa-plus"></i> Create</a>
		        </div>
	        </div>
            <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                <thead>
	                <tr>
	                    <th>Image</th>
	                    <th>Name</th>
	                    <th>Email</th>
	                    <th>Phone</th>
	                    <th>Updated date</th>
	                    <th>Action</th>
	                </tr>
                </thead>
                <tbody>
                	<?php $__currentLoopData = $get_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                <tr id="user<?php echo e($user->id); ?>">
	                    <td><img src="<?php echo e(asset($user->image)); ?>" style="width: 50px;"></td>
	                    <td><?php echo e($user->name); ?></td>
	                    <td><?php echo e($user->email); ?></td>
	                    <td><?php echo e($user->phone); ?></td>
	                    <td><?php echo e(date('d M Y',strtotime($user->updated_at))); ?></td>
	                    <td>
	                    	<a href="#view-modal<?php echo e($user->id); ?>" class="btn btn-primary waves-effect waves-light" data-animation="door" data-plugin="custommodal"data-overlaySpeed="100" data-overlayColor="#36404a">
						  		<i class="far fa-eye"></i>
						  	</a>
						  	<a href="#edit-modal<?php echo e($user->id); ?>" type="button" class="btn btn-info waves-effect waves-light"  data-animation="door" data-plugin="custommodal" data-overlaySpeed="100" data-overlayColor="#36404a">
						  		<i class="far fa-edit"></i>
						  	</a>
						  	<a href="javascript:void(0);" type="button" class="btn btn-icon btn-danger btn_delete" attr="<?php echo e($user->id); ?>">
						  		<i class="far fa-trash-alt"></i>
						  	</a>
						</td>
	                </tr>
	                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>


        <!-- Modal -->
        
        <div id="create-modal" class="modal-demo">
            <button type="button" class="close" onclick="Custombox.modal.close();">
                <span>&times;</span><span class="sr-only">Close</span>
            </button>
            <h4 class="custom-modal-title">Create <?php echo e($title); ?></h4>
            <div class="text-muted">
                <form method="POST" action="<?php echo e(route('saveUser')); ?>" enctype="multipart/form-data">
		            <?php echo csrf_field(); ?>
					<div class="card m-0">
						<div class="card-body">
							<div class="row gutters">
								<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
									<div class="form-group">
										<label>Name</label>
										<input type="text" class="form-control" name="name" placeholder="User Name" required="">
									</div>
								</div>
								<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
									<div class="form-group">
										<label>Email</label>
										<input type="text" class="form-control" name="email" placeholder="User Email" required="">
									</div>
								</div>
								<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
									<div class="form-group">
										<label>Phone</label>
										<input type="text" class="form-control" name="phone" placeholder="User Phone ex. 880168.." required="">
									</div>
								</div>
								<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
									<div class="form-group">
										<label>Password</label>
										<input type="password" class="form-control" name="password" placeholder="Type your password min:8 char" required="">
									</div>
								</div>
								<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
									<div class="form-group">
										<label>Re-Password</label>
										<input type="password" class="form-control" name="re_password" placeholder="Re-type your password" required="">
									</div>
								</div>
								<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
									<div class="form-group">
										<label>Image</label>
										<input type="file" class="form-control" name="image">
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="submit" class="btn btn-primary">Save</button>
					</div>
				</form>
            </div>
        </div>

        <?php $__currentLoopData = $get_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        
	        <div id="view-modal<?php echo e($key->id); ?>" class="modal-demo">
	            <button type="button" class="close" onclick="Custombox.modal.close();">
	                <span>&times;</span><span class="sr-only">Close</span>
	            </button>
	            <h4 class="custom-modal-title"><?php echo e($key->name); ?></h4>
	            <div class="custom-modal-text text-muted">
	                To an English person, it will seem like simplified English, as a skeptical Cambridge friend of mine told me what Occidental is. The European languages are members of the same family. Their separate existence is a myth. For science, music, sport, etc, Europe uses the same vocabulary.
	            </div>
	        </div>

	        
	        <div id="edit-modal<?php echo e($key->id); ?>" class="modal-demo">
	            <button type="button" class="close" onclick="Custombox.modal.close();">
	                <span>&times;</span><span class="sr-only">Close</span>
	            </button>
	            <h4 class="custom-modal-title">Edit <?php echo e($key->name); ?></h4>
	            <div class="text-muted">
	                <form method="POST" action="<?php echo e(route('updateUser')); ?>" enctype="multipart/form-data">
			            <?php echo csrf_field(); ?>
						<div class="card m-0">
							<div class="card-body">
								<div class="row gutters">
									<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
										<div class="form-group">
											<label>Name</label>
											<input type="text" class="form-control" name="name" placeholder="User Name" required="" value="<?php echo e($key->name); ?>">
											<input type="hidden" class="form-control" name="id" value="<?php echo e($key->id); ?>">
										</div>
									</div>
									<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
										<div class="form-group">
											<label>Email</label>
											<input type="text" class="form-control" name="email" placeholder="User Email" required="" value="<?php echo e($key->email); ?>">
										</div>
									</div>
									<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
										<div class="form-group">
											<label>Phone</label>
											<input type="text" class="form-control" name="phone" placeholder="User Phone ex. 880168.." required="" value="<?php echo e($key->phone); ?>">
										</div>
									</div>
									
									<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
										<div class="form-group">
											<label>Image</label>
											<input type="file" class="form-control" name="image">
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-primary">Save</button>
						</div>
					</form>
	            </div>
	        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
	$(document).on('click', '.btn_delete',function(event){
		event.preventDefault();
		var id = $(this).attr("attr");
		Swal.fire({
		  title: 'Are you sure?',
		  text: "You won't be able to revert this!",
		  icon: 'warning',
		  showCancelButton: true,
		  confirmButtonColor: '#3085d6',
		  cancelButtonColor: '#d33',
		  confirmButtonText: 'Yes, delete it!'
		}).then((result) => {
		  if (result.value) {
		  	$('#user'+id).hide();
			$.ajax({
				url: "<?php echo e(url('/user/delete')); ?>"+'/'+id,
				success:function(result){
					Swal.fire(
				      'Deleted!',
				      'Your Image has been deleted.',
				      'success'
				    )
				}
			});
		    
		  }
		})
	});
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<style>
	#datatable-buttons_filter{
		float: right !important;
	}
</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<!-- Datatable plugin js -->
<script src="<?php echo e(asset('assets/admin/libs/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/libs/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/libs/datatables/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/libs/datatables/buttons.bootstrap4.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/admin/libs/jszip/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/libs/pdfmake/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/libs/pdfmake/vfs_fonts.js')); ?>"></script>

<script src="<?php echo e(asset('assets/admin/libs/datatables/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/libs/datatables/buttons.print.min.js')); ?>"></script>

<!-- Datatables init -->
<script src="<?php echo e(asset('assets/admin/js/pages/datatables.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/admin/users.blade.php ENDPATH**/ ?>