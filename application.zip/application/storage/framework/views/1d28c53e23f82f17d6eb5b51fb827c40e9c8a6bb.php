    <?php if(Auth::user()): ?>
    <?php echo $__env->make('frontend.includes.create_post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <style>
      .photo-preview .photo-preview-image{
        border-radius: 0px !important;
      }
    </style>
    <?php
      use App\model\blog\Comment;
    ?>
    <?php $__currentLoopData = $blog_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
      $images = explode(',',$posts->image);

      $get_poll_options = DB::table('poll_options')->where('poll_post_id',$posts->poll_id)->get();
    ?>
    <?php if($posts->post_type_id == 2): ?>
    <div class="widget-box no-padding">
      <div class="widget-box-settings">
        <div class="post-settings-wrap">
          <div class="post-settings widget-box-post-settings-dropdown-trigger">
            <svg class="post-settings-icon icon-more-dots">
              <use xlink:href="#svg-more-dots"></use>
            </svg>
          </div>
          <!-- /SIMPLE DROPDOWN LINK -->
          <div class="simple-dropdown widget-box-post-settings-dropdown">
            <p class="simple-dropdown-link">Edit Post</p>
            <p class="simple-dropdown-link">Delete Post</p>
            <p class="simple-dropdown-link">Make it Featured</p>
            <p class="simple-dropdown-link">Report Post</p>
            <p class="simple-dropdown-link">Report Author</p>
          </div>
          <!-- /SIMPLE DROPDOWN LINK -->
        </div>
      </div>
      <div class="widget-box-status">
        <div class="widget-box-status-content">
          <div class="user-status">
            <!-- USER AVATAR -->
            <a class="user-status-avatar" href="profile-timeline.html">
              <div class="user-avatar small no-outline">
                <div class="user-avatar-content">
                  <div class="hexagon-image-30-32" data-src="<?php echo e(asset($posts->user_image)); ?>"></div>
                </div>
                <div class="user-avatar-progress">
                  <div class="hexagon-progress-40-44"></div>
                </div>
                <div class="user-avatar-progress-border">
                  <div class="hexagon-border-40-44"></div>
                </div>
                <div class="user-avatar-badge">
                  <div class="user-avatar-badge-border">
                    <div class="hexagon-22-24"></div>
                  </div>
                  <div class="user-avatar-badge-content">
                    <div class="hexagon-dark-16-18"></div>
                  </div>
                  <p class="user-avatar-badge-text">26</p>
                </div>
              </div>
            </a>
            <!-- USER AVATAR -->

            <p class="user-status-title medium"><a class="bold" href="profile-timeline.html"><?php echo e($posts->name); ?></a> created a <span class="bold">poll</span></p>
            <p class="user-status-text small"><?php echo e(\Carbon\Carbon::parse($posts->updated_at)->diffForhumans()); ?></p>
          </div>
          <!-- POLL BOX -->
          <div class="poll-box">
            <p class="poll-title"><?php echo e($posts->poll_title); ?></p>
            <p class="poll-text"><?php echo e($posts->poll_sub_title); ?></p>
            <div class="form">
              <?php $__currentLoopData = $get_poll_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poll_option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="form-row">
                <div class="form-item">
                  <div class="checkbox-wrap">
                    <input type="radio" id="poll-option-<?php echo e($poll_option->id); ?>" name="poll_option" value="<?php echo e($poll_option->id); ?>">
                    <div class="checkbox-box round"></div>
                    <label for="poll-option-<?php echo e($poll_option->id); ?>"><?php echo e($poll_option->qustion); ?></label>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- /FORM -->
            <!-- POLL BOX ACTIONS -->
            <div class="poll-box-actions">
              <p class="button small secondary">Vote Now!</p>
            </div>
            <!-- /POLL BOX ACTIONS -->
          </div>
          <!-- /POLL BOX -->
  
          <!-- CONTENT ACTIONS -->
          <div class="content-actions">
            <div class="content-action">
              <div class="meta-line">
                <div class="meta-line-list reaction-item-list">
                  <div class="reaction-item">
                    <img class="reaction-image reaction-item-dropdown-trigger" src="<?php echo e(asset('assets/frontend/img/reaction/funny.png')); ?>" alt="reaction-funny">
                    <div class="simple-dropdown padded reaction-item-dropdown">
                      <p class="simple-dropdown-text"><img class="reaction" src="<?php echo e(asset('assets/frontend/img/reaction/funny.png')); ?>" alt="reaction-funny"> <span class="bold">Funny</span></p>
                      <p class="simple-dropdown-text">Matt Parker</p>
                      <p class="simple-dropdown-text">Destroy Dex</p>
                      <p class="simple-dropdown-text">The Green Goo</p>
                    </div>
                  </div>

                  <div class="reaction-item">
                    <img class="reaction-image reaction-item-dropdown-trigger" src="<?php echo e(asset('assets/frontend/img/reaction/like.png')); ?>" alt="reaction-like">
                    <div class="simple-dropdown padded reaction-item-dropdown">
                      <p class="simple-dropdown-text"><img class="reaction" src="<?php echo e(asset('assets/frontend/img/reaction/like.png')); ?>" alt="reaction-like"> <span class="bold">Like</span></p>
                      <p class="simple-dropdown-text">Sandra Strange</p>
                      <p class="simple-dropdown-text">Jane Rodgers</p>
                    </div>
                  </div>
                  <div class="reaction-item">
                    <!-- REACTION IMAGE -->
                    <img class="reaction-image reaction-item-dropdown-trigger" src="<?php echo e(asset('assets/frontend/img/reaction/love.png')); ?>" alt="reaction-love" />
                    <div class="simple-dropdown padded reaction-item-dropdown">
                      <p class="simple-dropdown-text"><img class="reaction" src="<?php echo e(asset('assets/frontend/img/reaction/love.png')); ?>" alt="reaction-love"> <span class="bold">Love</span></p>
                      <p class="simple-dropdown-text">Neko Bebop</p>
                      <p class="simple-dropdown-text">Nick Grissom</p>
                      <p class="simple-dropdown-text">Sarah Diamond</p>
                      <p class="simple-dropdown-text">Jett Spiegel</p>
                    </div>
                  </div>
                </div>
                <p class="meta-line-text">9</p>
              </div>
              <div class="meta-line">
                <div class="meta-line-list user-avatar-list">
                  <div class="user-avatar micro no-stats">
                    <div class="user-avatar-border">
                      <div class="hexagon-22-24"></div>
                    </div>
                    <div class="user-avatar-content">
                      <div class="hexagon-image-18-20" data-src="<?php echo e(asset('assets/frontend/img/avatar/09.jpg')); ?>"></div>
                    </div>
                  </div>
                  <div class="user-avatar micro no-stats">
                    <div class="user-avatar-border">
                      <div class="hexagon-22-24"></div>
                    </div>
                    <div class="user-avatar-content">
                      <div class="hexagon-image-18-20" data-src="<?php echo e(asset('assets/frontend/img/avatar/08.jpg')); ?>"></div>
                    </div>
                  </div>
                  <div class="user-avatar micro no-stats">
                    <div class="user-avatar-border">
                      <div class="hexagon-22-24"></div>
                    </div>
                    <div class="user-avatar-content">
                      <div class="hexagon-image-18-20" data-src="<?php echo e(asset('assets/frontend/img/avatar/12.jpg')); ?>"></div>
                    </div>
                  </div>
                  <div class="user-avatar micro no-stats">
                    <div class="user-avatar-border">
                      <div class="hexagon-22-24"></div>
                    </div>
                    <div class="user-avatar-content">
                      <div class="hexagon-image-18-20" data-src="<?php echo e(asset('assets/frontend/img/avatar/16.jpg')); ?>"></div>
                    </div>
                  </div>
                  <!-- /USER AVATAR -->
                </div>
                <p class="meta-line-text">11 Participants</p>
              </div>
            </div>
            <!-- /CONTENT ACTION -->
        
            <!-- CONTENT ACTION -->
            <div class="content-action">
              <div class="meta-line">
                <p class="meta-line-link">1 Comments</p>
              </div>
              <div class="meta-line">
                <p class="meta-line-text">0 Shares</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- /WIDGET BOX STATUS -->
  
      <!-- POST OPTIONS -->
      <div class="post-options">
        <div class="post-option-wrap">
          <div class="post-option reaction-options-dropdown-trigger">
            <svg class="post-option-icon icon-thumbs-up">
              <use xlink:href="#svg-thumbs-up"></use>
            </svg>
            <p class="post-option-text">React!</p>
          </div>
          <div class="reaction-options reaction-options-dropdown">
            <div class="reaction-option text-tooltip-tft" data-title="Like">
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/like.png')); ?>" alt="reaction-like">
            </div>
            <div class="reaction-option text-tooltip-tft" data-title="Love">
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/love.png')); ?>" alt="reaction-love">
            </div>
            <div class="reaction-option text-tooltip-tft" data-title="Dislike">
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/dislike.png')); ?>" alt="reaction-dislike">
            </div>
            <div class="reaction-option text-tooltip-tft" data-title="Happy">
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/happy.png')); ?>" alt="reaction-happy">
            </div>
            <div class="reaction-option text-tooltip-tft" data-title="Funny">
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/funny.png')); ?>" alt="reaction-funny">
            </div>
            <div class="reaction-option text-tooltip-tft" data-title="Wow">
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/wow.png')); ?>" alt="reaction-wow">
            </div>
            <div class="reaction-option text-tooltip-tft" data-title="Angry">
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/angry.png')); ?>" alt="reaction-angry">
            </div>
            <div class="reaction-option text-tooltip-tft" data-title="Sad">
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/sad.png')); ?>" alt="reaction-sad">
            </div>
          </div>
        </div>
        <!-- /POST OPTION WRAP -->
        <div class="post-option">
          <svg class="post-option-icon icon-comment">
            <use xlink:href="#svg-comment"></use>
          </svg>
          <p class="post-option-text">Comment</p>
        </div>
        <div class="post-option">
          <svg class="post-option-icon icon-share">
            <use xlink:href="#svg-share"></use>
          </svg>
          <p class="post-option-text">Share</p>
        </div>
      </div>
      <!--/ POST OPTIONS -->
    </div>
    <!-- /WIDGET BOX -->
    <?php elseif($posts->post_type_id == 1): ?>
    <div class="widget-box no-padding">
      <div class="widget-box-settings">
        <div class="post-settings-wrap">
          <div class="post-settings widget-box-post-settings-dropdown-trigger">
            <svg class="post-settings-icon icon-more-dots">
              <use xlink:href="#svg-more-dots"></use>
            </svg>
          </div>
          <div class="simple-dropdown widget-box-post-settings-dropdown">
            <p class="simple-dropdown-link">Edit Post</p>
            <p class="simple-dropdown-link">Delete Post</p>
            <p class="simple-dropdown-link">Make it Featured</p>
            <p class="simple-dropdown-link">Report Post</p>
            <p class="simple-dropdown-link">Report Author</p>
          </div>
        </div>
      </div>
      <div class="widget-box-status">
        <div class="widget-box-status-content">
          <div class="user-status" style="margin-bottom: 10px;">
            <a class="user-status-avatar" href="profile-timeline.html">
              <div class="user-avatar small no-outline">
                <div class="user-avatar-content">
                  <div class="hexagon-image-30-32" data-src="<?php echo e(asset($posts->user_image)); ?>"></div>
                </div>
                <div class="user-avatar-progress">
                  <div class="hexagon-progress-40-44"></div>
                </div>
                <div class="user-avatar-progress-border">
                  <div class="hexagon-border-40-44"></div>
                </div>
                <div class="user-avatar-badge">
                  <div class="user-avatar-badge-border">
                    <div class="hexagon-22-24"></div>
                  </div>
                  <div class="user-avatar-badge-content">
                    <div class="hexagon-dark-16-18"></div>
                  </div>
                  <p class="user-avatar-badge-text">19</p>
                </div>
              </div>
            </a>
            <p class="user-status-title medium"><a class="bold" href="#"><?php echo e($posts->name); ?></a> uploaded <span class="bold"><?php echo e(count($images)); ?> new photos</span></p>
            <p class="user-status-text small"><?php echo e(\Carbon\Carbon::parse($posts->updated_at)->diffForhumans()); ?></p>
          </div>
          <p class="user-status-title medium"><a class="bold" href="#" style="color: gray;"><?php echo e($posts->post_title); ?></a></p>
          <p class="widget-box-status-text"><?php echo e($posts->post_sub_title); ?></p>
          <div class="picture-collage">
            <div class="picture-collage-row medium">
              <div class="row">

                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($loop->index+1 <= 3): ?>
                  <div class="col-md-6">
                    <div class="picture-collage-item popup-picture-trigger">
                      <div class="photo-preview">
                        <figure class="photo-preview-image liquid">
                          <img src="<?php echo e(asset($key_image)); ?>" alt="photo-preview-10">
                        </figure>
                        <div class="photo-preview-info">
                          <div class="reaction-count-list">
                            <div class="reaction-count negative">
                              <svg class="reaction-count-icon icon-thumbs-up">
                                <use xlink:href="#svg-thumbs-up"></use>
                              </svg>
                              <p class="reaction-count-text">2</p>
                            </div>
                            <div class="reaction-count negative">
                              <svg class="reaction-count-icon icon-comment">
                                <use xlink:href="#svg-comment"></use>
                              </svg>
                              <p class="reaction-count-text">5</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <?php else: ?>
                    <div class="col-md-6">
                      <div class="picture-collage-item">
                        <!-- PICTURE COLLAGE ITEM OVERLAY -->
                        <a class="picture-collage-item-overlay" href="profile-photos.html">
                          <!-- PICTURE COLLAGE ITEM OVERLAY TEXT -->
                          <p class="picture-collage-item-overlay-text">+ more</p>
                          <!-- /PICTURE COLLAGE ITEM OVERLAY TEXT -->
                        </a>
                        <!-- /PICTURE COLLAGE ITEM OVERLAY -->
          
                        <!-- PHOTO PREVIEW -->
                        <div class="photo-preview">
                          <!-- PHOTO PREVIEW IMAGE -->
                          <figure class="photo-preview-image liquid">
                            <img src="<?php echo e(asset($key_image)); ?>" alt="photo-preview-14">
                          </figure>
                          <!-- /PHOTO PREVIEW IMAGE -->
                        </div>
                        <!-- /PHOTO PREVIEW -->
                      </div>
                    </div>
                    <?php
                      break;
                    ?>
                  <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </div>
            </div>
          </div>
          <!-- /PICTURE COLLAGE -->
  
          <!-- CONTENT ACTIONS -->
          <div class="content-actions">
            <div class="content-action">
              <!-- META LINE -->
              <div class="meta-line">
                <div class="meta-line-list reaction-item-list">
                  <!-- REACTION ITEM -->
                  <div class="reaction-item">
                    <!-- REACTION IMAGE -->
                    <img class="reaction-image reaction-item-dropdown-trigger" src="<?php echo e(asset('assets/frontend/img/reaction/wow.png')); ?>" alt="reaction-wow">
                    <!-- /REACTION IMAGE -->
        
                    <!-- SIMPLE DROPDOWN -->
                    <div class="simple-dropdown padded reaction-item-dropdown">
                      <!-- SIMPLE DROPDOWN TEXT -->
                      <p class="simple-dropdown-text"><img class="reaction" src="<?php echo e(asset('assets/frontend/img/reaction/wow.png')); ?>" alt="reaction-wow"> <span class="bold">Wow</span></p>
                      <!-- /SIMPLE DROPDOWN TEXT -->
                    
                      <!-- SIMPLE DROPDOWN TEXT -->
                      <p class="simple-dropdown-text">Matt Parker</p>
                      <!-- /SIMPLE DROPDOWN TEXT -->
                    </div>
                    <!-- /SIMPLE DROPDOWN -->
                  </div>
                  <!-- /REACTION ITEM -->
  
                  <!-- REACTION ITEM -->
                  <div class="reaction-item">
                    <!-- REACTION IMAGE -->
                    <img class="reaction-image reaction-item-dropdown-trigger" src="<?php echo e(asset('assets/frontend/img/reaction/like.png')); ?>" alt="reaction-like">
                    <!-- /REACTION IMAGE -->
        
                    <!-- SIMPLE DROPDOWN -->
                    <div class="simple-dropdown padded reaction-item-dropdown">
                      <!-- SIMPLE DROPDOWN TEXT -->
                      <p class="simple-dropdown-text"><img class="reaction" src="<?php echo e(asset('assets/frontend/img/reaction/like.png')); ?>" alt="reaction-like"> <span class="bold">Like</span></p>
                      <!-- /SIMPLE DROPDOWN TEXT -->
                    
                      <!-- SIMPLE DROPDOWN TEXT -->
                      <p class="simple-dropdown-text">Sandra Strange</p>
                      <!-- /SIMPLE DROPDOWN TEXT -->
  
                      <!-- SIMPLE DROPDOWN TEXT -->
                      <p class="simple-dropdown-text">Jane Rodgers</p>
                      <!-- /SIMPLE DROPDOWN TEXT -->
                    </div>
                    <!-- /SIMPLE DROPDOWN -->
                  </div>
                  <!-- /REACTION ITEM -->
                </div>
                <!-- /META LINE LIST -->
        
                <!-- META LINE TEXT -->
                <p class="meta-line-text">3</p>
                <!-- /META LINE TEXT -->
              </div>
              <!-- /META LINE -->
        
              <!-- META LINE -->
              <div class="meta-line">
                <!-- META LINE LIST -->
                <div class="meta-line-list user-avatar-list">
                  <!-- USER AVATAR -->
                  <div class="user-avatar micro no-stats">
                    <!-- USER AVATAR BORDER -->
                    <div class="user-avatar-border">
                      <!-- HEXAGON -->
                      <div class="hexagon-22-24"></div>
                      <!-- /HEXAGON -->
                    </div>
                    <!-- /USER AVATAR BORDER -->
                
                    <!-- USER AVATAR CONTENT -->
                    <div class="user-avatar-content">
                      <!-- HEXAGON -->
                      <div class="hexagon-image-18-20" data-src="<?php echo e(asset('assets/frontend/img/avatar/03.jpg')); ?>"></div>
                      <!-- /HEXAGON -->
                    </div>
                    <!-- /USER AVATAR CONTENT -->
                  </div>
                  <!-- /USER AVATAR -->
        
                  <!-- USER AVATAR -->
                  <div class="user-avatar micro no-stats">
                    <!-- USER AVATAR BORDER -->
                    <div class="user-avatar-border">
                      <!-- HEXAGON -->
                      <div class="hexagon-22-24"></div>
                      <!-- /HEXAGON -->
                    </div>
                    <!-- /USER AVATAR BORDER -->
                
                    <!-- USER AVATAR CONTENT -->
                    <div class="user-avatar-content">
                      <!-- HEXAGON -->
                      <div class="hexagon-image-18-20" data-src="<?php echo e(asset('assets/frontend/img/avatar/15.jpg')); ?>"></div>
                      <!-- /HEXAGON -->
                    </div>
                    <!-- /USER AVATAR CONTENT -->
                  </div>
                  <!-- /USER AVATAR -->
        
                  <!-- USER AVATAR -->
                  <div class="user-avatar micro no-stats">
                    <!-- USER AVATAR BORDER -->
                    <div class="user-avatar-border">
                      <!-- HEXAGON -->
                      <div class="hexagon-22-24"></div>
                      <!-- /HEXAGON -->
                    </div>
                    <!-- /USER AVATAR BORDER -->
                
                    <!-- USER AVATAR CONTENT -->
                    <div class="user-avatar-content">
                      <!-- HEXAGON -->
                      <div class="hexagon-image-18-20" data-src="<?php echo e(asset('assets/frontend/img/avatar/14.jpg')); ?>"></div>
                      <!-- /HEXAGON -->
                    </div>
                    <!-- /USER AVATAR CONTENT -->
                  </div>
                  <!-- /USER AVATAR -->
        
                  <!-- USER AVATAR -->
                  <div class="user-avatar micro no-stats">
                    <!-- USER AVATAR BORDER -->
                    <div class="user-avatar-border">
                      <!-- HEXAGON -->
                      <div class="hexagon-22-24"></div>
                      <!-- /HEXAGON -->
                    </div>
                    <!-- /USER AVATAR BORDER -->
                
                    <!-- USER AVATAR CONTENT -->
                    <div class="user-avatar-content">
                      <!-- HEXAGON -->
                      <div class="hexagon-image-18-20" data-src="<?php echo e(asset('assets/frontend/img/avatar/07.jpg')); ?>"></div>
                      <!-- /HEXAGON -->
                    </div>
                    <!-- /USER AVATAR CONTENT -->
                  </div>
                  <!-- /USER AVATAR -->
                </div>
                <!-- /META LINE LIST -->
        
                <!-- META LINE TEXT -->
                <p class="meta-line-text">4 Participants</p>
                <!-- /META LINE TEXT -->
              </div>
              <!-- /META LINE -->
            </div>
            <!-- /CONTENT ACTION -->
        
            <!-- CONTENT ACTION -->
            <div class="content-action">
              <!-- META LINE -->
              <div class="meta-line">
                <!-- META LINE LINK -->
                <p class="meta-line-link">3 Comments</p>
                <!-- /META LINE LINK -->
              </div>
              <!-- /META LINE -->
        
              <!-- META LINE -->
              <div class="meta-line">
                <!-- META LINE TEXT -->
                <p class="meta-line-text">0 Shares</p>
                <!-- /META LINE TEXT -->
              </div>
              <!-- /META LINE -->
            </div>
            <!-- /CONTENT ACTION -->
          </div>
          <!-- /CONTENT ACTIONS -->
        </div>
        <!-- /WIDGET BOX STATUS CONTENT -->
      </div>
      <!-- /WIDGET BOX STATUS -->
  
      <!-- POST OPTIONS -->
      <div class="post-options">
        <!-- POST OPTION WRAP -->
        <div class="post-option-wrap">
          <!-- POST OPTION -->
          <div class="post-option reaction-options-dropdown-trigger">
            <!-- POST OPTION ICON -->
            <svg class="post-option-icon icon-thumbs-up">
              <use xlink:href="#svg-thumbs-up"></use>
            </svg>
            <!-- /POST OPTION ICON -->
  
            <!-- POST OPTION TEXT -->
            <p class="post-option-text">React!</p>
            <!-- /POST OPTION TEXT -->
          </div>
          <!-- /POST OPTION -->
  
          <!-- REACTION OPTIONS -->
          <div class="reaction-options reaction-options-dropdown">
            <!-- REACTION OPTION -->
            <div class="reaction-option text-tooltip-tft" data-title="Like">
              <!-- REACTION OPTION IMAGE -->
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/like.png')); ?>" alt="reaction-like">
              <!-- /REACTION OPTION IMAGE -->
            </div>
            <!-- /REACTION OPTION -->
  
            <!-- REACTION OPTION -->
            <div class="reaction-option text-tooltip-tft" data-title="Love">
              <!-- REACTION OPTION IMAGE -->
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/love.png')); ?>" alt="reaction-love">
              <!-- /REACTION OPTION IMAGE -->
            </div>
            <!-- /REACTION OPTION -->
  
            <!-- REACTION OPTION -->
            <div class="reaction-option text-tooltip-tft" data-title="Dislike">
              <!-- REACTION OPTION IMAGE -->
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/dislike.png')); ?>" alt="reaction-dislike">
              <!-- /REACTION OPTION IMAGE -->
            </div>
            <!-- /REACTION OPTION -->
  
            <!-- REACTION OPTION -->
            <div class="reaction-option text-tooltip-tft" data-title="Happy">
              <!-- REACTION OPTION IMAGE -->
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/happy.png')); ?>" alt="reaction-happy">
              <!-- /REACTION OPTION IMAGE -->
            </div>
            <!-- /REACTION OPTION -->
  
            <!-- REACTION OPTION -->
            <div class="reaction-option text-tooltip-tft" data-title="Funny">
              <!-- REACTION OPTION IMAGE -->
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/funny.png')); ?>" alt="reaction-funny">
              <!-- /REACTION OPTION IMAGE -->
            </div>
            <!-- /REACTION OPTION -->
  
            <!-- REACTION OPTION -->
            <div class="reaction-option text-tooltip-tft" data-title="Wow">
              <!-- REACTION OPTION IMAGE -->
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/wow.png')); ?>" alt="reaction-wow">
              <!-- /REACTION OPTION IMAGE -->
            </div>
            <!-- /REACTION OPTION -->
  
            <!-- REACTION OPTION -->
            <div class="reaction-option text-tooltip-tft" data-title="Angry">
              <!-- REACTION OPTION IMAGE -->
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/angry.png')); ?>" alt="reaction-angry">
              <!-- /REACTION OPTION IMAGE -->
            </div>
            <!-- /REACTION OPTION -->
  
            <!-- REACTION OPTION -->
            <div class="reaction-option text-tooltip-tft" data-title="Sad">
              <!-- REACTION OPTION IMAGE -->
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/sad.png')); ?>" alt="reaction-sad">
              <!-- /REACTION OPTION IMAGE -->
            </div>
            <!-- /REACTION OPTION -->
          </div>
          <!-- /REACTION OPTIONS -->
        </div>
        <!-- /POST OPTION WRAP -->
  
        <!-- POST OPTION -->
        <div class="post-option">
          <!-- POST OPTION ICON -->
          <svg class="post-option-icon icon-comment">
            <use xlink:href="#svg-comment"></use>
          </svg>
          <!-- /POST OPTION ICON -->
  
          <!-- POST OPTION TEXT -->
          <p class="post-option-text">Comment</p>
          <!-- /POST OPTION TEXT -->
        </div>
        <!-- /POST OPTION -->
  
        <!-- POST OPTION -->
        <div class="post-option">
          <!-- POST OPTION ICON -->
          <svg class="post-option-icon icon-share">
            <use xlink:href="#svg-share"></use>
          </svg>
          <!-- /POST OPTION ICON -->
  
          <!-- POST OPTION TEXT -->
          <p class="post-option-text">Share</p>
          <!-- /POST OPTION TEXT -->
        </div>
        <!-- /POST OPTION -->
      </div>
      <!-- /POST OPTIONS -->
      

      <?php
        $get_comments = Comment::leftjoin('users','users.id','comments.user_id')
          ->where('comments.post_id',$posts->id)
          ->select('users.image','users.name','comments.*')
          ->get();
      ?>
      <?php $__currentLoopData = $get_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="row" style="padding-bottom: 15px;">
        <span>
          <img src="<?php echo e(asset($comments->image)); ?>" style="border-radius:50px;width:30px;margin-left: 20px;margin-right: 10px;" >
        </span>
        <span style="width: 80%">
          <p>
            <span style="color: #ed2124;font-weight: bold;"><?php echo e($comments->name); ?></span> <?php echo e($comments->comment); ?>

          </p>
        </span>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php if(Auth::user()): ?>
      <div class="row" style="padding-bottom: 15px;" id="push_post<?php echo e($posts->id); ?>">
        
      </div>
      <?php endif; ?>

      
      <?php if(Auth::user()): ?>
      
      <div class="row" style="padding-bottom: 15px;">
        <span>
          
          <img src="<?php echo e(Auth::user()->image); ?>" style="border-radius:50px;width:50px;margin-left: 20px;margin-right: 10px;" >
        </span>
        <span style="width: 80%">
          <textarea class="form-control" placeholder="<?php if(Auth::user()): ?><?php echo e(Auth::user()->name); ?><?php else: ?> Guest <?php endif; ?> please Comments here" name="comment" id="comment<?php echo e($posts->id); ?>"></textarea>
          <p class="btn btn-danger" id="submit_comment" onclick="post_comment(<?php echo e($posts->id); ?>)" style="float: right;border-radius: 0px; background-color: #ed2124;">Post</p>
        </span>
      </div>
      
      <?php endif; ?>
    </div>
    <!-- /WIDGET BOX -->
    <?php elseif($posts->post_type_id == 3): ?>
    <div class="widget-box no-padding">
      <div class="widget-box-settings">
        <div class="post-settings-wrap">
          <div class="post-settings widget-box-post-settings-dropdown-trigger">
            <svg class="post-settings-icon icon-more-dots">
              <use xlink:href="#svg-more-dots"></use>
            </svg>
          </div>
          <div class="simple-dropdown widget-box-post-settings-dropdown">
            <p class="simple-dropdown-link">Edit Post</p>
            <p class="simple-dropdown-link">Delete Post</p>
            <p class="simple-dropdown-link">Make it Featured</p>
            <p class="simple-dropdown-link">Report Post</p>
            <p class="simple-dropdown-link">Report Author</p>
          </div>
        </div>
      </div>
      <div class="widget-box-status">
        <div class="widget-box-status-content">
          <div class="user-status">
            <a class="user-status-avatar" href="profile-timeline.html">
              <div class="user-avatar small no-outline">
                <div class="user-avatar-content">
                  <div class="hexagon-image-30-32" data-src="<?php echo e(asset($posts->user_image)); ?>"></div>
                </div>
                <div class="user-avatar-progress">
                  <div class="hexagon-progress-40-44"></div>
                </div>
                <div class="user-avatar-progress-border">
                  <div class="hexagon-border-40-44"></div>
                </div>
                <div class="user-avatar-badge">
                  <div class="user-avatar-badge-border">
                    <div class="hexagon-22-24"></div>
                  </div>
                  <div class="user-avatar-badge-content">
                    <div class="hexagon-dark-16-18"></div>
                  </div>
                  <p class="user-avatar-badge-text">6</p>
                </div>
              </div>
            </a>
            <p class="user-status-title medium"><a class="bold" href="profile-timeline.html">Bearded Wonder</a></p>
            <p class="user-status-text small">39 minutes ago</p>
          </div>
          <p class="widget-box-status-text">Sorry everyone, but from now on, I will only be able to edit and upload one design tutorial per month. This happens because I'm having a lot on my plate right now and recording and editing the tutorials requiere a lot of attention.</p>
          <div class="content-actions">
            <div class="content-action">
              <div class="meta-line">
                <div class="meta-line-list reaction-item-list">
                  <div class="reaction-item">
                    <img class="reaction-image reaction-item-dropdown-trigger" src="<?php echo e(asset('assets/frontend/img/reaction/dislike.png')); ?>" alt="reaction-dislike">
                    <div class="simple-dropdown padded reaction-item-dropdown">
                      <p class="simple-dropdown-text"><img class="reaction" src="<?php echo e(asset('assets/frontend/img/reaction/dislike.png')); ?>" alt="reaction-dislike"> <span class="bold">Dislike</span></p>
                      <p class="simple-dropdown-text">Matt Parker</p>
                      <p class="simple-dropdown-text">Destroy Dex</p>
                      <p class="simple-dropdown-text">The Green Goo</p>
                    </div>
                  </div>
                  <div class="reaction-item">
                    <img class="reaction-image reaction-item-dropdown-trigger" src="<?php echo e(asset('assets/frontend/img/reaction/love.png')); ?>" alt="reaction-love">
                    <div class="simple-dropdown padded reaction-item-dropdown">
                      <p class="simple-dropdown-text"><img class="reaction" src="<?php echo e(asset('assets/frontend/img/reaction/love.png')); ?>" alt="reaction-love"> <span class="bold">Love</span></p>
                      <p class="simple-dropdown-text">Sandra Strange</p>
                      <p class="simple-dropdown-text">Jane Rodgers</p>
                    </div>
                  </div>
                  <div class="reaction-item">
                    <img class="reaction-image reaction-item-dropdown-trigger" src="<?php echo e(asset('assets/frontend/img/reaction/like.png')); ?>" alt="reaction-like">
                    <div class="simple-dropdown padded reaction-item-dropdown">
                      <p class="simple-dropdown-text"><img class="reaction" src="<?php echo e(asset('assets/frontend/img/reaction/like.png')); ?>" alt="reaction-like"> <span class="bold">Like</span></p>
                      <p class="simple-dropdown-text">Neko Bebop</p>
                      <p class="simple-dropdown-text">Nick Grissom</p>
                      <p class="simple-dropdown-text">Sarah Diamond</p>
                      <p class="simple-dropdown-text">Jett Spiegel</p>
                      <p class="simple-dropdown-text"><span class="bold">and 2 more...</span></p>
                    </div>
                  </div>
                </div>
                <p class="meta-line-text">11</p>
              </div>
              <div class="meta-line">
                <div class="meta-line-list user-avatar-list">
                  <div class="user-avatar micro no-stats">
                    <div class="user-avatar-border">
                      <div class="hexagon-22-24"></div>
                    </div>
                    <div class="user-avatar-content">
                      <div class="hexagon-image-18-20" data-src="<?php echo e(asset('assets/frontend/img/avatar/08.jpg')); ?>"></div>
                    </div>
                  </div>
                  <div class="user-avatar micro no-stats">
                    <div class="user-avatar-border">
                      <div class="hexagon-22-24"></div>
                    </div>
                    <div class="user-avatar-content">
                      <div class="hexagon-image-18-20" data-src="<?php echo e(asset('assets/frontend/img/avatar/11.jpg')); ?>"></div>
                    </div>
                  </div>
                  <div class="user-avatar micro no-stats">
                    <div class="user-avatar-border">
                      <div class="hexagon-22-24"></div>
                    </div>
                    <div class="user-avatar-content">
                      <!-- HEXAGON -->
                      <div class="hexagon-image-18-20" data-src="<?php echo e(asset('assets/frontend/img/avatar/06.jpg')); ?>"></div>
                      <!-- /HEXAGON -->
                    </div>
                    <!-- /USER AVATAR CONTENT -->
                  </div>
                  <!-- /USER AVATAR -->
        
                  <!-- USER AVATAR -->
                  <div class="user-avatar micro no-stats">
                    <!-- USER AVATAR BORDER -->
                    <div class="user-avatar-border">
                      <!-- HEXAGON -->
                      <div class="hexagon-22-24"></div>
                      <!-- /HEXAGON -->
                    </div>
                    <!-- /USER AVATAR BORDER -->
                
                    <!-- USER AVATAR CONTENT -->
                    <div class="user-avatar-content">
                      <!-- HEXAGON -->
                      <div class="hexagon-image-18-20" data-src="<?php echo e(asset('assets/frontend/img/avatar/07.jpg')); ?>"></div>
                      <!-- /HEXAGON -->
                    </div>
                    <!-- /USER AVATAR CONTENT -->
                  </div>
                  <!-- /USER AVATAR -->
        
                  <!-- USER AVATAR -->
                  <div class="user-avatar micro no-stats">
                    <!-- USER AVATAR BORDER -->
                    <div class="user-avatar-border">
                      <!-- HEXAGON -->
                      <div class="hexagon-22-24"></div>
                      <!-- /HEXAGON -->
                    </div>
                    <!-- /USER AVATAR BORDER -->
                
                    <!-- USER AVATAR CONTENT -->
                    <div class="user-avatar-content">
                      <!-- HEXAGON -->
                      <div class="hexagon-image-18-20" data-src="<?php echo e(asset('assets/frontend/img/avatar/10.jpg')); ?>"></div>
                      <!-- /HEXAGON -->
                    </div>
                    <!-- /USER AVATAR CONTENT -->
                  </div>
                  <!-- /USER AVATAR -->
                </div>
                <!-- /META LINE LIST -->
        
                <!-- META LINE TEXT -->
                <p class="meta-line-text">18 Participants</p>
                <!-- /META LINE TEXT -->
              </div>
              <!-- /META LINE -->
            </div>
            <!-- /CONTENT ACTION -->
        
            <!-- CONTENT ACTION -->
            <div class="content-action">
              <!-- META LINE -->
              <div class="meta-line">
                <!-- META LINE LINK -->
                <p class="meta-line-link">15 Comments</p>
                <!-- /META LINE LINK -->
              </div>
              <!-- /META LINE -->
        
              <!-- META LINE -->
              <div class="meta-line">
                <!-- META LINE TEXT -->
                <p class="meta-line-text">0 Shares</p>
                <!-- /META LINE TEXT -->
              </div>
              <!-- /META LINE -->
            </div>
            <!-- /CONTENT ACTION -->
          </div>
          <!-- /CONTENT ACTIONS -->
        </div>
        <!-- /WIDGET BOX STATUS CONTENT -->
      </div>
      <!-- /WIDGET BOX STATUS -->
  
      <!-- POST OPTIONS -->
      <div class="post-options">
        <!-- POST OPTION WRAP -->
        <div class="post-option-wrap">
          <!-- POST OPTION -->
          <div class="post-option reaction-options-dropdown-trigger">
            <!-- POST OPTION ICON -->
            <svg class="post-option-icon icon-thumbs-up">
              <use xlink:href="#svg-thumbs-up"></use>
            </svg>
            <!-- /POST OPTION ICON -->
  
            <!-- POST OPTION TEXT -->
            <p class="post-option-text">React!</p>
            <!-- /POST OPTION TEXT -->
          </div>
          <!-- /POST OPTION -->
  
          <!-- REACTION OPTIONS -->
          <div class="reaction-options reaction-options-dropdown">
            <!-- REACTION OPTION -->
            <div class="reaction-option text-tooltip-tft" data-title="Like">
              <!-- REACTION OPTION IMAGE -->
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/like.png')); ?>" alt="reaction-like">
              <!-- /REACTION OPTION IMAGE -->
            </div>
            <!-- /REACTION OPTION -->
  
            <!-- REACTION OPTION -->
            <div class="reaction-option text-tooltip-tft" data-title="Love">
              <!-- REACTION OPTION IMAGE -->
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/love.png')); ?>" alt="reaction-love">
              <!-- /REACTION OPTION IMAGE -->
            </div>
            <!-- /REACTION OPTION -->
  
            <!-- REACTION OPTION -->
            <div class="reaction-option text-tooltip-tft" data-title="Dislike">
              <!-- REACTION OPTION IMAGE -->
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/dislike.png')); ?>" alt="reaction-dislike">
              <!-- /REACTION OPTION IMAGE -->
            </div>
            <!-- /REACTION OPTION -->
  
            <!-- REACTION OPTION -->
            <div class="reaction-option text-tooltip-tft" data-title="Happy">
              <!-- REACTION OPTION IMAGE -->
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/happy.png')); ?>" alt="reaction-happy">
              <!-- /REACTION OPTION IMAGE -->
            </div>
            <!-- /REACTION OPTION -->
  
            <!-- REACTION OPTION -->
            <div class="reaction-option text-tooltip-tft" data-title="Funny">
              <!-- REACTION OPTION IMAGE -->
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/funny.png')); ?>" alt="reaction-funny">
              <!-- /REACTION OPTION IMAGE -->
            </div>
            <!-- /REACTION OPTION -->
  
            <!-- REACTION OPTION -->
            <div class="reaction-option text-tooltip-tft" data-title="Wow">
              <!-- REACTION OPTION IMAGE -->
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/wow.png')); ?>" alt="reaction-wow">
              <!-- /REACTION OPTION IMAGE -->
            </div>
            <!-- /REACTION OPTION -->
  
            <!-- REACTION OPTION -->
            <div class="reaction-option text-tooltip-tft" data-title="Angry">
              <!-- REACTION OPTION IMAGE -->
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/angry.png')); ?>" alt="reaction-angry">
              <!-- /REACTION OPTION IMAGE -->
            </div>
            <!-- /REACTION OPTION -->
  
            <!-- REACTION OPTION -->
            <div class="reaction-option text-tooltip-tft" data-title="Sad">
              <!-- REACTION OPTION IMAGE -->
              <img class="reaction-option-image" src="<?php echo e(asset('assets/frontend/img/reaction/sad.png')); ?>" alt="reaction-sad">
              <!-- /REACTION OPTION IMAGE -->
            </div>
            <!-- /REACTION OPTION -->
          </div>
          <!-- /REACTION OPTIONS -->
        </div>
        <!-- /POST OPTION WRAP -->
  
        <!-- POST OPTION -->
        <div class="post-option">
          <!-- POST OPTION ICON -->
          <svg class="post-option-icon icon-comment">
            <use xlink:href="#svg-comment"></use>
          </svg>
          <!-- /POST OPTION ICON -->
  
          <!-- POST OPTION TEXT -->
          <p class="post-option-text">Comment</p>
          <!-- /POST OPTION TEXT -->
        </div>
        <!-- /POST OPTION -->
  
        <!-- POST OPTION -->
        <div class="post-option">
          <!-- POST OPTION ICON -->
          <svg class="post-option-icon icon-share">
            <use xlink:href="#svg-share"></use>
          </svg>
          <!-- /POST OPTION ICON -->
  
          <!-- POST OPTION TEXT -->
          <p class="post-option-text">Share</p>
          <!-- /POST OPTION TEXT -->
        </div>
        <!-- /POST OPTION -->
      </div>
      <!-- /POST OPTIONS -->
    </div>
    <!-- /WIDGET BOX -->
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if(Auth::user()): ?>
    <script>
      function post_comment($post_id){
        var post_id = $post_id;
        var post_comment = $('#comment'+post_id).val();
        var user_image = '<?php echo e(Auth::user()->image); ?>';
        var user_name = '<?php echo e(Auth::user()->name); ?>';
        $('#comment'+post_id).val('');
        console.log(post_comment);
         $.ajax({
            url: "<?php echo e(url('post_comment')); ?>",
            method: "get",
            data: {post_id:post_id,post_comment:post_comment},
            success: function(data){
              if (post_comment) {

                 $('#push_post'+post_id).append('<span>'+
                  '<img src="'+user_image+'" style="border-radius:50px;width:50px;margin-left: 20px;margin-right: 10px;" >'+
                '</span>'+
                '<span style="width: 80%">'+
                  '<p>'+
                    '<span style="color: #ed2124;font-weight: bold;">'+user_name+'</span> <span>'+
                      post_comment+
                    '</span>'+
                  '</p>'+
                '</span>');
               }else{
                alert('Please Type a comment first');
               }
            }
          });
      }
    </script>
    <?php endif; ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/frontend/includes/posts.blade.php ENDPATH**/ ?>