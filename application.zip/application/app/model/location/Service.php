<?php

namespace App\model\location;

use Illuminate\Database\Eloquent\Model;

class Service extends Model
{
    //
}
