<?php

namespace App\model\location;

use Illuminate\Database\Eloquent\Model;

class Division extends Model
{
    //
}
