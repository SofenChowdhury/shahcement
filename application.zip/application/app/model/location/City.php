<?php

namespace App\model\location;

use Illuminate\Database\Eloquent\Model;

class City extends Model
{
    //
}
