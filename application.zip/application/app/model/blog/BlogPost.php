<?php

namespace App\model\blog;

use Illuminate\Database\Eloquent\Model;

class BlogPost extends Model
{
    //
}
