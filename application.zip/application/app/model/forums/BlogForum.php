<?php

namespace App\model\forums;

use Illuminate\Database\Eloquent\Model;

class BlogForum extends Model
{
    //
}
