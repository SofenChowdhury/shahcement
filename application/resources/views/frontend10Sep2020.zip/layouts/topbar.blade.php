<header class="header">
    <div class="header-actions">
      <div class="header-brand">
        <div class="logo" style="width: 150px;margin-right: 20px;padding-top: 30px;">
          <img src="https://shahcement.com/wp-content/uploads/2017/11/logo2.png" style="width: 120%;">
        </div>
        <!-- /LOGO -->
        <h1 class="header-brand-text">Nirmane Ami</h1>
      </div>

      <div class="sidemenu-trigger navigation-widget-trigger">
        <svg class="icon-grid">
          <use xlink:href="#svg-grid"></use>
        </svg>
      </div>
      <div class="mobilemenu-trigger navigation-widget-mobile-trigger">
        <div class="burger-icon inverted">
          <div class="burger-icon-bar"></div>
          <div class="burger-icon-bar"></div>
          <div class="burger-icon-bar"></div>
        </div>
      </div>

      <nav class="navigation">
        <ul class="menu-main">
          <li class="menu-main-item">
            <a class="menu-main-item-link" href="{{route('index')}}">Home</a>
          </li>
          <li class="menu-main-item">
            <a class="menu-main-item-link" href="#">Faqs</a>
          </li>
        </ul>
      </nav>
    </div>
    
      
    
    <!-- /HEADER ACTIONS -->

    <!-- HEADER ACTIONS -->
    <div class="header-actions">
      <div class="interactive-input dark" style="margin-right:10px;">
        <input type="text" id="search-main" name="search_main" placeholder="Search here for people or groups" style="color: gray;">
        <div class="interactive-input-icon-wrap">
          <svg class="interactive-input-icon icon-magnifying-glass">
            <use xlink:href="#svg-magnifying-glass"></use>
          </svg>
        </div>

        <div class="interactive-input-action">
          <svg class="interactive-input-action-icon icon-cross-thin">
            <use xlink:href="#svg-cross-thin"></use>
          </svg>
        </div>
      </div>
      <div class="action-list dark">
        <div class="action-list-item-wrap">
          <div class="action-list-item header-dropdown-trigger">
            <svg class="action-list-item-icon icon-messages">
              <use xlink:href="#svg-messages"></use>
            </svg>
          </div>

          <div class="dropdown-box header-dropdown">
            <div class="dropdown-box-header">
              <p class="dropdown-box-header-title">Messages</p>
              <div class="dropdown-box-header-actions">
                <p class="dropdown-box-header-action">Mark all as Read</p>
                <p class="dropdown-box-header-action">Settings</p>
              </div>
            </div>
            <div class="dropdown-box-list medium" data-simplebar>
              <a class="dropdown-box-list-item" href="#">
                <div class="user-status">
                  <div class="user-status-avatar">
                    <div class="user-avatar small no-outline">
                      <div class="user-avatar-content">
                        <div class="hexagon-image-30-32" data-src="{{asset('assets/frontend/img/avatar/04.jpg')}}"></div>
                      </div>
                      <div class="user-avatar-progress">
                        <div class="hexagon-progress-40-44"></div>
                      </div>
                      <div class="user-avatar-progress-border">
                        <div class="hexagon-border-40-44"></div>
                      </div>
                      <div class="user-avatar-badge">
                        <div class="user-avatar-badge-border">
                          <div class="hexagon-22-24"></div>
                        </div>
                        <div class="user-avatar-badge-content">
                          <div class="hexagon-dark-16-18"></div>
                        </div>
                        <p class="user-avatar-badge-text">6</p>
                      </div>
                    </div>
                  </div>
                  <p class="user-status-title"><span class="bold">Bearded Wonder</span></p>
                  <p class="user-status-text">Great! Then will meet with them at the party...</p>
                  <p class="user-status-timestamp floaty">29 mins ago</p>
                </div>
              </a>
              <!-- /DROPDOWN BOX LIST ITEM -->
        
              <!-- DROPDOWN BOX LIST ITEM -->
              <a class="dropdown-box-list-item" href="#">
                <div class="user-status">
                  <div class="user-status-avatar">
                    <div class="user-avatar small no-outline">
                      <div class="user-avatar-content">
                        <div class="hexagon-image-30-32" data-src="{{asset('assets/frontend/img/avatar/05.jpg')}}"></div>
                      </div>
                      <div class="user-avatar-progress">
                        <div class="hexagon-progress-40-44"></div>
                      </div>
                      <div class="user-avatar-progress-border">
                        <div class="hexagon-border-40-44"></div>
                      </div>
                      <div class="user-avatar-badge">
                        <div class="user-avatar-badge-border">
                          <div class="hexagon-22-24"></div>
                        </div>
                        <div class="user-avatar-badge-content">
                          <div class="hexagon-dark-16-18"></div>
                        </div>
                        <p class="user-avatar-badge-text">12</p>
                      </div>
                    </div>
                  </div>
                  <p class="user-status-title"><span class="bold">Neko Bebop</span></p>
                  <p class="user-status-text">Awesome! I'll see you there!</p>
                  <p class="user-status-timestamp floaty">54 mins ago</p>
                </div>
              </a>
              <!-- /DROPDOWN BOX LIST ITEM -->
              <a class="dropdown-box-list-item" href="#">
                <div class="user-status">
                  <div class="user-status-avatar">
                    <div class="user-avatar small no-outline">
                      <div class="user-avatar-content">
                        <div class="hexagon-image-30-32" data-src="{{asset('assets/frontend/img/avatar/03.jpg')}}"></div>
                      </div>
                      <div class="user-avatar-progress">
                        <div class="hexagon-progress-40-44"></div>
                      </div>
                      <div class="user-avatar-progress-border">
                        <div class="hexagon-border-40-44"></div>
                      </div>
                      <div class="user-avatar-badge">
                        <div class="user-avatar-badge-border">
                          <div class="hexagon-22-24"></div>
                        </div>
                        <div class="user-avatar-badge-content">
                          <div class="hexagon-dark-16-18"></div>
                        </div>
                        <p class="user-avatar-badge-text">16</p>
                      </div>
                    </div>
                  </div>
                  <!-- /USER STATUS AVATAR -->
                  <p class="user-status-title"><span class="bold">Nick Grissom</span></p>
                  <p class="user-status-text">Can you stream that new game?</p>
                  <p class="user-status-timestamp floaty">2 hours ago</p>
                  <!-- /USER STATUS TIMESTAMP -->
                </div>
                <!-- /USER STATUS -->
              </a>
              <!-- /DROPDOWN BOX LIST ITEM -->
        
              <!-- DROPDOWN BOX LIST ITEM -->
              <a class="dropdown-box-list-item" href="#">
                <div class="user-status">
                  <div class="user-status-avatar">
                    <div class="user-avatar small no-outline">
                      <div class="user-avatar-content">
                        <div class="hexagon-image-30-32" data-src="{{asset('assets/frontend/img/avatar/07.jpg')}}"></div>
                      </div>
                      <div class="user-avatar-progress">
                        <div class="hexagon-progress-40-44"></div>
                      </div>
                      <div class="user-avatar-progress-border">
                        <div class="hexagon-border-40-44"></div>
                      </div>
                      <div class="user-avatar-badge">
                        <div class="user-avatar-badge-border">
                          <div class="hexagon-22-24"></div>
                        </div>
                        <div class="user-avatar-badge-content">
                          <div class="hexagon-dark-16-18"></div>
                        </div>
                        <p class="user-avatar-badge-text">26</p>
                      </div>
                    </div>
                  </div>
                  <p class="user-status-title"><span class="bold">Sarah Diamond</span></p>
                  <p class="user-status-text">I'm sending you the latest news of the release...</p>
                  <p class="user-status-timestamp floaty">16 hours ago</p>
                </div>
              </a>
              <!-- /DROPDOWN BOX LIST ITEM -->
        
              <!-- DROPDOWN BOX LIST ITEM -->
              <a class="dropdown-box-list-item" href="#">
                <div class="user-status">
                  <div class="user-status-avatar">
                    <div class="user-avatar small no-outline">
                      <div class="user-avatar-content">
                        <div class="hexagon-image-30-32" data-src="{{asset('assets/frontend/img/avatar/12.jpg')}}"></div>
                      </div>
                      <div class="user-avatar-progress">
                        <div class="hexagon-progress-40-44"></div>
                      </div>
                      <div class="user-avatar-progress-border">
                        <div class="hexagon-border-40-44"></div>
                      </div>
                      <div class="user-avatar-badge">
                        <div class="user-avatar-badge-border">
                          <div class="hexagon-22-24"></div>
                        </div>
                        <div class="user-avatar-badge-content">
                          <div class="hexagon-dark-16-18"></div>
                        </div>
                        <p class="user-avatar-badge-text">10</p>
                      </div>
                    </div>
                  </div>
                  <p class="user-status-title"><span class="bold">James Murdock</span></p>
                  <p class="user-status-text">Great! Then will meet with them at the party...</p>
                  <p class="user-status-timestamp floaty">7 days ago</p>
                </div>
              </a>
              <!-- /DROPDOWN BOX LIST ITEM -->
            </div>
            <!-- /DROPDOWN BOX LIST -->
        
            <!-- DROPDOWN BOX BUTTON -->
            <a class="dropdown-box-button primary" href="#">View all Messages</a>
          </div>
          <!-- /DROPDOWN BOX -->
        </div>
        <div class="action-list-item-wrap">
          <div class="action-list-item unread header-dropdown-trigger">
            <svg class="action-list-item-icon icon-notification">
              <use xlink:href="#svg-notification"></use>
            </svg>
          </div>

          <!-- DROPDOWN BOX -->
          <div class="dropdown-box header-dropdown">
            <div class="dropdown-box-header">
              <p class="dropdown-box-header-title">Notifications</p>
              <div class="dropdown-box-header-actions">
                <p class="dropdown-box-header-action">Mark all as Read</p>
                <p class="dropdown-box-header-action">Settings</p>
              </div>
            </div>
            <div class="dropdown-box-list" data-simplebar>
              <div class="dropdown-box-list-item unread">
                <div class="user-status notification">
                  <a class="user-status-avatar" href="#">
                    <div class="user-avatar small no-outline">
                      <div class="user-avatar-content">
                        <div class="hexagon-image-30-32" data-src="{{asset('assets/frontend/img/avatar/03.jpg')}}"></div>
                      </div>
                      <div class="user-avatar-progress">
                        <div class="hexagon-progress-40-44"></div>
                      </div>
                      <div class="user-avatar-progress-border">
                        <div class="hexagon-border-40-44"></div>
                      </div>
                      <div class="user-avatar-badge">
                        <div class="user-avatar-badge-border">
                          <div class="hexagon-22-24"></div>
                        </div>
                        <div class="user-avatar-badge-content">
                          <div class="hexagon-dark-16-18"></div>
                        </div>
                        <p class="user-avatar-badge-text">16</p>
                      </div>
                    </div>
                  </a>
                  <!-- /USER STATUS AVATAR -->
                  <p class="user-status-title"><a class="bold" href="profile-timeline.html">Nick Grissom</a> posted a comment on your <a class="highlighted" href="profile-timeline.html">status update</a></p>
                  <p class="user-status-timestamp">2 minutes ago</p>
                  <div class="user-status-icon">
                    <svg class="icon-comment">
                      <use xlink:href="#svg-comment"></use>
                    </svg>
                  </div>
                </div>
              </div>
              <div class="dropdown-box-list-item">
                <div class="user-status notification">
                  <a class="user-status-avatar" href="#">
                    <div class="user-avatar small no-outline">
                      <div class="user-avatar-content">
                        <div class="hexagon-image-30-32" data-src="{{asset('assets/frontend/img/avatar/07.jpg')}}"></div>
                      </div>
                      <div class="user-avatar-progress">
                        <div class="hexagon-progress-40-44"></div>
                      </div>
                      <div class="user-avatar-progress-border">
                        <div class="hexagon-border-40-44"></div>
                      </div>
                      <div class="user-avatar-badge">
                        <div class="user-avatar-badge-border">
                          <div class="hexagon-22-24"></div>
                        </div>
                        <div class="user-avatar-badge-content">
                          <div class="hexagon-dark-16-18"></div>
                        </div>
                        <p class="user-avatar-badge-text">26</p>
                      </div>
                    </div>
                  </a>
                  <p class="user-status-title"><a class="bold" href="#">Sarah Diamond</a> left a like <img class="reaction" src="{{asset('assets/frontend/img/reaction/like.png')}}" alt="reaction-like"> reaction on your <a class="highlighted" href="#">status update</a></p>
                  <p class="user-status-timestamp">17 minutes ago</p>
                  <div class="user-status-icon">
                    <svg class="icon-thumbs-up">
                      <use xlink:href="#svg-thumbs-up"></use>
                    </svg>
                  </div>
                </div>
              </div>
              <div class="dropdown-box-list-item">
                <div class="user-status notification">
                  <a class="user-status-avatar" href="#">
                    <div class="user-avatar small no-outline">
                      <div class="user-avatar-content">
                        <div class="hexagon-image-30-32" data-src="{{asset('assets/frontend/img/avatar/02.jpg')}}"></div>
                      </div>
                      <div class="user-avatar-progress">
                        <div class="hexagon-progress-40-44"></div>
                      </div>
                      <div class="user-avatar-progress-border">
                        <div class="hexagon-border-40-44"></div>
                      </div>
                      <div class="user-avatar-badge">
                        <div class="user-avatar-badge-border">
                          <div class="hexagon-22-24"></div>
                        </div>
                        <div class="user-avatar-badge-content">
                          <div class="hexagon-dark-16-18"></div>
                        </div>
                        <p class="user-avatar-badge-text">13</p>
                      </div>
                    </div>
                  </a>
                  <p class="user-status-title"><a class="bold" href="#">Destroy Dex</a> posted a comment on your <a class="highlighted" href="#">photo</a></p>
                  <p class="user-status-timestamp">31 minutes ago</p>
                  <div class="user-status-icon">
                    <svg class="icon-comment">
                      <use xlink:href="#svg-comment"></use>
                    </svg>
                  </div>
                </div>
              </div>
              <div class="dropdown-box-list-item">
                <div class="user-status notification">
                  <a class="user-status-avatar" href="#">
                    <div class="user-avatar small no-outline">
                      <div class="user-avatar-content">
                        <div class="hexagon-image-30-32" data-src="{{asset('assets/frontend/img/avatar/10.jpg')}}"></div>
                      </div>
                      <div class="user-avatar-progress">
                        <div class="hexagon-progress-40-44"></div>
                      </div>
                      <div class="user-avatar-progress-border">
                        <div class="hexagon-border-40-44"></div>
                      </div>
                      <div class="user-avatar-badge">
                        <div class="user-avatar-badge-border">
                          <div class="hexagon-22-24"></div>
                        </div>
                        <div class="user-avatar-badge-content">
                          <div class="hexagon-dark-16-18"></div>
                        </div>
                        <p class="user-avatar-badge-text">5</p>
                      </div>
                    </div>
                  </a>

                  <p class="user-status-title"><a class="bold" href="#">The Green Goo</a> left a love <img class="reaction" src="{{asset('assets/frontend/img/reaction/love.png')}}" alt="reaction-love"> reaction on your <a class="highlighted" href="#">status update</a></p>
                  <p class="user-status-timestamp">2 hours ago</p>
                  <div class="user-status-icon">
                    <svg class="icon-thumbs-up">
                      <use xlink:href="#svg-thumbs-up"></use>
                    </svg>
                  </div>
                </div>
              </div>
            </div>
            <a class="dropdown-box-button secondary" href="#">View all Notifications</a>
          </div>
        </div>
      </div>
      <div class="action-item-wrap">
        <div class="action-item dark header-settings-dropdown-trigger">
          <svg class="action-item-icon icon-settings">
            <use xlink:href="#svg-settings"></use>
          </svg>
        </div>
        <div class="dropdown-navigation header-settings-dropdown">
          <div class="dropdown-navigation-header">
            <div class="user-status">
              <a class="user-status-avatar" href="profile-timeline.html">
                <div class="user-avatar small no-outline">
                  <div class="user-avatar-content">
                    @if(Auth::user())
                    <div class="hexagon-image-30-32" data-src="{{asset(Auth::user()->image)}}"></div>
                    @else
                    <div class="hexagon-image-30-32" data-src="{{asset('assets/frontend/img/avatar/01.jpg')}}"></div>
                    @endif
                  </div>
                  <div class="user-avatar-progress">
                    <div class="hexagon-progress-40-44"></div>
                  </div>
                  <div class="user-avatar-progress-border">
                    <div class="hexagon-border-40-44"></div>
                  </div>
                  <div class="user-avatar-badge">
                    <div class="user-avatar-badge-border">
                      <div class="hexagon-22-24"></div>
                    </div>
                    <div class="user-avatar-badge-content">
                      <div class="hexagon-dark-16-18"></div>
                    </div>
                    <p class="user-avatar-badge-text">24</p>
                  </div>
                </div>              
              </a>
              @if(Auth::user())
              <p class="user-status-title"><span class="bold">Hi {{Auth::user()->name}}!</span></p>
              <p class="user-status-text small"><a href="{{route('profile')}}">{{Auth::user()->email}}</a></p>
              @else
              <p class="user-status-title"><span class="bold">Hi Guest!</span></p>
              @endif
            </div>
          </div>
          @if(Auth::user())
          <p class="dropdown-navigation-category">My Profile</p>
          <a class="dropdown-navigation-link" href="{{route('profile')}}">Profile Info</a>
          <a class="dropdown-navigation-link" href="#">Messages</a>
          <p class="dropdown-navigation-category">Account</p>
          <a class="dropdown-navigation-link" href="#">Account Info</a>
          <a class="dropdown-navigation-link" href="#">Change Password</a>
          <a class="dropdown-navigation-link" href="#">My Posts <span class="highlighted">10</span></a>

          <a class="dropdown-navigation-button button small secondary" href="{{ route('logout') }}"
             onclick="event.preventDefault();
                      document.getElementById('logout-form').submit();">
              <i class="lni lni-lock"></i> {{ __('Logout') }}
          </a>

          <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
              @csrf
          </form>
          @else
          <p class="dropdown-navigation-category">Please Login For post</p>
          <a class="dropdown-navigation-button button small secondary" href="{{route('login')}}"><i class="lni lni-key"></i> Login </a>
          @endif
        </div>
      </div>
    </div>
  </header>