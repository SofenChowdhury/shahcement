<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from odindesign-themes.com/Blog/newsfeed.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 03 Jul 2020 15:15:23 GMT -->
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- bootstrap 4.3.1 -->
  <link rel="stylesheet" href="{{asset('assets/frontend/css/vendor/bootstrap.min.css')}}">
  <!-- styles -->
  <link rel="stylesheet" href="{{asset('assets/frontend/css/styles.min.css')}}">
  <!-- simplebar styles -->
  <link rel="stylesheet" href="{{asset('assets/frontend/css/vendor/simplebar.css')}}">
  <!-- tiny-slider styles -->
  <link rel="stylesheet" href="{{asset('assets/frontend/css/vendor/tiny-slider.css')}}">
  <!-- favicon -->
  <link rel="icon" href="https://shahcement.com/wp-content/uploads/2017/11/logo2.png">
  <link href="https://cdn.lineicons.com/2.0/LineIcons.css" rel="stylesheet">
  <title>Blog | Newsfeed</title>
</head>
<body>
<style>
  .quick-post .quick-post-header .option-items{
    border-radius: 0px !important;
  }
.progress-stat-bar canvas{
  background-color: white;
  border-radius: 10px;
}
</style>
  <!-- PAGE LOADER -->
  <div class="page-loader" style="">
    <div class="page-loader-decoration" style="background-color: transparent;">
      <img class="icon-logo" src="https://shahcement.com/wp-content/uploads/2017/11/logo2.png" style="width: 250%;height: 150%;">
    </div>
    <div class="page-loader-info">
      <p class="page-loader-info-title">Nirmaney ami Blog</p>
      <p class="page-loader-info-text">Loading...</p>
    </div>
    <!-- /PAGE LOADER INFO -->
    
    <!-- PAGE LOADER INDICATOR -->
    <div class="page-loader-indicator loader-bars">
      <div class="loader-bar"></div>
      <div class="loader-bar"></div>
      <div class="loader-bar"></div>
      <div class="loader-bar"></div>
      <div class="loader-bar"></div>
      <div class="loader-bar"></div>
      <div class="loader-bar"></div>
      <div class="loader-bar"></div>
    </div>
    <!-- /PAGE LOADER INDICATOR -->
  </div>
  <!-- /PAGE LOADER -->



  <!-- NAVIGATION WIDGET -->
  @include('layouts.sidebar-left')

  <!-- /NAVIGATION WIDGET -->
  <!-- HEADER -->
  @include('layouts.topbar')
  <!-- /HEADER -->

  <!-- FLOATY BAR -->
  <aside class="floaty-bar">
    <div class="bar-actions">
      @if(Auth::user())
      <div class="" style="padding-right:10px;">
        <a class="action-list-item" href="{{route('profile')}}">
          <img src="{{asset(Auth::user()->image)}}" style="width: 30px;border-radius: 50px;border:2px solid white;" />
        </a>
      </div>
      @endif
      <div class="action-list dark">
        <a class="action-list-item" href="{{route('e_book')}}">
          <i class="menu-item-link-icon lni lni-book" style="font-size: 22px;color: white;"></i>
        </a>

        <a class="action-list-item" href="#">
          <svg class="action-list-item-icon icon-messages">
            <use xlink:href="#svg-messages"></use>
          </svg>
        </a>

        <a class="action-list-item unread" href="#">
          <svg class="action-list-item-icon icon-notification">
            <use xlink:href="#svg-notification"></use>
          </svg>
        </a>
      </div>
      <a class="action-item-wrap" href="#">
        <div class="action-item dark">
          <svg class="action-item-icon icon-settings">
            <use xlink:href="#svg-settings"></use>
          </svg>
        </div>
      </a>
    </div>
  </aside>
  <!-- /FLOATY BAR -->

  <!-- CONTENT GRID -->
  <div class="content-grid" style="">
    <!-- GRID -->
    @yield('contents')
    <!-- /GRID -->
  </div>
  <!-- /CONTENT GRID -->
<!-- app -->
<script src="{{asset('assets/frontend/app.bundle.min.js')}}"></script>
</body>
</html>