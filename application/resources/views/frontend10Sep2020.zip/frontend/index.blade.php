@extends('layouts.frontend_layout')
@section('contents')
<div class="grid grid-3-6-3 mobile-prefer-content" style="margin-top: 75px;">
  <div class="grid-column">
    @if(Auth::user())
    <div class="widget-box">
      <div class="progress-arc-summary">
        <div class="progress-arc-wrap">
          <div class="progress-arc">
            <canvas id="profile-completion-chart"></canvas>
          </div>
          <div class="progress-arc-info">
            <img src="{{asset(Auth::user()->image)}}" style="width: 127px;height: 127px;border-radius: 100px;">
          </div>
        </div>
        <div class="progress-arc-summary-info">
          <p class="progress-arc-summary-title">{{Auth::user()->name}}</p>
          <p class="progress-arc-summary-subtitle">{{Auth::user()->email}}</p>
        </div>
      </div>
    </div>
    @endif
  </div>
  <div class="grid-column">
    @include('frontend.includes.posts')
  </div>  
  <!-- WIDGET BOX -->
    <div class="grid-column">
        <div class="widget-box">
          <p class="widget-box-title">ফোরাম</p>
          <div class="widget-box-content">
            <div class="user-status-list">
              <div class="user-status request-small">
                <a class="user-status-avatar" href="#">
                  <div class="user-avatar small no-border">
                    <div class="user-avatar-content">
                      <div class="hexagon-image-40-44" data-src="{{asset('assets/frontend/img/avatar/29.jpg')}}"></div>
                    </div>
                  </div>
                </a>
                <p class="user-status-title"><a class="bold" href="#">Twitch Streamers</a></p>
                <p class="user-status-text small">265 members</p>
                <div class="action-request-list">
                  <div class="action-request accept">
                    <svg class="action-request-icon icon-join-group">
                      <use xlink:href="#svg-join-group"></use>
                    </svg>
                  </div>
                </div>
              </div>
              <div class="user-status request-small">
                <a class="user-status-avatar" href="#">
                  <div class="user-avatar small no-border">
                    <div class="user-avatar-content">
                      <div class="hexagon-image-40-44" data-src="{{asset('assets/frontend/img/avatar/24.jpg')}}"></div>
                    </div>
                  </div>
                </a>
                <p class="user-status-title"><a class="bold" href="#">Cosplayers of the World</a></p>
                <p class="user-status-text small">139 members</p>
                <div class="action-request-list">
                  <div class="action-request accept">
                    <svg class="action-request-icon icon-join-group">
                      <use xlink:href="#svg-join-group"></use>
                    </svg>
                  </div>
                </div>
              </div>
              <div class="user-status request-small">
                <a class="user-status-avatar" href="#">
                  <div class="user-avatar small no-border">
                    <div class="user-avatar-content">
                      <div class="hexagon-image-40-44" data-src="{{asset('assets/frontend/img/avatar/25.jpg')}}"></div>
                    </div>
                  </div>
                </a>
                <p class="user-status-title"><a class="bold" href="#">Stream Designers</a></p>
                <p class="user-status-text small">466 members</p>
                <div class="action-request-list">
                  <div class="action-request accept">
                    <svg class="action-request-icon icon-join-group">
                      <use xlink:href="#svg-join-group"></use>
                    </svg>
                  </div>
                </div>
              </div>
              <div class="user-status request-small">
                <a class="user-status-avatar" href="#">
                  <div class="user-avatar small no-border">
                    <div class="user-avatar-content">
                      <div class="hexagon-image-40-44" data-src="{{asset('assets/frontend/img/avatar/28.jpg')}}"></div>
                    </div>
                  </div>
                </a>
                <p class="user-status-title"><a class="bold" href="Featured Badges">Street Artists</a></p>
                <p class="user-status-text small">951 members</p>
                <div class="action-request-list">
                  <div class="action-request decline">
                    <svg class="action-request-icon icon-leave-group">
                      <use xlink:href="#svg-leave-group"></use>
                    </svg>
                  </div>
                </div>
              </div>
              <div class="user-status request-small">
                <a class="user-status-avatar" href="#">
                  <div class="user-avatar small no-border">
                    <div class="user-avatar-content">
                      <div class="hexagon-image-40-44" data-src="{{asset('assets/frontend/img/avatar/27.jpg')}}"></div>
                    </div>
                  </div>
                </a>
                <p class="user-status-title"><a class="bold" href="#">Gaming Watchtower</a></p>
                <p class="user-status-text small">2.365 members</p>
                <div class="action-request-list">
                  <div class="action-request accept">
                    <svg class="action-request-icon icon-join-group">
                      <use xlink:href="#svg-join-group"></use>
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
</div>
@stop