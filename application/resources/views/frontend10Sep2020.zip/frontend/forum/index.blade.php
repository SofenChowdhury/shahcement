@extends('layouts.frontend_layout')
@section('contents')
<script src="{{asset('assets/frontend/app.bundle.min.js')}}"></script>
<div style="padding-left: 7%;margin-top: -30px;">
  <section class="section" style="margin-top: -40px;">
      <div class="section-header">
          <div class="section-header-info">
            <p class="section-pretitle">{{Auth::user()->name}}'s</p>
            <h2 class="section-title">Forums <span class="highlighted">1</span></h2>
          </div>
      </div>
      <div class="section-filters-bar v1" style="margin-top: 10px;margin-bottom: 10px;">
          <div class="section-filters-bar-actions">
            <form class="form">
              <div class="form-input small with-button">
                <label for="groups-search">Search Forum</label>
                <input type="text" id="groups-search" name="groups_search">
                <button class="button primary">
                  <svg class="icon-magnifying-glass">
                    <use xlink:href="#svg-magnifying-glass"></use>
                  </svg>
                </button>
              </div>
              <div class="form-select">
                <label for="groups-filter-category">Filter By</label>
                <select id="groups-filter-category" name="groups_filter_category">
                  <option value="0">Newly Created</option>
                  <option value="1">Most Members</option>
                  <option value="2">Alphabetical</option>
                </select>
                <svg class="form-select-icon icon-small-arrow">
                  <use xlink:href="#svg-small-arrow"></use>
                </svg>
              </div>
            </form>
            <div class="filter-tabs">
              <div class="filter-tab active">
                <p class="filter-tab-text">Newly Created</p>
              </div>
              <div class="filter-tab">
                <p class="filter-tab-text">Most Members</p>
              </div>
              <div class="filter-tab">
                <p class="filter-tab-text">Alphabetical</p>
              </div>
            </div>
          </div>
      </div>
      <div class="grid">
          <div class="user-preview landscape" style="border-radius: 0px;">
              <figure class="user-preview-cover liquid" style="border-radius: 0px;">
                <img src="{{asset('assets/frontend/img/cover/08.jpg')}}" alt="cover-08">
              </figure>
              <div class="user-preview-info">
                <div class="user-short-description landscape tiny">
                    <a class="user-short-description-avatar user-avatar small no-stats" href="group-timeline.html">
                      <div class="user-avatar-border">
                          <div class="hexagon-50-56"></div>
                      </div>
                      <div class="user-avatar-content">
                        <div class="hexagon-image-40-44" data-src="{{asset('assets/frontend/img/avatar/29.jpg')}}"></div>
                      </div>
                    </a>
                    <p class="user-short-description-title"><a href="group-timeline.html">Twitch Streamers</a></p>
                    <p class="user-short-description-text">Twitch gaming streamers group</p>
                </div>
                <div class="user-stats">
                    <div class="user-stat">
                      <p class="user-stat-title">265</p>
                      <p class="user-stat-text">members</p>
                    </div>
                    <div class="user-stat">
                      <p class="user-stat-title">168</p>
                      <p class="user-stat-text">posts</p>
                    </div>
                    <div class="user-stat">
                      <p class="user-stat-title">11.2k</p>
                      <p class="user-stat-text">visits</p>
                    </div>
                </div>
                <div class="user-avatar-list medium reverse centered">
                    <div class="user-avatar smaller no-stats">
                      <div class="user-avatar-border">
                        <div class="hexagon-34-36"></div>
                      </div>
                      <div class="user-avatar-content">
                        <div class="hexagon-image-30-32" data-src="{{asset('assets/frontend/img/avatar/07.jpg')}}"></div>
                      </div>
                    </div>
                    <div class="user-avatar smaller no-stats">
                      <div class="user-avatar-border">
                          <div class="hexagon-34-36"></div>
                      </div>
                      <div class="user-avatar-content">
                        <div class="hexagon-image-30-32" data-src="{{asset('assets/frontend/img/avatar/13.jpg')}}"></div>
                      </div>
                    </div>
                    <div class="user-avatar smaller no-stats">
                      <div class="user-avatar-border">
                          <div class="hexagon-34-36"></div>
                      </div>
                      <div class="user-avatar-content">
                          <div class="hexagon-image-30-32" data-src="{{asset('assets/frontend/img/avatar/08.jpg')}}"></div>
                      </div>
                    </div>
                    <div class="user-avatar smaller no-stats">
                      <div class="user-avatar-border">
                          <div class="hexagon-34-36"></div>
                      </div>
                      <div class="user-avatar-content">
                          <div class="hexagon-image-30-32" data-src="{{asset('assets/frontend/img/avatar/16.jpg')}}"></div>
                      </div>
                    </div>
                    <div class="user-avatar smaller no-stats">
                      <div class="user-avatar-border">
                          <div class="hexagon-34-36"></div>
                      </div>
                      <div class="user-avatar-content">
                          <div class="hexagon-image-30-32" data-src="{{asset('assets/frontend/img/avatar/23.jpg')}}"></div>
                      </div>
                    </div>
                    <div class="user-avatar smaller no-stats">
                      <div class="user-avatar-border">
                          <div class="hexagon-34-36"></div>
                      </div>
                      <div class="user-avatar-content">
                        <div class="hexagon-image-30-32" data-src="{{asset('assets/frontend/img/avatar/05.jpg')}}"></div>
                      </div>
                    </div>
                    <div class="user-avatar smaller no-stats">
                      <div class="user-avatar-border">
                          <div class="hexagon-34-36"></div>
                      </div>
                      <div class="user-avatar-content">
                          <div class="hexagon-image-30-32" data-src="{{asset('assets/frontend/img/avatar/03.jpg')}}"></div>
                      </div>
                    </div>
                    <div class="user-avatar smaller no-stats">
                      <div class="user-avatar-border">
                          <div class="hexagon-34-36"></div>
                      </div>
                      <div class="user-avatar-content">
                          <div class="hexagon-image-30-32" data-src="{{asset('assets/frontend/img/avatar/02.jpg')}}"></div>
                      </div>
                    </div>
                </div>
                <div class="user-preview-actions">
                    <div class="tag-sticker">
                      <svg class="tag-sticker-icon icon-private">
                        <use xlink:href="#svg-private"></use>
                      </svg>
                    </div>
                    <p class="button secondary">
                      <svg class="button-icon icon-join-group">
                        <use xlink:href="#svg-join-group"></use>
                      </svg>
                    </p>
                </div>
              </div>
          </div>
      </div>
  </section>
</div>
@stop