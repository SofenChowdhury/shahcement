<script src="{{asset('assets/frontend/app.bundle.min.js')}}"></script>
<div class="grid grid-3-6-3">
    <!-- GRID COLUMN -->
    <div class="grid-column">
      <div class="widget-box">
        <p class="widget-box-title">About Me</p>
        <div class="widget-box-content" style="margin-top: 9px;">
          <p class="paragraph"><textarea class="form-control" name="about_me"></textarea></p>
          <div class="information-line-list">
            <div class="information-line">
              	<p class="information-line-title">Joined</p>
              	<p class="information-line-text">
              		<input type="date" name="join_date" style="border:1px solid lightgray;">
              	</p>
            </div>
            <div class="information-line">
              	<p class="information-line-title">City</p>
              	<p class="information-line-text" style="width: 100%">
	              	<select class="form-control" name="city">
	              		<option value="">Select City</option>
	              		<option value="Dhaka">Dhaka</option>
	              		<option value="Comilla">Comilla</option>
	              	</select>
              	</p>
            </div>
            <div class="information-line">
              	<p class="information-line-title">Country</p>
              	<p class="information-line-text" style="width: 100%">
              		<select class="form-control" name="country">
	              		<option value="">Select City</option>
	              		<option value="Bangladesh">Bangladesh</option>
	              		<option value="India">India</option>
	              	</select>
              	</p>
            </div>
            <div class="information-line">
              	<p class="information-line-title">Web</p>
              	<p class="information-line-text">
              		<input type="text" name="website" class="form-control" style="height: 30px;" placeholder="Website Link">
              	</p>
            </div>
          </div>
        </div>
      </div>
      <div class="widget-box">
        <p class="widget-box-title">Personal Info</p>
        <div class="widget-box-content">
          <div class="information-line-list">
            <div class="information-line">
              <p class="information-line-title">Email</p>
              <p class="information-line-text">{{Auth::user()->email}}</p>
            </div>
            <div class="information-line">
              <p class="information-line-title">Birthday</p>
              <p class="information-line-text"><input type="date" name="Birthday" style="border:1px solid lightgray;"></p>
            </div>
            <div class="information-line">
              <p class="information-line-title">Occupation</p>
              <p class="information-line-text"><input type="text" name="occupation" style="border:1px solid lightgray;height: 30px;"></p>
            </div>
            <div class="information-line">
              <p class="information-line-title">Status</p>
              <p class="information-line-text">
              	<select class="form-control" name="relation_status">
              		<option value="">Select Relationship</option>
              	</select>
              </p>
            </div>
            <div class="information-line">
              <p class="information-line-title">Birthplace</p>
              <p class="information-line-text">
              	<textarea class="form-control" placeholder="Your Birthplace"></textarea>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="grid-column">
      <div class="widget-box">
      	<div class="row">
      		<div class="col-7">	
        		<p class="widget-box-title">Interests</p>
      		</div>
      		<div class="col-5">
      			<p class="btn btn-primary" style="float: right;"><i class="lni lni-add-files"></i> Add Interest</p>
      		</div>
      	</div>
        <div class="widget-box-content">
          <div class="information-block-list">
            <div class="information-block">
              	<p class="information-block-title">
              		<input type="text" name="interest_title" class="form-control" style="height: 30px;" placeholder="Your Interest Title">
              	</p>
              	<p class="information-block-text">
              		<textarea name="interest_description" class="form-control" placeholder="say Something about your Interest"></textarea>
              	</p>
            </div>
          </div>
        </div>
      </div>
      <div class="widget-box">
        <div class="row">
      		<div class="col-7">	
        		<p class="widget-box-title">Education</p>
      		</div>
      		<div class="col-5">
      			<p class="btn btn-primary" style="float: right;"><i class="lni lni-add-files"></i> Add Education</p>
      		</div>
      	</div>
        <div class="widget-box-content">
          <div class="timeline-information-list">
            <div class="timeline-information">
              <p class="timeline-information-title">
              	<label>Education Title</label>
              	<input type="text" name="education_title" class="form-control" style="height: 30px;" placeholder="Education Title">
              </p>
              <p class="timeline-information-date"><label>job Duration</label><input type="date" name="start_date" style="border:1px solid lightgray"> - <input type="date" name="end_date" style="border:1px solid lightgray"></p>
              <p class="timeline-information-date"><input type="text" name="achievement" placeholder="Achievement"></p>
              
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="grid-column">
      <div class="widget-box">
        <div class="widget-box-settings">
          <div class="post-settings-wrap">
            <div class="post-settings widget-box-post-settings-dropdown-trigger">
              <svg class="post-settings-icon icon-more-dots">
                <use xlink:href="#svg-more-dots"></use>
              </svg>
            </div>
            <div class="simple-dropdown widget-box-post-settings-dropdown">
              <p class="simple-dropdown-link">Widget Settings</p>
            </div>
          </div>
        </div>
        <p class="widget-box-title">My Latest Post</p>
        <div class="widget-box-content">
          <div class="stat-block-list">
            <div class="stat-block">
              <div class="stat-block-decoration">
                <svg class="stat-block-decoration-icon icon-friend">
                  <use xlink:href="#svg-friend"></use>
                </svg>
              </div>
              <div class="stat-block-info">
                <p class="stat-block-title">Last friend added</p>
                <p class="stat-block-text">5 Days Ago</p>
              </div>
            </div>
            <div class="stat-block">
              <div class="stat-block-decoration">
                <svg class="stat-block-decoration-icon icon-status">
                  <use xlink:href="#svg-status"></use>
                </svg>
              </div>
              <div class="stat-block-info">
                <p class="stat-block-title">Last post update</p>
                <p class="stat-block-text">1 Day Ago</p>
              </div>
            </div>
            <div class="stat-block">
              <div class="stat-block-decoration">
                <svg class="stat-block-decoration-icon icon-comment">
                  <use xlink:href="#svg-comment"></use>
                </svg>
              </div>
              <div class="stat-block-info">
                <p class="stat-block-title">Most commented post</p>
                <p class="stat-block-text">56 Comments</p>
              </div>
            </div>
            <div class="stat-block">
              <div class="stat-block-decoration">
                <svg class="stat-block-decoration-icon icon-thumbs-up">
                  <use xlink:href="#svg-thumbs-up"></use>
                </svg>
              </div>
              <div class="stat-block-info">
                <p class="stat-block-title">Most liked post</p>
                <p class="stat-block-text">904 Likes</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</div>