<script src="{{asset('assets/frontend/app.bundle.min.js')}}"></script>
<div class="grid grid-3-6-3 mobile-prefer-content">
  	<div class="grid-column">
        <div class="widget-box">
          	<div class="widget-box-settings">
	            <div class="post-settings-wrap">
	              <div class="post-settings widget-box-post-settings-dropdown-trigger">
	                <svg class="post-settings-icon icon-more-dots">
	                  <use xlink:href="#svg-more-dots"></use>
	                </svg>
	              </div>
	              <div class="simple-dropdown widget-box-post-settings-dropdown">
	                <p class="simple-dropdown-link">Widget Settings</p>
	              </div>
	            </div>
          	</div>
	      	<p class="widget-box-title">About Me</p>
	        <div class="widget-box-content">
	            <p class="paragraph">Hi! My name is Marina but some people may know me as GameHuntress! I have a Twitch channel where I stream, play and review all the newest games.</p>
	            <div class="information-line-list">
	              <div class="information-line">
	                <p class="information-line-title">Joined</p>
	                <p class="information-line-text">March 26th, 2017</p>
	              </div>
	              <div class="information-line">
	                <p class="information-line-title">City</p>
	                <p class="information-line-text">Los Angeles, California</p>
	              </div>
	              <div class="information-line">
	                <p class="information-line-title">Country</p>
	                <p class="information-line-text">United States</p>
	              </div>
	              <div class="information-line">
	                <p class="information-line-title">Age</p>
	                <p class="information-line-text">32 Years</p>
	              </div>
	              <div class="information-line">
	                <p class="information-line-title">Web</p>
	                <p class="information-line-text"><a href="#">www.gamehuntress.com</a></p>
	              </div>
	            </div>
	        </div>
	    </div>
        <div class="widget-box">
	        <div class="widget-box-settings">
	            <div class="post-settings-wrap">
	              	<div class="post-settings widget-box-post-settings-dropdown-trigger">
		                <svg class="post-settings-icon icon-more-dots">
		                  <use xlink:href="#svg-more-dots"></use>
		                </svg>
	              	</div>
	              	<div class="simple-dropdown widget-box-post-settings-dropdown">
		                <p class="simple-dropdown-link">Widget Settings</p>
	              	</div>
	            </div>
	        </div>
          	<p class="widget-box-title">Forums <span class="highlighted">82</span></p>
          	<div class="widget-box-content">
	            <div class="user-status-list">
	              	<div class="user-status request-small">
		                <a class="user-status-avatar" href="{{route('timeline')}}">
		                  <div class="user-avatar small no-outline">
		                    <div class="user-avatar-content">
		                      <div class="hexagon-image-30-32" data-src="{{asset('assets/frontend/img/avatar/07.jpg')}}"></div>
		                    </div>
		                    <div class="user-avatar-progress">
		                      <div class="hexagon-progress-40-44"></div>
		                    </div>
		                    <div class="user-avatar-progress-border">
		                      <div class="hexagon-border-40-44"></div>
		                    </div>
		                    <div class="user-avatar-badge">
		                      <div class="user-avatar-badge-border">
		                        <div class="hexagon-22-24"></div>
		                      </div>
		                      <div class="user-avatar-badge-content">
		                        <div class="hexagon-dark-16-18"></div>
		                      </div>
		                      <p class="user-avatar-badge-text">26</p>
		                    </div>
		                  </div>
		                </a>
		                <p class="user-status-title"><a class="bold" href="{{route('timeline')}}">Sarah Diamond</a></p>
		                <p class="user-status-text small">2 friends in common</p>
		                <div class="action-request-list">
		                  	<div class="action-request accept">
			                    <svg class="action-request-icon icon-add-friend">
			                      <use xlink:href="#svg-add-friend"></use>
			                    </svg>
		                  	</div>
		                </div>
	              	</div>
	              	<div class="user-status request-small">
		                <a class="user-status-avatar" href="profile-timeline.html">
		                  	<div class="user-avatar small no-outline">
			                    <div class="user-avatar-content">
			                      <div class="hexagon-image-30-32" data-src="{{asset('assets/frontend/img/avatar/03.jpg')}}"></div>
			                    </div>
			                    <div class="user-avatar-progress">
			                      <div class="hexagon-progress-40-44"></div>
			                    </div>
			                    <div class="user-avatar-progress-border">
			                      <div class="hexagon-border-40-44"></div>
			                    </div>
			                    <div class="user-avatar-badge">
			                      	<div class="user-avatar-badge-border">
			                        	<div class="hexagon-22-24"></div>
			                      	</div>
			                      	<div class="user-avatar-badge-content">
				                        <div class="hexagon-dark-16-18"></div>
			                      	</div>
			                      	<p class="user-avatar-badge-text">16</p>
			                    </div>
		                  	</div>
		                </a>
		                <p class="user-status-title"><a class="bold" href="profile-timeline.html">Nick Grissom</a></p>
		                <p class="user-status-text small">5 friends in common</p>
		                <div class="action-request-list">
		                  <div class="action-request accept">
		                    <svg class="action-request-icon icon-add-friend">
		                      <use xlink:href="#svg-add-friend"></use>
		                    </svg>
		                  </div>
		                </div>
	              	</div>
	              	<div class="user-status request-small">
		                <a class="user-status-avatar" href="profile-timeline.html">
		                  <div class="user-avatar small no-outline">
		                    <div class="user-avatar-content">
		                      <div class="hexagon-image-30-32" data-src="{{asset('assets/frontend/img/avatar/02.jpg')}}"></div>
		                    </div>
		                    <div class="user-avatar-progress">
		                      <div class="hexagon-progress-40-44"></div>
		                    </div>
		                    <div class="user-avatar-progress-border">
		                      <div class="hexagon-border-40-44"></div>
		                    </div>
		                    <div class="user-avatar-badge">
		                      <div class="user-avatar-badge-border">
		                        <div class="hexagon-22-24"></div>
		                      </div>
		                      <div class="user-avatar-badge-content">
		                        <div class="hexagon-dark-16-18"></div>
		                      </div>
		                      <p class="user-avatar-badge-text">13</p>
		                    </div>
		                  </div>
		                </a>
		                <p class="user-status-title"><a class="bold" href="profile-timeline.html">Destroy Dex</a></p>
		                <p class="user-status-text small">0 friends in common</p>
		                <div class="action-request-list">
		                  	<div class="action-request accept">
			                    <svg class="action-request-icon icon-add-friend">
			                      <use xlink:href="#svg-add-friend"></use>
			                    </svg>
		                  	</div>
		                </div>
	              	</div>
	              	<div class="user-status request-small">
		                <a class="user-status-avatar" href="profile-timeline.html">
		                  <div class="user-avatar small no-outline">
		                    <div class="user-avatar-content">
		                      <div class="hexagon-image-30-32" data-src="{{asset('assets/frontend/img/avatar/05.jpg')}}"></div>
		                    </div>
		                    <div class="user-avatar-progress">
		                      <div class="hexagon-progress-40-44"></div>
		                    </div>
		                    <div class="user-avatar-progress-border">
		                      <div class="hexagon-border-40-44"></div>
		                    </div>
		                    <div class="user-avatar-badge">
		                      <div class="user-avatar-badge-border">
		                        <div class="hexagon-22-24"></div>
		                      </div>
		                      <div class="user-avatar-badge-content">
		                        <div class="hexagon-dark-16-18"></div>
		                      </div>
		                      <p class="user-avatar-badge-text">12</p>
		                    </div>
		                  </div>
		                </a>
		                <p class="user-status-title"><a class="bold" href="profile-timeline.html">Neko Bebop</a></p>
		                <p class="user-status-text small">1 friends in common</p>
		                <div class="action-request-list">
		                  	<div class="action-request decline">
			                    <svg class="action-request-icon icon-remove-friend">
			                      <use xlink:href="#svg-remove-friend"></use>
			                    </svg>
		                  	</div>
		                </div>
	              	</div>
	            </div>
          	</div>
          	<a class="widget-box-button button small secondary" href="profile-friends.html">See all Forums</a>
        </div>
        <div class="widget-box">
          <div class="widget-box-settings">
            <div class="post-settings-wrap">
              <div class="post-settings widget-box-post-settings-dropdown-trigger">
                <svg class="post-settings-icon icon-more-dots">
                  <use xlink:href="#svg-more-dots"></use>
                </svg>
              </div>
              <div class="simple-dropdown widget-box-post-settings-dropdown">
                <p class="simple-dropdown-link">Widget Settings</p>
              </div>
            </div>
          </div>
          <p class="widget-box-title">Videos <span class="highlighted">7</span></p>
          <div class="widget-box-content">
            <div class="video-box-list">
              <div class="video-box small">
                <div class="video-box-cover popup-video-trigger">
                  <figure class="video-box-cover-image liquid">
                    <img src="{{asset('assets/frontend/img/cover/08.jpg')}}" alt="cover-08">
                  </figure>
                  <div class="play-button">
                    <svg class="play-button-icon icon-play">
                      <use xlink:href="#svg-play"></use>
                    </svg>
                  </div>
                  <div class="video-box-info">
                    <p class="video-box-title">Mochi's Island Story Mode</p>
                    <p class="video-box-text">1 hour ago</p>
                  </div>
                </div>
              </div>
              <div class="video-box small">
                <div class="video-box-cover popup-video-trigger">
                  <figure class="video-box-cover-image liquid">
                    <img src="{{asset('assets/frontend/img/cover/09.jpg')}}" alt="cover-09">
                  </figure>
                  <div class="play-button">
                    <svg class="play-button-icon icon-play">
                      <use xlink:href="#svg-play"></use>
                    </svg>
                  </div>
                  <div class="video-box-info">
                    <p class="video-box-title">Sunset Cowboys - Walkthrough</p>
                    <p class="video-box-text">3 days ago</p>
                  </div>
                </div>
              </div>
              <div class="video-box small">
                <div class="video-box-cover popup-video-trigger">
                  <figure class="video-box-cover-image liquid">
                    <img src="{{asset('assets/frontend/img/cover/05.jpg')}}" alt="cover-05">
                  </figure>
                  <div class="play-button">
                    <svg class="play-button-icon icon-play">
                      <use xlink:href="#svg-play"></use>
                    </svg>
                  </div>
                  <div class="video-box-info">
                    <p class="video-box-title">Quest of the Ogre II: The Revenge USA...</p>
                    <p class="video-box-text">5 days ago</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
  	</div>

  	{{-- Page Main Contants --}}
  	<!-- GRID COLUMN -->
  	<div class="grid-column">
	    @if(Auth::user())
	    @include('frontend.includes.create_post')
	    @endif
	    <style>
	      .photo-preview .photo-preview-image{
	        border-radius: 0px !important;
	      }
	    </style>
	    @php
	      use App\model\blog\Comment;use App\model\blog\PostReaction;
	    @endphp
    	@foreach($blog_post as $posts)
	    @php
	      $get_like = PostReaction::where('post_id',$posts->id)
	        ->where('react_id',1)
	        ->first();

	      $get_love = PostReaction::where('post_id',$posts->id)
	        ->where('react_id',2)
	        ->first();

	      $get_angry = PostReaction::where('post_id',$posts->id)
	        ->where('react_id',3)
	        ->first();
	      $get_sad = PostReaction::where('post_id',$posts->id)
	        ->where('react_id',4)
	        ->first();
	      $count_react = PostReaction::where('post_id',$posts->id)->count();
	    @endphp
	    @php
	      $images = explode(',',$posts->image);

	      $get_poll_options = DB::table('poll_options')->where('poll_post_id',$posts->poll_id)->get();
	    @endphp
	    	@if($posts->post_type_id == 2)
		    <div class="widget-box no-padding">
		      	<div class="widget-box-settings">
			        <div class="post-settings-wrap">
			          	<div class="post-settings widget-box-post-settings-dropdown-trigger">
				            <svg class="post-settings-icon icon-more-dots">
				              <use xlink:href="#svg-more-dots"></use>
				            </svg>
			          	</div>
			          	<!-- /SIMPLE DROPDOWN LINK -->
			          	<div class="simple-dropdown widget-box-post-settings-dropdown">
				            <p class="simple-dropdown-link">Edit Post</p>
				            <p class="simple-dropdown-link">Delete Post</p>
				            <p class="simple-dropdown-link">Make it Featured</p>
				            <p class="simple-dropdown-link">Report Post</p>
				            <p class="simple-dropdown-link">Report Author</p>
			          	</div>
			          	<!-- /SIMPLE DROPDOWN LINK -->
			        </div>
		      	</div>
		      	<div class="widget-box-status">
			        <div class="widget-box-status-content">
			          	<div class="user-status">
				            <!-- USER AVATAR -->
				            <a class="user-status-avatar" href="{{route('profile')}}">
				              	<div class="user-avatar small no-outline">
					                <div class="user-avatar-content">
					                  	<div class="hexagon-image-30-32" data-src="{{asset($posts->user_image)}}"></div>
					                </div>
					                <div class="user-avatar-progress">
					                  <div class="hexagon-progress-40-44"></div>
					                </div>
					                <div class="user-avatar-progress-border">
					                  <div class="hexagon-border-40-44"></div>
					                </div>
					                <div class="user-avatar-badge">
					                  <div class="user-avatar-badge-border">
					                    <div class="hexagon-22-24"></div>
					                  </div>
					                  <div class="user-avatar-badge-content">
					                    <div class="hexagon-dark-16-18"></div>
					                  </div>
					                  <p class="user-avatar-badge-text">26</p>
					                </div>
				              	</div>
				            </a>
				            <!-- USER AVATAR -->

				            <p class="user-status-title medium"><a class="bold" href="profile-timeline.html">{{$posts->name}}</a> created a <span class="bold">poll</span></p>
				            <p class="user-status-text small">{{ \Carbon\Carbon::parse($posts->updated_at)->diffForhumans() }}</p>
			          	</div>
			          <!-- POLL BOX -->
			          	<div class="poll-box">
				            <p class="poll-title">{{$posts->poll_title}}</p>
				            <p class="poll-text">{{$posts->poll_sub_title}}</p>
				            <div class="form">
				              	@foreach($get_poll_options as $poll_option)
				              	<div class="form-row">
					                <div class="form-item">
					                  	<div class="checkbox-wrap">
					                    	<input type="radio" id="poll-option-{{$poll_option->id}}" name="poll_option" value="{{$poll_option->id}}">
					                    	<div class="checkbox-box round"></div>
					                    	<label for="poll-option-{{$poll_option->id}}">{{$poll_option->qustion}}</label>
					                  	</div>
					                </div>
				              	</div>
				              	@endforeach
				            </div>
				            <!-- /FORM -->
				            <!-- POLL BOX ACTIONS -->
				            <div class="poll-box-actions">
				              	<p class="button small secondary">Vote Now!</p>
				            </div>
				            <!-- /POLL BOX ACTIONS -->
			          	</div>
			          <!-- /POLL BOX -->
			  
			          <!-- CONTENT ACTIONS -->
			          	<div class="content-actions">
				            <div class="content-action">
				              <div class="meta-line">
				                <div class="meta-line-list reaction-item-list">
				                  @if($get_angry)
				                  <!-- REACTION ITEM -->
				                  <div class="reaction-item" id="react{{$posts->id}}3">
				                    <!-- REACTION IMAGE -->
				                    <img class="reaction-image reaction-item-dropdown-trigger" src="{{asset('assets/frontend/img/reaction/angry.png')}}" alt="reaction-angry">
				                    <!-- /REACTION IMAGE -->
				                  </div>
				                  <!-- /REACTION ITEM -->
				                  @endif
				                  @if($get_sad)
				                  <!-- REACTION ITEM -->
				                  <div class="reaction-item" id="react{{$posts->id}}4">
				                    <!-- REACTION IMAGE -->
				                    <img class="reaction-image reaction-item-dropdown-trigger" src="{{asset('assets/frontend/img/reaction/sad.png')}}" alt="reaction-sad">
				                    <!-- /REACTION IMAGE -->
				                  </div>
				                  <!-- /REACTION ITEM -->
				                  @endif
				                  @if($get_love)
				                  <!-- REACTION ITEM -->
				                  <div class="reaction-item" id="react{{$posts->id}}2">
				                    <!-- REACTION IMAGE -->
				                    <img class="reaction-image reaction-item-dropdown-trigger" src="{{asset('assets/frontend/img/reaction/love.png')}}" alt="reaction-wow">
				                    <!-- /REACTION IMAGE -->
				                  </div>
				                  <!-- /REACTION ITEM -->
				                  @endif
				                  @if($get_like)
				                  <!-- REACTION ITEM -->
				                  <div class="reaction-item" id="react{{$posts->id}}1">
				                    <!-- REACTION IMAGE -->
				                    <img class="reaction-image reaction-item-dropdown-trigger" src="{{asset('assets/frontend/img/reaction/like.png')}}" alt="reaction-like">
				                    <!-- /REACTION IMAGE -->
				                  </div>
				                  <!-- /REACTION ITEM -->
				                  @endif
				                </div>
				                <p class="meta-line-text">{{$count_react}}</p>
				              </div>
				              <div class="meta-line">
				                <div class="meta-line-list user-avatar-list">
				                  <div class="user-avatar micro no-stats">
				                    <div class="user-avatar-border">
				                      <div class="hexagon-22-24"></div>
				                    </div>
				                    <div class="user-avatar-content">
				                      <div class="hexagon-image-18-20" data-src="{{asset('assets/frontend/img/avatar/09.jpg')}}"></div>
				                    </div>
				                  </div>
				                  <div class="user-avatar micro no-stats">
				                    <div class="user-avatar-border">
				                      <div class="hexagon-22-24"></div>
				                    </div>
				                    <div class="user-avatar-content">
				                      <div class="hexagon-image-18-20" data-src="{{asset('assets/frontend/img/avatar/08.jpg')}}"></div>
				                    </div>
				                  </div>
				                  <div class="user-avatar micro no-stats">
				                    <div class="user-avatar-border">
				                      <div class="hexagon-22-24"></div>
				                    </div>
				                    <div class="user-avatar-content">
				                      <div class="hexagon-image-18-20" data-src="{{asset('assets/frontend/img/avatar/12.jpg')}}"></div>
				                    </div>
				                  </div>
				                  <div class="user-avatar micro no-stats">
				                    <div class="user-avatar-border">
				                      <div class="hexagon-22-24"></div>
				                    </div>
				                    <div class="user-avatar-content">
				                      <div class="hexagon-image-18-20" data-src="{{asset('assets/frontend/img/avatar/16.jpg')}}"></div>
				                    </div>
				                  </div>
				                  <!-- /USER AVATAR -->
				                </div>
				                <p class="meta-line-text">11 Participants</p>
				              </div>
				            </div>
				            <!-- /CONTENT ACTION -->
				        
				            <!-- CONTENT ACTION -->
				            <div class="content-action">
				              	<div class="meta-line">
				                	<p class="meta-line-link">1 Comments</p>
				              	</div>
				              	<div class="meta-line">
				                	<p class="meta-line-text">0 Shares</p>
				              	</div>
				            </div>
			          	</div>
			        </div>
		      	</div>
		      <!-- /WIDGET BOX STATUS -->
		  
		      <!-- POST OPTIONS -->
		      	<div class="post-options">
			        <div class="post-option-wrap">
			          	<div class="post-option reaction-options-dropdown-trigger">
				            <svg class="post-option-icon icon-thumbs-up">
				              <use xlink:href="#svg-thumbs-up"></use>
				            </svg>
			            	<p class="post-option-text">React!</p>
			          	</div>
			          	<div class="reaction-options reaction-options-dropdown">
				            <div class="reaction-options reaction-options-dropdown">
				              	<div class="reaction-option text-tooltip-tft" data-title="Like">
				                	<img class="reaction-option-image" src="{{asset('assets/frontend/img/reaction/like.png')}}" alt="reaction-like" onclick="react_post(1,{{$posts->id}})">
				              	</div>
				              	{{-- <div class="reaction-option text-tooltip-tft" data-title="Love">
				                	<img class="reaction-option-image" src="{{asset('assets/frontend/img/reaction/love.png')}}" alt="reaction-love" onclick="react_post(2,{{$posts->id}})">
				              	</div>
				              	<div class="reaction-option text-tooltip-tft" data-title="Angry">
				                	<img class="reaction-option-image" src="{{asset('assets/frontend/img/reaction/angry.png')}}" alt="reaction-angry" onclick="react_post(3,{{$posts->id}})">
				              	</div>
				              	<div class="reaction-option text-tooltip-tft" data-title="Sad">
				                	<img class="reaction-option-image" src="{{asset('assets/frontend/img/reaction/sad.png')}}" alt="reaction-sad" onclick="react_post(4,{{$posts->id}})">
				              	</div> --}}
				            </div>
			          	</div>
			        </div>
			        <!-- /POST OPTION WRAP -->
			        <div class="post-option">
			          	<svg class="post-option-icon icon-comment">
			            	<use xlink:href="#svg-comment"></use>
			          	</svg>
			          	<p class="post-option-text">Comment</p>
			        </div>
			        <div class="post-option">
			          	<div class="post-option reaction-options-dropdown-trigger">
			            <svg class="post-option-icon icon-share">
			              <use xlink:href="#svg-share"></use>
			            </svg>
			            <p class="post-option-text">Share!</p>
			          </div>
			          <div class="reaction-options reaction-options-dropdown" style="box-shadow: none;background-color:transparent;">
			            <div class="reaction-option text-tooltip-tft" data-title="Share Facebook">
			              <img class="reaction-option-image" src="https://banner2.cleanpng.com/20180410/grq/kisspng-computer-icons-facebook-gulf-dentex-2018-social-me-social-media-icon-5acc9ad62072e6.9153031115233584221329.jpg" alt="reaction-like" onclick="react_post(1,{{$posts->id}})" style="border-radius: 50px;">
			            </div>
			          </div>
			        </div>
		      	</div>
		      <!--/ POST OPTIONS -->
		    </div>
		    <!-- /WIDGET BOX -->
	    	@elseif($posts->post_type_id == 1)
		    <div class="widget-box no-padding">
		      	<div class="widget-box-settings">
			        <div class="post-settings-wrap">
			          	<div class="post-settings widget-box-post-settings-dropdown-trigger">
				            <svg class="post-settings-icon icon-more-dots">
				              <use xlink:href="#svg-more-dots"></use>
				            </svg>
			          	</div>
			          	<div class="simple-dropdown widget-box-post-settings-dropdown">
				            <p class="simple-dropdown-link">Edit Post</p>
				            <p class="simple-dropdown-link">Delete Post</p>
				            <p class="simple-dropdown-link">Make it Featured</p>
				            <p class="simple-dropdown-link">Report Post</p>
				            <p class="simple-dropdown-link">Report Author</p>
			          	</div>
			        </div>
		      	</div>
		      	<div class="widget-box-status">
		        <div class="widget-box-status-content">
		          	<div class="user-status" style="margin-bottom: 10px;">
			            <a class="user-status-avatar" href="profile-timeline.html">
			              	<div class="user-avatar small no-outline">
				                <div class="user-avatar-content">
				                  	<div class="hexagon-image-30-32" data-src="{{asset($posts->user_image)}}"></div>
				                </div>
				                <div class="user-avatar-progress">
				                  	<div class="hexagon-progress-40-44"></div>
				                </div>
				                <div class="user-avatar-progress-border">
				                  	<div class="hexagon-border-40-44"></div>
				                </div>
				                <div class="user-avatar-badge">
				                  	<div class="user-avatar-badge-border">
				                    	<div class="hexagon-22-24"></div>
				                  	</div>
				                  	<div class="user-avatar-badge-content">
				                    	<div class="hexagon-dark-16-18"></div>
				                  	</div>
				                  	<p class="user-avatar-badge-text">19</p>
				                </div>
			              	</div>
			            </a>
			            <p class="user-status-title medium"><a class="bold" href="#">{{$posts->name}}</a> uploaded <span class="bold">{{count($images)}} new photos</span></p>
			            <p class="user-status-text small">{{ \Carbon\Carbon::parse($posts->updated_at)->diffForhumans() }}</p>
		          	</div>
		          	<p class="user-status-title medium"><a class="bold" href="#" style="color: gray;">{{$posts->post_title}}</a></p>
		          	<p class="widget-box-status-text">{{$posts->post_sub_title}}</p>
		          	<div class="picture-collage">
			            <div class="picture-collage-row medium">
			              	<div class="row">
				                @foreach($images as $key_image)
				                  	@if($loop->index+1 <= 3)
					                  	@if (pathinfo($key_image, PATHINFO_EXTENSION) == 'jpg' or pathinfo($key_image, PATHINFO_EXTENSION) == 'jpeg' or pathinfo($key_image, PATHINFO_EXTENSION) == 'png')
					                  	<div class="col-md-6">
						                    <div class="picture-collage-item popup-picture-trigger">
						                      	<div class="photo-preview">
							                        <figure class="photo-preview-image liquid" style="margin-left: -14px;">
							                          <img src="{{asset($key_image)}}" alt="photo-preview-10">
							                        </figure>
							                        <div class="photo-preview-info" style="margin-left: -14px;">
							                          	<div class="reaction-count-list">
								                            <div class="reaction-count negative">
								                              	<i class="lni lni-eye" style="color: white;"></i>
								                              	<p class="reaction-count-text"></p>
								                            </div>
							                          	</div>
							                        </div>
						                      	</div>
						                    </div>
					                  	</div>
					                  	@else
					                  	<div class="col-md-6">
						                    <video width="100%" style="width: 111.5%;"controls style="margin-left: -14px;">
						                      	<source src="{{asset($key_image)}}" type="video/mp4">
						                    	Your browser does not support the video tag.
						                    </video>
					                  	</div>
					                  	@endif
					                  	@else
					                    <div class="col-md-6">
					                      	<div class="picture-collage-item">
						                        <a class="picture-collage-item-overlay" href="profile-photos.html" style="margin-left: -14px;">
						                          	<p class="picture-collage-item-overlay-text">+ more</p>
						                        </a>
						                        <div class="photo-preview" style="margin-left: -14px;">
						                          	<figure class="photo-preview-image liquid">
						                            	<img src="{{asset($key_image)}}" alt="photo-preview-14">
						                          	</figure>
						                        </div>
					                      	</div>
					                    </div>
					                    @php
					                      break;
					                    @endphp
				                  	@endif
				                @endforeach
			              	</div>
			            </div>
		          	</div>
		          	<!-- /PICTURE COLLAGE -->
		  
		          	<!-- CONTENT ACTIONS -->
		          	<div class="content-actions">
			            <div class="content-action">
			              	<div class="meta-line">
				                <div class="meta-line-list reaction-item-list">
				                  	@if($get_angry)
					                  	<div class="reaction-item">
					                    	<img class="reaction-image reaction-item-dropdown-trigger" src="{{asset('assets/frontend/img/reaction/angry.png')}}" alt="reaction-angry">
					                  	</div>
				                  	@endif
				                  	@if($get_sad)
					                  	<div class="reaction-item">
					                    	<img class="reaction-image reaction-item-dropdown-trigger" src="{{asset('assets/frontend/img/reaction/sad.png')}}" alt="reaction-sad">
					                  	</div>
				                  	@endif
				                  	@if($get_love)
					                  	<div class="reaction-item">
					                    	<img class="reaction-image reaction-item-dropdown-trigger" src="{{asset('assets/frontend/img/reaction/love.png')}}" alt="reaction-love">
					                  	</div>
				                  	@endif
				                  	@if($get_like)
					                  	<div class="reaction-item">
					                    	<img class="reaction-image reaction-item-dropdown-trigger" src="{{asset('assets/frontend/img/reaction/like.png')}}" alt="reaction-like" >
					                  	</div>
				                  	@endif
				                  	<div class="" id="react{{$posts->id}}"></div>
				                </div>
				                <p class="meta-line-text" id="count_react">{{$count_react}}</p>
			              	</div>
			              	<div class="meta-line">
				                <div class="meta-line-list user-avatar-list">
				                  	<div class="user-avatar micro no-stats">
					                    <div class="user-avatar-border">
					                      	<div class="hexagon-22-24"></div>
					                    </div> 
					                    <div class="user-avatar-content">
					                      <div class="hexagon-image-18-20" data-src="{{asset('assets/frontend/img/avatar/03.jpg')}}"></div>
					                    </div>
				                  	</div>
				                  	<div class="user-avatar micro no-stats">
					                    <div class="user-avatar-border">
					                      	<div class="hexagon-22-24"></div>
					                    </div>
					                    <div class="user-avatar-content">
					                      	<div class="hexagon-image-18-20" data-src="{{asset('assets/frontend/img/avatar/15.jpg')}}"></div>
					                    </div>
				                  	</div>
				                  	<div class="user-avatar micro no-stats">
					                    <div class="user-avatar-border">
					                      	<div class="hexagon-22-24"></div>
					                    </div>
					                    <div class="user-avatar-content">
					                      	<div class="hexagon-image-18-20" data-src="{{asset('assets/frontend/img/avatar/14.jpg')}}"></div>
					                    </div>
				                  	</div>
				                  	<div class="user-avatar micro no-stats">
					                    <div class="user-avatar-border">
					                      	<div class="hexagon-22-24"></div>
					                    </div>
					                    <div class="user-avatar-content">
					                      	<div class="hexagon-image-18-20" data-src="{{asset('assets/frontend/img/avatar/07.jpg')}}"></div>
					                    </div>
				                  	</div>
				                </div>
				                <p class="meta-line-text">4 Participants</p>
			              	</div>
			            </div>
			            <div class="content-action">
			              	<div class="meta-line">
				                <p class="meta-line-link">3 Comments</p>
			              	</div>
			              	<div class="meta-line">
				                <p class="meta-line-text">0 Shares</p>
			              	</div>
			            </div>
		          	</div>
		        </div>
		      	</div>
		      	<div class="post-options">
			        <div class="post-option-wrap">
			          	<div class="post-option reaction-options-dropdown-trigger">
				            <svg class="post-option-icon icon-thumbs-up">
				              <use xlink:href="#svg-thumbs-up"></use>
				            </svg>
				            <p class="post-option-text">React!</p>
			          	</div>
			          	<div class="reaction-options reaction-options-dropdown">
				            <div class="reaction-option text-tooltip-tft" data-title="Like">
				              	<img class="reaction-option-image" src="{{asset('assets/frontend/img/reaction/like.png')}}" alt="reaction-like" onclick="react_post(1,{{$posts->id}})">
				            </div>
				            {{-- <div class="reaction-option text-tooltip-tft" data-title="Love">
				              	<img class="reaction-option-image" src="{{asset('assets/frontend/img/reaction/love.png')}}" alt="reaction-love" onclick="react_post(2,{{$posts->id}})">
				            </div>
				            <div class="reaction-option text-tooltip-tft" data-title="Angry">
				              	<img class="reaction-option-image" src="{{asset('assets/frontend/img/reaction/angry.png')}}" alt="reaction-angry" onclick="react_post(3,{{$posts->id}})">
				            </div>
				            <div class="reaction-option text-tooltip-tft" data-title="Sad">
				              	<img class="reaction-option-image" src="{{asset('assets/frontend/img/reaction/sad.png')}}" alt="reaction-sad" onclick="react_post(4,{{$posts->id}})">
				            </div> --}}
			          	</div>
			        </div>
			        <!-- POST OPTION -->
			        <div class="post-option">
			          <svg class="post-option-icon icon-comment">
			            <use xlink:href="#svg-comment"></use>
			          </svg>
			          <p class="post-option-text">Comment</p>
			        </div>
			        <div class="post-option">
			          	<div class="post-option reaction-options-dropdown-trigger">
				            <svg class="post-option-icon icon-share">
				              <use xlink:href="#svg-share"></use>
				            </svg>
				            <p class="post-option-text">Share!</p>
				        </div>
				        <div class="reaction-options reaction-options-dropdown" style="box-shadow: none;background-color:transparent;">
				            <div class="reaction-option text-tooltip-tft" data-title="Share Facebook">
				              <img class="reaction-option-image" src="https://banner2.cleanpng.com/20180410/grq/kisspng-computer-icons-facebook-gulf-dentex-2018-social-me-social-media-icon-5acc9ad62072e6.9153031115233584221329.jpg" alt="reaction-like" onclick="react_post(1,{{$posts->id}})" style="border-radius: 50px;">
				            </div>
				         </div>
			        </div>
		      	</div>
		      	<!-- /POST OPTIONS -->
		      {{-- Comment part Start --}}
		      	@php
			        $get_comments = Comment::leftjoin('users','users.id','comments.user_id')
			          ->where('comments.post_id',$posts->id)
			          ->select('users.image','users.name','comments.*')
			          ->get();
		      	@endphp
		      	@foreach($get_comments as $comments)
			      	<div class="row" style="padding-bottom: 15px;">
				        <span>
				          	<img src="{{asset($comments->image)}}" style="border-radius:50px;width:30px;margin-left: 20px;margin-right: 10px;" >
				        </span>
				        <span style="width: 80%">
				          	<p>
				            	<span style="color: #ed2124;font-weight: bold;">{{$comments->name}}</span> {{$comments->comment}}
				          	</p>
				        </span>
			      	</div>
		      	@endforeach
		      	@if(Auth::user())
		      		<div class="row" style="padding-bottom: 15px;" id="push_post{{$posts->id}}"></div>
		      	@endif

		      	{{-- Comment part End --}}
		      	@if(Auth::user())
			      	{{-- Comment Post part Start --}}
			      	<div class="row" style="padding-bottom: 15px;">
				        <span>
				          
				          	<img src="{{Auth::user()->image}}" style="border-radius:50px;width:50px;margin-left: 20px;margin-right: 10px;" >
				        </span>
				        <span style="width: 80%">
				          	<textarea class="form-control" placeholder="@if(Auth::user()){{Auth::user()->name}}@else Guest @endif please Comments here" name="comment" id="comment{{$posts->id}}"></textarea>
				          	<p class="btn btn-danger" id="submit_comment" onclick="post_comment({{$posts->id}})" style="float: right;border-radius: 0px; background-color: #ed2124;">Post</p>
				        </span>
			      	</div>
			      	{{-- Comment Post part End --}}
		      	@endif
		    </div>
		    <!-- /WIDGET BOX -->
		    @elseif($posts->post_type_id == 3)
		    <div class="widget-box no-padding">
		      	<div class="widget-box-settings">
			        <div class="post-settings-wrap">
			          	<div class="post-settings widget-box-post-settings-dropdown-trigger">
				            <svg class="post-settings-icon icon-more-dots">
				              	<use xlink:href="#svg-more-dots"></use>
				            </svg>
			          	</div>
			          	<div class="simple-dropdown widget-box-post-settings-dropdown">
				            <p class="simple-dropdown-link">Edit Post</p>
				            <p class="simple-dropdown-link">Delete Post</p>
				            <p class="simple-dropdown-link">Make it Featured</p>
				            <p class="simple-dropdown-link">Report Post</p>
				            <p class="simple-dropdown-link">Report Author</p>
			          	</div>
			        </div>
		      	</div>
		      	<div class="widget-box-status">
			        <div class="widget-box-status-content">
			          	<div class="user-status">
				            <a class="user-status-avatar" href="profile-timeline.html">
				              	<div class="user-avatar small no-outline">
					                <div class="user-avatar-content">
					                  	<div class="hexagon-image-30-32" data-src="{{asset($posts->user_image)}}"></div>
					                </div>
					                <div class="user-avatar-progress">
					                  	<div class="hexagon-progress-40-44"></div>
					                </div>
					                <div class="user-avatar-progress-border">
					                  	<div class="hexagon-border-40-44"></div>
					                </div>
					                <div class="user-avatar-badge">
					                  	<div class="user-avatar-badge-border">
					                    	<div class="hexagon-22-24"></div>
					                  	</div>
					                  	<div class="user-avatar-badge-content">
					                    	<div class="hexagon-dark-16-18"></div>
					                  	</div>
					                  	<p class="user-avatar-badge-text">6</p>
					                </div>
				              	</div>
				            </a>
				            <p class="user-status-title medium"><a class="bold" href="profile-timeline.html">Bearded Wonder</a></p>
				            <p class="user-status-text small">39 minutes ago</p>
			          	</div>
			          	<p class="widget-box-status-text">Sorry everyone, but from now on, I will only be able to edit and upload one design tutorial per month. This happens because I'm having a lot on my plate right now and recording and editing the tutorials requiere a lot of attention.</p>
			          <div class="content-actions">
			            <div class="content-action">
			              	<div class="meta-line">
				                <div class="meta-line-list reaction-item-list">
				                  	<div class="reaction-item">
				                    	<img class="reaction-image reaction-item-dropdown-trigger" src="{{asset('assets/frontend/img/reaction/dislike.png')}}" alt="reaction-dislike">
					                    <div class="simple-dropdown padded reaction-item-dropdown">
					                      	<p class="simple-dropdown-text"><img class="reaction" src="{{asset('assets/frontend/img/reaction/dislike.png')}}" alt="reaction-dislike"> <span class="bold">Dislike</span></p>
					                      	<p class="simple-dropdown-text">Matt Parker</p>
					                      	<p class="simple-dropdown-text">Destroy Dex</p>
					                      	<p class="simple-dropdown-text">The Green Goo</p>
					                    </div>
				                  	</div>
				                  	<div class="reaction-item">
				                    	<img class="reaction-image reaction-item-dropdown-trigger" src="{{asset('assets/frontend/img/reaction/love.png')}}" alt="reaction-love">
					                    <div class="simple-dropdown padded reaction-item-dropdown">
					                      	<p class="simple-dropdown-text"><img class="reaction" src="{{asset('assets/frontend/img/reaction/love.png')}}" alt="reaction-love"> <span class="bold">Love</span></p>
					                      	<p class="simple-dropdown-text">Sandra Strange</p>
					                      	<p class="simple-dropdown-text">Jane Rodgers</p>
					                    </div>
				                  	</div>
				                  	<div class="reaction-item">
				                    	<img class="reaction-image reaction-item-dropdown-trigger" src="{{asset('assets/frontend/img/reaction/like.png')}}" alt="reaction-like">
					                    <div class="simple-dropdown padded reaction-item-dropdown">
					                      	<p class="simple-dropdown-text"><img class="reaction" src="{{asset('assets/frontend/img/reaction/like.png')}}" alt="reaction-like"> <span class="bold">Like</span></p>
					                      	<p class="simple-dropdown-text">Neko Bebop</p>
					                      	<p class="simple-dropdown-text">Nick Grissom</p>
					                      	<p class="simple-dropdown-text">Sarah Diamond</p>
					                      	<p class="simple-dropdown-text">Jett Spiegel</p>
					                      	<p class="simple-dropdown-text"><span class="bold">and 2 more...</span></p>
					                    </div>
				                  	</div>
				                </div>
				                <p class="meta-line-text">11</p>
			              	</div>
			              <div class="meta-line">
			                <div class="meta-line-list user-avatar-list">
			                  	<div class="user-avatar micro no-stats">
				                    <div class="user-avatar-border">
				                      	<div class="hexagon-22-24"></div>
				                    </div>
				                    <div class="user-avatar-content">
				                      	<div class="hexagon-image-18-20" data-src="{{asset('assets/frontend/img/avatar/08.jpg')}}"></div>
				                    </div>
			                  	</div>
			                  	<div class="user-avatar micro no-stats">
				                    <div class="user-avatar-border">
				                      	<div class="hexagon-22-24"></div>
				                    </div>
				                    <div class="user-avatar-content">
				                      	<div class="hexagon-image-18-20" data-src="{{asset('assets/frontend/img/avatar/11.jpg')}}"></div>
				                    </div>
			                  	</div>
			                  	<div class="user-avatar micro no-stats">
				                    <div class="user-avatar-border">
				                      	<div class="hexagon-22-24"></div>
				                    </div>
				                    <div class="user-avatar-content">
				                      	<!-- HEXAGON -->
				                      	<div class="hexagon-image-18-20" data-src="{{asset('assets/frontend/img/avatar/06.jpg')}}"></div>
				                      	<!-- /HEXAGON -->
				                    </div>
				                    <!-- /USER AVATAR CONTENT -->
			                  	</div>
			                  <!-- /USER AVATAR -->
			        
			                  <!-- USER AVATAR -->
			                  <div class="user-avatar micro no-stats">
			                    <!-- USER AVATAR BORDER -->
			                    <div class="user-avatar-border">
			                      <!-- HEXAGON -->
			                      <div class="hexagon-22-24"></div>
			                      <!-- /HEXAGON -->
			                    </div>
			                    <!-- /USER AVATAR BORDER -->
			                
			                    <!-- USER AVATAR CONTENT -->
			                    <div class="user-avatar-content">
			                      <!-- HEXAGON -->
			                      <div class="hexagon-image-18-20" data-src="{{asset('assets/frontend/img/avatar/07.jpg')}}"></div>
			                      <!-- /HEXAGON -->
			                    </div>
			                    <!-- /USER AVATAR CONTENT -->
			                  </div>
			                  <!-- /USER AVATAR -->
			        
			                  <!-- USER AVATAR -->
			                  <div class="user-avatar micro no-stats">
			                    <!-- USER AVATAR BORDER -->
			                    <div class="user-avatar-border">
			                      <!-- HEXAGON -->
			                      <div class="hexagon-22-24"></div>
			                      <!-- /HEXAGON -->
			                    </div>
			                    <!-- /USER AVATAR BORDER -->
			                
			                    <!-- USER AVATAR CONTENT -->
			                    <div class="user-avatar-content">
			                      <!-- HEXAGON -->
			                      <div class="hexagon-image-18-20" data-src="{{asset('assets/frontend/img/avatar/10.jpg')}}"></div>
			                      <!-- /HEXAGON -->
			                    </div>
			                    <!-- /USER AVATAR CONTENT -->
			                  </div>
			                  <!-- /USER AVATAR -->
			                </div>
			                <!-- /META LINE LIST -->
			        
			                <!-- META LINE TEXT -->
			                <p class="meta-line-text">18 Participants</p>
			                <!-- /META LINE TEXT -->
			              </div>
			              <!-- /META LINE -->
			            </div>
			            <!-- /CONTENT ACTION -->
			        
			            <!-- CONTENT ACTION -->
			            <div class="content-action">
			              <!-- META LINE -->
			              <div class="meta-line">
			                <!-- META LINE LINK -->
			                <p class="meta-line-link">15 Comments</p>
			                <!-- /META LINE LINK -->
			              </div>
			              <!-- /META LINE -->
			        
			              <!-- META LINE -->
			              <div class="meta-line">
			                <!-- META LINE TEXT -->
			                <p class="meta-line-text">0 Shares</p>
			                <!-- /META LINE TEXT -->
			              </div>
			              <!-- /META LINE -->
			            </div>
			            <!-- /CONTENT ACTION -->
			          </div>
			          <!-- /CONTENT ACTIONS -->
			        </div>
			        <!-- /WIDGET BOX STATUS CONTENT -->
		      	</div>
		      <!-- /WIDGET BOX STATUS -->
		  
		      <!-- POST OPTIONS -->
		      <div class="post-options">
		        <!-- POST OPTION WRAP -->
		        <div class="post-option-wrap">
		          <!-- POST OPTION -->
		          <div class="post-option reaction-options-dropdown-trigger">
		            <!-- POST OPTION ICON -->
		            <svg class="post-option-icon icon-thumbs-up">
		              <use xlink:href="#svg-thumbs-up"></use>
		            </svg>
		            <!-- /POST OPTION ICON -->
		  
		            <!-- POST OPTION TEXT -->
		            <p class="post-option-text">React!</p>
		            <!-- /POST OPTION TEXT -->
		          </div>
		          <!-- /POST OPTION -->
		  
		          <!-- REACTION OPTIONS -->
		          <div class="reaction-options reaction-options-dropdown">
		            <!-- REACTION OPTION -->
		            <div class="reaction-option text-tooltip-tft" data-title="Like">
		              <!-- REACTION OPTION IMAGE -->
		              <img class="reaction-option-image" src="{{asset('assets/frontend/img/reaction/like.png')}}" alt="reaction-like">
		              <!-- /REACTION OPTION IMAGE -->
		            </div>
		            <!-- /REACTION OPTION -->
		  
		            <!-- REACTION OPTION -->
		            <div class="reaction-option text-tooltip-tft" data-title="Love">
		              <!-- REACTION OPTION IMAGE -->
		              <img class="reaction-option-image" src="{{asset('assets/frontend/img/reaction/love.png')}}" alt="reaction-love">
		              <!-- /REACTION OPTION IMAGE -->
		            </div>
		            <!-- /REACTION OPTION -->
		  
		            <!-- REACTION OPTION -->
		            <div class="reaction-option text-tooltip-tft" data-title="Dislike">
		              	<!-- REACTION OPTION IMAGE -->
		              	<img class="reaction-option-image" src="{{asset('assets/frontend/img/reaction/dislike.png')}}" alt="reaction-dislike">
		              	<!-- /REACTION OPTION IMAGE -->
		            </div>
		            <!-- /REACTION OPTION -->
		  
		            <!-- REACTION OPTION -->
		            <div class="reaction-option text-tooltip-tft" data-title="Happy">
		              <!-- REACTION OPTION IMAGE -->
		              <img class="reaction-option-image" src="{{asset('assets/frontend/img/reaction/happy.png')}}" alt="reaction-happy">
		              <!-- /REACTION OPTION IMAGE -->
		            </div>
		            <!-- /REACTION OPTION -->
		  
		            <!-- REACTION OPTION -->
		            <div class="reaction-option text-tooltip-tft" data-title="Funny">
		              <!-- REACTION OPTION IMAGE -->
		              <img class="reaction-option-image" src="{{asset('assets/frontend/img/reaction/funny.png')}}" alt="reaction-funny">
		              <!-- /REACTION OPTION IMAGE -->
		            </div>
		            <!-- /REACTION OPTION -->
		  
		            <!-- REACTION OPTION -->
		            <div class="reaction-option text-tooltip-tft" data-title="Wow">
		              <!-- REACTION OPTION IMAGE -->
		              <img class="reaction-option-image" src="{{asset('assets/frontend/img/reaction/wow.png')}}" alt="reaction-wow">
		              <!-- /REACTION OPTION IMAGE -->
		            </div>
		            <!-- /REACTION OPTION -->
		  
		            <!-- REACTION OPTION -->
		            <div class="reaction-option text-tooltip-tft" data-title="Angry">
		              <!-- REACTION OPTION IMAGE -->
		              <img class="reaction-option-image" src="{{asset('assets/frontend/img/reaction/angry.png')}}" alt="reaction-angry">
		              <!-- /REACTION OPTION IMAGE -->
		            </div>
		            <!-- /REACTION OPTION -->
		  
		            <!-- REACTION OPTION -->
		            <div class="reaction-option text-tooltip-tft" data-title="Sad">
		              <!-- REACTION OPTION IMAGE -->
		              <img class="reaction-option-image" src="{{asset('assets/frontend/img/reaction/sad.png')}}" alt="reaction-sad">
		              <!-- /REACTION OPTION IMAGE -->
		            </div>
		            <!-- /REACTION OPTION -->
		          </div>
		          <!-- /REACTION OPTIONS -->
		        </div>
		        <!-- /POST OPTION WRAP -->
		  
		        <!-- POST OPTION -->
		        <div class="post-option">
		          <!-- POST OPTION ICON -->
		          <svg class="post-option-icon icon-comment">
		            <use xlink:href="#svg-comment"></use>
		          </svg>
		          <!-- /POST OPTION ICON -->
		  
		          <!-- POST OPTION TEXT -->
		          <p class="post-option-text">Comment</p>
		          <!-- /POST OPTION TEXT -->
		        </div>
		        <!-- /POST OPTION -->
		  
		        <!-- POST OPTION -->
		        <div class="post-option">
		          <!-- POST OPTION ICON -->
		          <svg class="post-option-icon icon-share">
		            <use xlink:href="#svg-share"></use>
		          </svg>
		          <!-- /POST OPTION ICON -->
		  
		          <!-- POST OPTION TEXT -->
		          <p class="post-option-text">Share</p>
		          <!-- /POST OPTION TEXT -->
		        </div>
		        <!-- /POST OPTION -->
		      </div>
		      <!-- /POST OPTIONS -->
		    </div>
		    <!-- /WIDGET BOX -->
		    @endif
    	@endforeach
    </div>
    <!-- /GRID COLUMN -->

    {{-- Page Right part --}}
  	<!-- GRID COLUMN -->
  	<div class="grid-column">
        <div class="widget-box">
          <div class="widget-box-settings">
            <div class="post-settings-wrap">
              <div class="post-settings widget-box-post-settings-dropdown-trigger">
                <svg class="post-settings-icon icon-more-dots">
                  <use xlink:href="#svg-more-dots"></use>
                </svg>
              </div>
              <div class="simple-dropdown widget-box-post-settings-dropdown">
                <p class="simple-dropdown-link">Widget Settings</p>
              </div>
            </div>
          </div>
          <p class="widget-box-title">Photos <span class="highlighted">74</span></p>
          <div class="widget-box-content">
            <div class="picture-item-list small">
              <div class="picture-item">
                <figure class="picture round liquid">
                  <img src="{{asset('assets/frontend/img/avatar/01.jpg')}}" alt="avatar-01">
                </figure>
              </div>
              <div class="picture-item">
                <figure class="picture round liquid">
                  <img src="{{asset('assets/frontend/img/cover/10.jpg')}}" alt="avatar-10">
                </figure>
              </div>
              <div class="picture-item">
                <figure class="picture round liquid">
                  <img src="{{asset('assets/frontend/img/cover/12.jpg')}}" alt="avatar-12">
                </figure>
              </div>
              <div class="picture-item">
                <figure class="picture round liquid">
                  <img src="{{asset('assets/frontend/img/cover/02.jpg')}}" alt="avatar-02">
                </figure>
              </div>
              <div class="picture-item">
                <figure class="picture round liquid">
                  <img src="{{asset('assets/frontend/img/cover/06.jpg')}}" alt="avatar-06">
                </figure>
              </div>
              	<div class="picture-item">
	                <figure class="picture round liquid">
	                  <img src="{{asset('assets/frontend/img/cover/13.jpg')}}" alt="avatar-13">
	                </figure>
              	</div>
                <div class="picture-item-overlay round">
                  	<p class="picture-item-overlay-text">+61</p>
                </div>
              </a>
            </div>
          </div>
        </div>

        <!-- WIDGET BOX -->
        <div class="widget-box">
          <div class="widget-box-settings">
            <div class="post-settings-wrap">
              <div class="post-settings widget-box-post-settings-dropdown-trigger">
                <svg class="post-settings-icon icon-more-dots">
                  <use xlink:href="#svg-more-dots"></use>
                </svg>
              </div>
              <div class="simple-dropdown widget-box-post-settings-dropdown">
                <p class="simple-dropdown-link">Widget Settings</p>
              </div>
            </div>
          </div>
          <p class="widget-box-title">Forums</p>
          <div class="widget-box-content">
            <div class="filters">
              <p class="filter">Newest</p>
              <p class="filter active">Popular</p>
              <p class="filter">Active</p>
            </div>
            <div class="user-status-list">
              <div class="user-status request-small">
                <a class="user-status-avatar" href="#">
                  <div class="user-avatar small no-border">
                    <div class="user-avatar-content">
                      <div class="hexagon-image-40-44" data-src="{{asset('assets/frontend/img/avatar/29.jpg')}}"></div>
                    </div>
                  </div>
                </a>
                <p class="user-status-title"><a class="bold" href="group-timeline.html">Twitch Streamers</a></p>
                <p class="user-status-text small">265 members</p>
                <div class="action-request-list">
                  <div class="action-request accept">
                    <svg class="action-request-icon icon-join-group">
                      <use xlink:href="#svg-join-group"></use>
                    </svg>
                  </div>
                </div>
              </div>
              <div class="user-status request-small">
                <a class="user-status-avatar" href="#">
                  <div class="user-avatar small no-border">
                    <div class="user-avatar-content">
                      <div class="hexagon-image-40-44" data-src="{{asset('assets/frontend/img/avatar/24.jpg')}}"></div>
                    </div>
                  </div>
                </a>
                <p class="user-status-title"><a class="bold" href="group-timeline.html">Cosplayers of the World</a></p>
                <p class="user-status-text small">139 members</p>
                <div class="action-request-list">
                  <div class="action-request accept">
                    <svg class="action-request-icon icon-join-group">
                      <use xlink:href="#svg-join-group"></use>
                    </svg>
                  </div>
                </div>
              </div>
              <div class="user-status request-small">
                <a class="user-status-avatar" href="#">
                  <div class="user-avatar small no-border">
                    <div class="user-avatar-content">
                      <div class="hexagon-image-40-44" data-src="{{asset('assets/frontend/img/avatar/25.jpg')}}"></div>
                    </div>
                  </div>
                </a>
                <p class="user-status-title"><a class="bold" href="#">Stream Designers</a></p>
                <p class="user-status-text small">466 members</p>
                <div class="action-request-list">
                  <div class="action-request accept">
                    <svg class="action-request-icon icon-join-group">
                      <use xlink:href="#svg-join-group"></use>
                    </svg>
                  </div>
                </div>
              </div>
              <div class="user-status request-small">
                <a class="user-status-avatar" href="#">
                  <div class="user-avatar small no-border">
                    <div class="user-avatar-content">
                      <div class="hexagon-image-40-44" data-src="{{asset('assets/frontend/img/avatar/28.jpg')}}"></div>
                    </div>
                  </div>
                </a>
                <p class="user-status-title"><a class="bold" href="#">Street Artists</a></p>
                <p class="user-status-text small">951 members</p>
                <div class="action-request-list">
                  <div class="action-request decline">
                    <svg class="action-request-icon icon-leave-group">
                      <use xlink:href="#svg-leave-group"></use>
                    </svg>
                  </div>
                </div>
              </div>
              <div class="user-status request-small">
                <a class="user-status-avatar" href="#">
                  <div class="user-avatar small no-border">
                    <div class="user-avatar-content">
                      <div class="hexagon-image-40-44" data-src="{{asset('assets/frontend/img/avatar/27.jpg')}}"></div>
                    </div>
                  </div>
                </a>
                <p class="user-status-title"><a class="bold" href="group-timeline.html">Gaming Watchtower</a></p>
                <p class="user-status-text small">2.365 members</p>
                <div class="action-request-list">
                  <div class="action-request accept">
                    <svg class="action-request-icon icon-join-group">
                      <use xlink:href="#svg-join-group"></use>
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
  	</div>
</div>

@if(Auth::user())
    <script>
      function post_comment($post_id){
        var post_id = $post_id;
        var post_comment = $('#comment'+post_id).val();
        var user_image = '{{Auth::user()->image}}';
        var user_name = '{{Auth::user()->name}}';
        $('#comment'+post_id).val('');
        console.log(post_comment);
        $.ajax({
            url: "{{ url('post_comment') }}",
            method: "get",
            data: {post_id:post_id,post_comment:post_comment},
            success: function(data){
              if (post_comment) {

                 $('#push_post'+post_id).append('<span>'+
                  '<img src="'+user_image+'" style="border-radius:50px;width:50px;margin-left: 20px;margin-right: 10px;" >'+
                '</span>'+
                '<span style="width: 80%">'+
                  '<p>'+
                    '<span style="color: #ed2124;font-weight: bold;">'+user_name+'</span> <span>'+
                      post_comment+
                    '</span>'+
                  '</p>'+
                '</span>');
               }else{
                alert('Please Type a comment first');
               }
            }
          });
      }

      function react_post($id,$post_id){
        var auth = {{Auth::user()->id}};
        var post_id = $post_id;
        var react_id = $id;
        if (auth) {
          $.ajax({
            url: "{{ url('react_post') }}",
            method: "get",
            data: {post_id:$post_id,react_id:$id},
            success: function(data){
              console.log($('#react'+post_id+react_id).text());
              
              $('#react'+post_id).empty();
              if(react_id == 1){
                $('#react'+post_id).html('<img class="reaction-image reaction-item-dropdown-trigger" src="{{asset('assets/frontend/img/reaction/like.png')}}" alt="reaction-like">');
              }else if(react_id == 2){
                $('#react'+post_id).html('<img class="reaction-image reaction-item-dropdown-trigger" src="{{asset('assets/frontend/img/reaction/love.png')}}" alt="reaction-love">');
              }else if(react_id == 3){
                $('#react'+post_id).html('<img class="reaction-image reaction-item-dropdown-trigger" src="{{asset('assets/frontend/img/reaction/angry.png')}}" alt="reaction-angry">');
              }else if(react_id == 4){
                $('#react'+post_id).html('<img class="reaction-image reaction-item-dropdown-trigger" src="{{asset('assets/frontend/img/reaction/sad.png')}}" alt="reaction-sad">');
              }
              

            }
          });
        }else{
          alert('Please Login First');
        }
      }
    </script>
@endif