@extends('layouts.frontend_layout')
@section('contents')
<div style="padding-left: 7%;margin-top: -30px;">
    <div class="section-header">
        <div class="section-header-info">
            <p class="section-pretitle"> E-Book </p>
            <h2 class="section-title">Browse E-Books</h2>
        </div>
    </div>
    <div class="section-filters-bar v2">
        <form class="form">
            <div class="form-item split medium">
                <div class="form-select">
                    <label for="quest-filter-show">Show</label>
                    <select id="quest-filter-show" name="quest_filter_show">
                        <option value="0">All E-Book</option>
                        <option value="1">Completed Quests</option>
                        <option value="2">Open Quests</option>
                    </select>
                    <svg class="form-select-icon icon-small-arrow">
                        <use xlink:href="#svg-small-arrow"></use>
                    </svg>
                </div>
                <div class="form-select">
                    <label for="quest-filter-criteria">Filter By</label>
                    <select id="quest-filter-criteria" name="quest_filter_criteria">
                        <option value="0">Quest Progress</option>
                        <option value="1">Quest EXP</option>
                    </select>
                    <svg class="form-select-icon icon-small-arrow">
                        <use xlink:href="#svg-small-arrow"></use>
                    </svg>
                </div>
                <div class="form-select">
                    <label for="quest-filter-order">Order By</label>
                    <select id="quest-filter-order" name="quest_filter_order">
                        <option value="0">Descending</option>
                        <option value="1">Ascending</option>
                    </select>
                    <svg class="form-select-icon icon-small-arrow">
                        <use xlink:href="#svg-small-arrow"></use>
                    </svg>
                </div>
                <button class="button secondary">Filter E-Book</button>
            </div>
        </form>
    </div>
    {{-- Contant Table --}}
    <div class="table table-quests split-rows">
        <div class="table-header">
            <div class="table-header-column">
                <p class="table-header-title">E-Book</p>
            </div>
            <div class="table-header-column">
                <p class="table-header-title">Description</p>
            </div>
            <div class="table-header-column centered padded-big-left">
                <p class="table-header-title">Experience</p>
            </div>
            <div class="table-header-column padded-big-left">
                <p class="table-header-title">Progress</p>
            </div>
        </div>
        <div class="table-body same-color-rows">
            <div class="table-row small">
                <div class="table-column">
                    <div class="table-information">
                        <img class="table-image" src="{{asset('assets/frontend/img/quest/completedq-s.png')}}" alt="completedq-s">
                        <p class="table-title">Press Start!</p>
                    </div>
                </div>
                <div class="table-column">
                    <p class="table-text">Post a status update or any other post for the first time
                    </p>
                </div>
                <div class="table-column centered padded-big-left">
                    <p class="text-sticker void">
                        <svg class="text-sticker-icon icon-plus-small">
                            <use xlink:href="#svg-plus-small"></use>
                        </svg>
                        20 EXP
                    </p>
                </div>
                <div class="table-column padded-big-left">
                    <div class="progress-stat-wrap">
                        <div class="progress-stat">
                            <div id="quest-line-ps" class="progress-stat-bar"></div>
                            <div class="bar-progress-wrap">
                                <p class="bar-progress-info medium negative"><span class="bar-progress-text no-space"></span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="table-row small">
                <div class="table-column">
                    <div class="table-information">
                        <img class="table-image" src="{{asset('assets/frontend/img/quest/openq-s.png')}}" alt="openq-s">
                        <p class="table-title">Nothing to Hide</p>
                    </div>
                </div>
                <div class="table-column">
                    <p class="table-text">You have completed all your profile information fields
                    </p>
                </div>
                <div class="table-column centered padded-big-left">
                    <p class="text-sticker void">
                        <svg class="text-sticker-icon icon-plus-small">
                            <use xlink:href="#svg-plus-small"></use>
                        </svg>
                        40 EXP
                    </p>
                </div>
                <div class="table-column padded-big-left">
                    <div class="progress-stat-wrap">
                        <div class="progress-stat">
                            <div id="quest-line-nth" class="progress-stat-bar"></div>
                            <div class="bar-progress-wrap">
                                <p class="bar-progress-info medium negative"><span class="bar-progress-text no-space"></span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="table-row small">
                <div class="table-column">
                    <div class="table-information">
                        <img class="table-image" src="{{asset('assets/frontend/img/quest/completedq-s.png')}}" alt="completedq-s">
                        <p class="table-title">Friendly User</p>
                    </div>
                </div>
                <div class="table-column">
                    <p class="table-text">Give 50 like and/or love reactions on your friends' posts
                    </p>
                </div>
                <div class="table-column centered padded-big-left">
                    <p class="text-sticker void">
                        <svg class="text-sticker-icon icon-plus-small">
                            <use xlink:href="#svg-plus-small"></use>
                        </svg>
                        40 EXP
                    </p>
                </div>
                <div class="table-column padded-big-left">
                    <div class="progress-stat-wrap">
                        <div class="progress-stat">
                            <div id="quest-line-fu" class="progress-stat-bar"></div>
                            <div class="bar-progress-wrap">
                                <p class="bar-progress-info medium negative"><span class="bar-progress-text no-space"></span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@stop